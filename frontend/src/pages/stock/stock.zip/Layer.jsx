import React from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Store, 
  Layers, 
  Package, 
  Users, 
  ShoppingCart, 
  FileText, 
  BarChart3 
} from 'lucide-react';

const CartesStock = () => {
  const navigate = useNavigate();
  
  const cartes = [
    {
      titre: 'Gestion des Magasins',
      description: 'Gérez les magasins et leurs configurations',
      icone: Store,
      chemin: '/magasins',
      couleur: 'bg-blue-500'
    },
    {
      titre: 'Gestion des Catégories',
      description: 'Créez et gérez les catégories de produits',
      icone: Layers,
      chemin: '/categories',
      couleur: 'bg-green-500'
    },
    {
      titre: 'Gestion des Produits',
      description: 'Ajoutez et gérez les produits',
      icone: Package,
      chemin: '/products',
      couleur: 'bg-purple-500'
    },
    {
      titre: 'Gestion des Fournisseurs',
      description: 'Gérez les fournisseurs et leurs contacts',
      icone: Users,
      chemin: '/suppliers',
      couleur: 'bg-orange-500'
    },
    {
      titre: 'Demandes d\'Achat',
      description: 'Créez et suivez les demandes d\'achat',
      icone: FileText,
      chemin: '/purchase-requests',
      couleur: 'bg-red-500'
    },
    {
      titre: 'Commandes d\'Achat',
      description: 'Gérez les commandes d\'achat',
      icone: ShoppingCart,
      chemin: '/purchase-orders',
      couleur: 'bg-indigo-500'
    },
    {
      titre: 'Gestion des Stocks',
      description: 'Surveillez et gérez les niveaux de stock',
      icone: BarChart3,
      chemin: '/stock',
      couleur: 'bg-teal-500'
    }
  ];

  const gererClicCarte = (chemin) => {
    navigate(chemin);
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 p-6">
      {cartes.map((carte, index) => {
        const ComposantIcone = carte.icone;
        return (
          <div
            key={index}
            className="bg-white rounded-lg shadow-md p-6 cursor-pointer transition-all duration-200 hover:shadow-lg hover:transform hover:scale-105"
            onClick={() => gererClicCarte(carte.chemin)}
          >
            <div className="flex items-center mb-4">
              <div className={`p-3 rounded-full ${carte.couleur} text-white`}>
                <ComposantIcone className="h-6 w-6" />
              </div>
              <h3 className="ml-4 text-lg font-semibold text-gray-900">
                {carte.titre}
              </h3>
            </div>
            <p className="text-sm text-gray-600">
              {carte.description}
            </p>
            <div className="mt-4 text-sm text-blue-600 font-medium">
              Cliquer pour accéder →
            </div>
          </div>
        );
      })}
    </div>
  );
};

export default CartesStock;