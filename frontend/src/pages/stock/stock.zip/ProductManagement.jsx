import { useState, useEffect } from 'react';
import { useAuth } from '../../hooks/useAuth';
import { usePermissions } from '../../hooks/usePermissions';
import axios from 'axios';
import { Plus, Package, Tags, Store, User, CheckCircle, XCircle, Clock, Filter, X, Search, Lock } from 'lucide-react';

const ProductManagement = () => {
  const { user } = useAuth();
  const { hasComponentAccess, hasPermission, loading: permissionsLoading } = usePermissions();
  const [products, setProducts] = useState([]);
  const [filteredProducts, setFilteredProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [magasins, setMagasins] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [showFilterModal, setShowFilterModal] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState('');
  const [requiredFields, setRequiredFields] = useState([]);
  const [formData, setFormData] = useState({
    name: '',
    category_id: '',
    magasin_id: '',
    product_data: {}
  });
  const [error, setError] = useState(null);
  const [actionLoading, setActionLoading] = useState(false);

  // États de filtre
  const [filters, setFilters] = useState({
    category: '',
    magasin: '',
    status: '',
    createdBy: '',
    searchTerm: ''
  });
  const [activeFilters, setActiveFilters] = useState([]);

  useEffect(() => {
    fetchData();
    // eslint-disable-next-line
  }, []);

  useEffect(() => {
    applyFilters();
    // eslint-disable-next-line
  }, [products, filters]);

  const fetchData = async () => {
    setLoading(true);
    setError(null);
    try {
      const [productsRes, categoriesRes, magasinsRes] = await Promise.all([
        axios.get('http://localhost:5000/api/products/magasin/' + user.magasin.id),
        axios.get('http://localhost:5000/api/categories/magasin/' + user.magasin.id),
        axios.get('http://localhost:5000/api/magasins')
      ]);
      setProducts(productsRes.data);

      // Accepte les required_fields sous forme de chaîne ou de tableau, et filtre par is_approved
      const filteredCategories = categoriesRes.data.filter(cat => cat.is_approved === 1);
      setCategories(filteredCategories);
      setMagasins(magasinsRes.data);
    } catch (error) {
      console.error('Erreur lors de la récupération des données :', error);
      setError('Échec de la récupération des données. Veuillez réessayer.');
    } finally {
      setLoading(false);
    }
  };

  // Fonctionnalité de filtrage
  const applyFilters = () => {
    let filtered = [...products];

    // Filtre catégorie
    if (filters.category) {
      filtered = filtered.filter(product => 
        product.category_name?.toLowerCase().includes(filters.category.toLowerCase())
      );
    }

    // Filtre magasin
    if (filters.magasin) {
      filtered = filtered.filter(product => 
        product.magasin_name?.toLowerCase().includes(filters.magasin.toLowerCase())
      );
    }

    // Filtre statut
    if (filters.status) {
      filtered = filtered.filter(product => product.status === filters.status);
    }

    // Filtre créateur
    if (filters.createdBy) {
      filtered = filtered.filter(product => 
        product.created_by_name?.toLowerCase().includes(filters.createdBy.toLowerCase())
      );
    }

    // Filtre recherche
    if (filters.searchTerm) {
      filtered = filtered.filter(product => {
        const searchLower = filters.searchTerm.toLowerCase();
        return product.name.toLowerCase().includes(searchLower) ||
               product.category_name?.toLowerCase().includes(searchLower) ||
               product.magasin_name?.toLowerCase().includes(searchLower);
      });
    }

    setFilteredProducts(filtered);
    updateActiveFilters();
  };

  const updateActiveFilters = () => {
    const active = [];
    if (filters.category) active.push({ key: 'category', label: `Catégorie : ${filters.category}`, value: filters.category });
    if (filters.magasin) active.push({ key: 'magasin', label: `Magasin : ${filters.magasin}`, value: filters.magasin });
    if (filters.status) active.push({ key: 'status', label: `Statut : ${filters.status}`, value: filters.status });
    if (filters.createdBy) active.push({ key: 'createdBy', label: `Créé par : ${filters.createdBy}`, value: filters.createdBy });
    if (filters.searchTerm) active.push({ key: 'searchTerm', label: `Recherche : ${filters.searchTerm}`, value: filters.searchTerm });
    setActiveFilters(active);
  };

  const removeFilter = (filterKey) => {
    setFilters(prev => ({ ...prev, [filterKey]: '' }));
  };

  const clearAllFilters = () => {
    setFilters({
      category: '',
      magasin: '',
      status: '',
      createdBy: '',
      searchTerm: ''
    });
  };

  const handleFilterChange = (key, value) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  // Gérer la sélection de catégorie, supporte required_fields en tableau ou chaîne
  const handleCategoryChange = (categoryId) => {
    setSelectedCategory(categoryId);
    const category = categories.find(c => c.id.toString() === categoryId);
    if (category) {
      let fields = [];
      if (Array.isArray(category.required_fields)) {
        fields = category.required_fields;
      } else if (typeof category.required_fields === 'string') {
        try {
          fields = JSON.parse(category.required_fields);
        } catch {
          fields = [];
        }
      }
      setRequiredFields(fields);
      setFormData(prev => ({
        ...prev,
        category_id: categoryId,
        magasin_id: category.magasin.id,
        product_data: {}
      }));
    } else {
      setRequiredFields([]);
      setFormData(prev => ({
        ...prev,
        category_id: '',
        magasin_id: '',
        product_data: {}
      }));
    }
  };

  const handleFieldChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      product_data: {
        ...prev.product_data,
        [field]: value
      }
    }));
  };

  // Valider les champs requis avant soumission
  const validateForm = () => {
    if (!formData.category_id) {
      setError('La catégorie est requise.');
      return false;
    }
    if (!formData.magasin.id) {
      setError('Le magasin est requis.');
      return false;
    }
    if (!formData.product_data || Object.keys(formData.product_data).length === 0) {
      setError('Les champs du produit sont requis.');
      return false;
    }
    // Vérifier que tous les champs requis sont remplis
    for (let field of requiredFields) {
      if (!formData.product_data[field] || formData.product_data[field].trim() === '') {
        setError(`Le champ "${field}" est requis.`);
        return false;
      }
    }
    return true;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);

    // Valider avant soumission
    if (!validateForm()) {
      return;
    }

    setActionLoading(true);

    // Composer le payload avec created_by
    const payload = {
      ...formData,
      created_by: user?.name || user?.username || user?.email || 'Inconnu'
    };

    try {
      await axios.post('http://localhost:5000/api/products', payload);
      setShowModal(false);
      setFormData({ name: '', category_id: '', magasin_id: '', product_data: {} });
      setRequiredFields([]);
      setSelectedCategory('');
      await fetchData();
    } catch (error) {
      console.error('Erreur lors de la création du produit :', error);
      if (error.response && error.response.data && error.response.data.error) {
        setError(error.response.data.error);
      } else {
        setError('Échec de la création du produit. Veuillez réessayer.');
      }
    } finally {
      setActionLoading(false);
    }
  };

  const handleStatusUpdate = async (productId, status) => {
    setActionLoading(true);
    setError(null);
    try {
      await axios.patch(`http://localhost:5000/api/products/${productId}/status`, { status });
      await fetchData();
    } catch (error) {
      console.error('Erreur lors de la mise à jour du statut du produit :', error);
      setError('Échec de la mise à jour du statut du produit. Veuillez réessayer.');
    } finally {
      setActionLoading(false);
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'approved':
        return <CheckCircle className="h-5 w-5 text-green-600" />;
      case 'rejected':
        return <XCircle className="h-5 w-5 text-red-600" />;
      default:
        return <Clock className="h-5 w-5 text-yellow-600" />;
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'approved':
        return 'bg-green-100 text-green-800';
      case 'rejected':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-yellow-100 text-yellow-800';
    }
  };

  // Check component access
  if (permissionsLoading) {
    return <div className="p-6">Vérification des permissions...</div>;
  }

  if (!hasComponentAccess('ProductManagement')) {
    return (
      <div className="p-6">
        <div className="flex flex-col items-center justify-center min-h-[400px]">
          <Lock className="h-16 w-16 text-gray-400 mb-4" />
          <h2 className="text-xl font-semibold text-gray-900 mb-2">Accès non autorisé</h2>
          <p className="text-gray-600 text-center">
            Vous n'avez pas les permissions nécessaires pour accéder à la gestion des produits.
            <br />
            Veuillez contacter votre administrateur pour obtenir les droits d'accès appropriés.
          </p>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center w-full">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
        <div className="mt-4 text-gray-600 text-lg">Chargement des données...</div>
      </div>
    );
  }

  return (
    <div className="w-full py-6 px-2 sm:px-4 lg:px-8">
      <div className="py-6 px-0 w-full">
        {error && (
          <div className="mb-4 p-3 rounded bg-red-100 text-red-700 border border-red-200">
            {error}
          </div>
        )}
        <div className="sm:flex sm:items-center w-full">
          <div className="sm:flex-auto">
            <h1 className="text-3xl font-bold text-gray-900">Gestion des produits</h1>
            <p className="mt-2 text-sm text-gray-700">
              Gérez les produits selon les catégories approuvées
            </p>
          </div>
          <div className="mt-4 sm:mt-0 sm:ml-16 sm:flex-none space-x-2">
            <button
              onClick={() => setShowFilterModal(true)}
              className="inline-flex items-center justify-center rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
            >
              <Filter className="h-4 w-4 mr-2" />
              Filtres
              {activeFilters.length > 0 && (
                <span className="ml-2 bg-blue-100 text-blue-800 text-xs font-medium px-2 py-1 rounded-full">
                  {activeFilters.length}
                </span>
              )}
            </button>
            {hasPermission('create_product') && (
              <button
                onClick={() => setShowModal(true)}
                className="inline-flex items-center justify-center rounded-md border border-transparent bg-blue-600 px-4 py-2 text-sm font-medium text-white shadow-sm hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 sm:w-auto"
              >
                <Plus className="h-4 w-4 mr-2" />
                Ajouter un produit
              </button>
            )}
          </div>
        </div>

        {/* Affichage des filtres actifs */}
        {activeFilters.length > 0 && (
          <div className="mt-4 flex flex-wrap gap-2 items-center">
            <span className="text-sm font-medium text-gray-700">Filtres actifs :</span>
            {activeFilters.map((filter) => (
              <span
                key={filter.key}
                className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800"
              >
                {filter.label}
                <button
                  onClick={() => removeFilter(filter.key)}
                  className="ml-2 inline-flex items-center justify-center w-4 h-4 rounded-full hover:bg-blue-200"
                >
                  <X className="h-3 w-3" />
                </button>
              </span>
            ))}
            <button
              onClick={clearAllFilters}
              className="text-sm text-gray-500 hover:text-gray-700 underline"
            >
              Tout effacer
            </button>
          </div>
        )}

        {/* Barre de recherche */}
        <div className="mt-4">
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-5 w-5 text-gray-400" />
            </div>
            <input
              type="text"
              placeholder="Rechercher par nom, catégorie ou magasin..."
              className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
              value={filters.searchTerm}
              onChange={(e) => handleFilterChange('searchTerm', e.target.value)}
            />
          </div>
        </div>

        <div className="mt-8 flex flex-col w-full">
          <div className="-my-2 -mx-2 overflow-x-auto w-full">
            <div className="inline-block min-w-full py-2 align-middle px-2">
              <div className="overflow-hidden shadow ring-1 ring-black ring-opacity-5 rounded-lg w-full">
                <table className="min-w-full divide-y divide-gray-300 w-full">
                  <thead className="bg-gray-50 w-full">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Produit
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Catégorie
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Magasin
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Statut
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Créé par
                      </th>
                      <th className="relative px-6 py-3">
                        <span className="sr-only">Actions</span>
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200 w-full">
                    {filteredProducts.map((product) => (
                      <tr key={product.id}>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <Package className="h-5 w-5 text-gray-400 mr-3" />
                            <div className="text-sm font-medium text-gray-900">
                              {product.name}
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <Tags className="h-4 w-4 text-gray-400 mr-2" />
                            <span className="text-sm text-gray-900">
                              {product.category_name}
                            </span>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <Store className="h-4 w-4 text-gray-400 mr-2" />
                            <span className="text-sm text-gray-900">
                              {product.magasin_name}
                            </span>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            {getStatusIcon(product.status)}
                            <span className={`ml-2 inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(product.status)}`}>
                              {product.status === 'pending'
                                ? 'En attente'
                                : product.status === 'approved'
                                ? 'Approuvé'
                                : product.status === 'rejected'
                                ? 'Rejeté'
                                : product.status}
                            </span>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <User className="h-4 w-4 text-gray-400 mr-2" />
                            <span className="text-sm text-gray-900">
                              {product.created_by_name}
                            </span>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                          {hasPermission('validate_product') && product.status === 'pending' && (
                            <div className="flex space-x-2">
                              <button
                                onClick={() => handleStatusUpdate(product.id, 'approved')}
                                className={`text-green-600 hover:text-green-900 ${actionLoading ? 'opacity-50 pointer-events-none' : ''}`}
                                disabled={actionLoading}
                              >
                                {actionLoading ? 'Traitement...' : 'Approuver'}
                              </button>
                              <button
                                onClick={() => handleStatusUpdate(product.id, 'rejected')}
                                className={`text-red-600 hover:text-red-900 ${actionLoading ? 'opacity-50 pointer-events-none' : ''}`}
                                disabled={actionLoading}
                              >
                                {actionLoading ? 'Traitement...' : 'Rejeter'}
                              </button>
                            </div>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                {filteredProducts.length === 0 && (
                  <div className="text-center py-8 text-gray-500">
                    Aucun produit trouvé correspondant à vos filtres.
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Modal de filtre */}
        {showFilterModal && (
          <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
            <div className="relative top-10 mx-auto p-5 border w-full max-w-2xl shadow-lg rounded-md bg-white">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-medium text-gray-900">Filtrer les produits</h3>
                <button
                  onClick={() => setShowFilterModal(false)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <X className="h-6 w-6" />
                </button>
              </div>

              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Catégorie</label>
                    <input
                      type="text"
                      className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 text-sm"
                      placeholder="Entrer le nom de la catégorie"
                      value={filters.category}
                      onChange={(e) => handleFilterChange('category', e.target.value)}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Magasin</label>
                    <input
                      type="text"
                      className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 text-sm"
                      placeholder="Entrer le nom du magasin"
                      value={filters.magasin}
                      onChange={(e) => handleFilterChange('magasin', e.target.value)}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Statut</label>
                    <select
                      className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 text-sm"
                      value={filters.status}
                      onChange={(e) => handleFilterChange('status', e.target.value)}
                    >
                      <option value="">Tous les statuts</option>
                      <option value="pending">En attente</option>
                      <option value="approved">Approuvé</option>
                      <option value="rejected">Rejeté</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Créé par</label>
                    <input
                      type="text"
                      className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 text-sm"
                      placeholder="Entrer le nom du créateur"
                      value={filters.createdBy}
                      onChange={(e) => handleFilterChange('createdBy', e.target.value)}
                    />
                  </div>
                </div>

                <div className="flex justify-end space-x-3 pt-4">
                  <button
                    onClick={clearAllFilters}
                    className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50"
                  >
                    Tout effacer
                  </button>
                  <button
                    onClick={() => setShowFilterModal(false)}
                    className="px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-md hover:bg-blue-700"
                  >
                    Appliquer les filtres
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Modal */}
        {showModal && (
          <div style={{background:"#8080805e"}} className="fixed inset-0 bg-opacity-50 overflow-y-auto h-full w-full z-50">
            <div className="relative top-20 mx-auto p-5 border w-full max-w-5xl shadow-lg rounded-md bg-white max-h-5/6 overflow-y-auto">
              <div className="mt-3">
                <h3 className="text-lg font-medium text-gray-900 mb-4">
                  Créer un nouveau produit
                </h3>
                
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Nom du produit
                    </label>
                    <input
                      type="text"
                      required
                      className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      disabled={actionLoading}
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Catégorie
                    </label>
                    <select
                      required
                      className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                      value={formData.category_id}
                      onChange={(e) => handleCategoryChange(e.target.value)}
                      disabled={actionLoading}
                    >
                      <option value="">Sélectionner une catégorie</option>
                      {categories.map((category) => (
                        <option key={category.id} value={category.id}>
                          {category.name} ({category.magasin_name})
                        </option>
                      ))}
                    </select>
                  </div>

                  {requiredFields.length > 0 && (
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Champs du produit
                      </label>
                      <div className="space-y-3 max-h-60 overflow-y-auto border border-gray-300 rounded-md p-3">
                        {requiredFields.map((field) => (
                          <div key={field}>
                            <label className="block text-sm font-medium text-gray-600">
                              {field}
                            </label>
                            <input
                              type="text"
                              className="mt-1 block w-full border border-gray-200 rounded-md px-3 py-2 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                              value={formData.product_data[field] || ''}
                              onChange={(e) => handleFieldChange(field, e.target.value)}
                              placeholder={`Entrer ${field}`}
                              disabled={actionLoading}
                            />
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  <div className="flex justify-end space-x-3 pt-4">
                    <button
                      type="button"
                      onClick={() => {
                        setShowModal(false);
                        setFormData({ name: '', category_id: '', magasin_id: '', product_data: {} });
                        setRequiredFields([]);
                        setSelectedCategory('');
                        setError(null);
                      }}
                      className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50"
                      disabled={actionLoading}
                    >
                      Annuler
                    </button>
                    <button
                      type="submit"
                      className={`px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 ${actionLoading ? 'opacity-50 pointer-events-none' : ''}`}
                      disabled={actionLoading}
                    >
                      {actionLoading ? 'Création...' : 'Créer'}
                    </button>
                  </div>
                  {error && (
                    <div className="mt-2 p-2 rounded bg-red-100 text-red-700 border border-red-200">
                      {error}
                    </div>
                  )}
                </form>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProductManagement;