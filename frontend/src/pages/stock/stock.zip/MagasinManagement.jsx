import { useState, useEffect } from 'react';
import { useAuth } from '../../hooks/useAuth';
import { usePermissions } from '../../hooks/usePermissions';
import axios from 'axios';
import { Plus, Edit2, Eye, Filter, X, Search, Lock } from 'lucide-react';

const MagasinManagement = () => {
  const { hasComponentAccess, hasPermission, loading: permissionsLoading } = usePermissions();
  const [magasins, setMagasins] = useState([]);
  const [filteredMagasins, setFilteredMagasins] = useState([]);
  const [users, setUsers] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [showFilterModal, setShowFilterModal] = useState(false);
  const [editingMagasin, setEditingMagasin] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    responsable_id: '',
    email: '',
    phone: '',
    address: '',
    selected_fields: []
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  // États de filtre
  const [filters, setFilters] = useState({
    responsable: '',
    searchTerm: ''
  });
  const [activeFilters, setActiveFilters] = useState([]);

  const DEFAULT_FIELDS = [
    "Taille", "Qualite", "Couleur", "Composition", "Devise", "Unite", "Incoterm", 
    "Saison", "MarchéCible", "Certifications", "PaysOrigine", "HSCode", "Type", 
    "Statut", "Prod_Origine", "Marque", "Version", "Référence", "Libellé", "CodeABarre", 
    "Prix", "PrixMP", "LeadTime", "Poids_Net", "Poids_Unitaire", "Poids_M2", 
    "Construction", "ClasOnze", "RetTRMin", "RetTRMax", "RetCHMin", "RetCHMax", 
    "Laize", "Retrecissement_X", "Retrecissement_Y", "Note", "Domaine", 
    "InstructionsEntretien", "InfoDurabilité", "SpécTechniques", "Images", "Tags"
  ];

  // Check component access
 

  useEffect(() => {
    fetchMagasins();
    fetchUsers();
  }, []);

  useEffect(() => {
    applyFilters();
  }, [magasins, filters]);

  const fetchMagasins = async () => {
    try {
      const response = await axios.get('http://localhost:5000/api/magasins');
      setMagasins(response.data);
    } catch (error) {
      console.error('Erreur lors de la récupération des magasins :', error);
      setError('Échec de la récupération des magasins');
    }
  };

  // Fonctionnalité de filtre
  const applyFilters = () => {
    let filtered = [...magasins];

    // Filtre responsable
    if (filters.responsable) {
      filtered = filtered.filter(magasin => 
        magasin.responsable?.toLowerCase().includes(filters.responsable.toLowerCase())
      );
    }

    // Filtre de recherche
    if (filters.searchTerm) {
      filtered = filtered.filter(magasin => {
        const searchLower = filters.searchTerm.toLowerCase();
        return magasin.name.toLowerCase().includes(searchLower) ||
               magasin.responsable?.toLowerCase().includes(searchLower) ||
               magasin.responsable_email?.toLowerCase().includes(searchLower) ||
               magasin.address?.toLowerCase().includes(searchLower);
      });
    }

    setFilteredMagasins(filtered);
    updateActiveFilters();
  };

  const updateActiveFilters = () => {
    const active = [];
    if (filters.responsable) active.push({ key: 'responsable', label: `Responsable : ${filters.responsable}`, value: filters.responsable });
    if (filters.searchTerm) active.push({ key: 'searchTerm', label: `Recherche : ${filters.searchTerm}`, value: filters.searchTerm });
    setActiveFilters(active);
  };

  const removeFilter = (filterKey) => {
    setFilters(prev => ({ ...prev, [filterKey]: '' }));
  };

  const clearAllFilters = () => {
    setFilters({
      responsable: '',
      searchTerm: ''
    });
  };

  const handleFilterChange = (key, value) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  const fetchUsers = async () => {
    try {
      const response = await axios.get('http://localhost:5000/api/magasins/users');
      setUsers(response.data);
    } catch (error) {
      console.error('Erreur lors de la récupération des utilisateurs :', error);
      setError('Échec de la récupération des utilisateurs');
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      if (editingMagasin) {
        await axios.put(`http://localhost:5000/api/magasins/${editingMagasin.id}`, formData);
      } else {
        await axios.post('http://localhost:5000/api/magasins', formData);
      }
      
      await fetchMagasins();
      setShowModal(false);
      setEditingMagasin(null);
      setFormData({
        name: '',
        responsable_id: '',
        email: '',
        phone: '',
        address: '',
        selected_fields: []
      });
    } catch (error) {
      console.error('Erreur lors de l\'enregistrement du magasin :', error);
      setError(error.response?.data?.error || 'Échec de l\'enregistrement du magasin');
    } finally {
      setLoading(false);
    }
  };

  const handleFieldToggle = (field) => {
    const isSelected = formData.selected_fields.includes(field);
    setFormData(prev => ({
      ...prev,
      selected_fields: isSelected 
        ? prev.selected_fields.filter(f => f !== field)
        : [...prev.selected_fields, field]
    }));
  };

  const openModal = (magasin = null) => {
    if (magasin) {
      setEditingMagasin(magasin);
      setFormData({
        name: magasin.name,
        responsable_id: magasin.responsable_id || '',
        email: magasin.email || '',
        phone: magasin.phone || '',
        address: magasin.address || '',
        selected_fields: magasin.available_fields || []
      });
    } else {
      setEditingMagasin(null);
      setFormData({
        name: '',
        responsable_id: '',
        email: '',
        phone: '',
        address: '',
        selected_fields: DEFAULT_FIELDS
      });
    }
    setShowModal(true);
  };

  const getResponsableName = (responsableId) => {
    const user = users.find(u => u.id === responsableId);
    return user ? user.name : 'Aucun responsable assigné';
  };
  if (permissionsLoading) {
    return <div className="p-6">Vérification des permissions...</div>;
  }

  if (!hasComponentAccess('MagasinManagement')) {
    return (
      <div className="p-6">
        <div className="flex flex-col items-center justify-center min-h-[400px]">
          <Lock className="h-16 w-16 text-gray-400 mb-4" />
          <h2 className="text-xl font-semibold text-gray-900 mb-2">Accès non autorisé</h2>
          <p className="text-gray-600 text-center">
            Vous n'avez pas les permissions nécessaires pour accéder à la gestion des magasins.
            <br />
            Veuillez contacter votre administrateur pour obtenir les droits d'accès appropriés.
          </p>
        </div>
      </div>
    );
  }
  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Gestion des Magasins</h1>
          <p className="mt-2 text-sm text-gray-700">
            Gérez les magasins et leurs configurations
          </p>
        </div>
        <div className="flex space-x-2">
          <button
            onClick={() => setShowFilterModal(true)}
            className="inline-flex items-center justify-center rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
          >
            <Filter className="h-4 w-4 mr-2" />
            Filtres
            {activeFilters.length > 0 && (
              <span className="ml-2 bg-blue-100 text-blue-800 text-xs font-medium px-2 py-1 rounded-full">
                {activeFilters.length}
              </span>
            )}
          </button>
          {hasPermission('manage_magasin') && (
            <button
              onClick={() => openModal()}
              className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg flex items-center space-x-2"
            >
              <Plus className="h-4 w-4" />
              <span>Nouveau Magasin</span>
            </button>
          )}
        </div>
      </div>

      {/* Affichage des filtres actifs */}
      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
          {error}
        </div>
      )}

      {activeFilters.length > 0 && (
        <div className="mt-4 flex flex-wrap gap-2 items-center">
          <span className="text-sm font-medium text-gray-700">Filtres actifs :</span>
          {activeFilters.map((filter) => (
            <span
              key={filter.key}
              className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800"
            >
              {filter.label}
              <button
                onClick={() => removeFilter(filter.key)}
                className="ml-2 inline-flex items-center justify-center w-4 h-4 rounded-full hover:bg-blue-200"
              >
                <X className="h-3 w-3" />
              </button>
            </span>
          ))}
          <button
            onClick={clearAllFilters}
            className="text-sm text-gray-500 hover:text-gray-700 underline"
          >
            Tout effacer
          </button>
        </div>
      )}

      {/* Barre de recherche */}
      <div className="mt-4">
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search className="h-5 w-5 text-gray-400" />
          </div>
          <input
            type="text"
            placeholder="Rechercher par nom, responsable, email ou adresse..."
            className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
            value={filters.searchTerm}
            onChange={(e) => handleFilterChange('searchTerm', e.target.value)}
          />
        </div>
      </div>

      <div className="bg-white shadow rounded-lg overflow-hidden mt-6">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Nom
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Responsable
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Email Responsable
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Poste
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Champs Disponibles
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {filteredMagasins.map((magasin) => (
              <tr key={magasin.id}>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                  {magasin.name}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {magasin.responsable}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {magasin.responsable_email || 'N/A'}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {magasin.responsable_poste || 'N/A'}
                </td>
                <td className="px-6 py-4 text-sm text-gray-500">
                  <span className="text-xs bg-gray-100 px-2 py-1 rounded">
                    {magasin.available_fields?.length || 0} champs
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  <div className="flex space-x-2">
                    {hasPermission('manage_magasin') && (
                      <button
                        onClick={() => openModal(magasin)}
                        className="text-indigo-600 hover:text-indigo-900"
                      >
                        <Edit2 className="h-4 w-4" />
                      </button>
                    )}
                    <button className="text-blue-600 hover:text-blue-900">
                      <Eye className="h-4 w-4" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {filteredMagasins.length === 0 && (
          <div className="text-center py-8 text-gray-500">
            Aucun magasin trouvé correspondant à vos filtres.
          </div>
        )}
      </div>

      {/* Modal */}
      {showModal && (
        <div style={{background:"#8080805e"}} className="fixed inset-0  bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-20 mx-auto p-5 border w-full max-w-4xl shadow-lg rounded-md bg-white">
            <div className="mt-3">
              <h3 className="text-lg font-medium text-gray-900 mb-4">
                {editingMagasin ? 'Modifier le Magasin' : 'Nouveau Magasin'}
              </h3>
              
              <form onSubmit={handleSubmit}>
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Nom du Magasin
                    </label>
                    <input
                      type="text"
                      value={formData.name}
                      onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      required
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Responsable
                    </label>
                    <select
                      value={formData.responsable_id}
                      onChange={(e) => setFormData(prev => ({ ...prev, responsable_id: e.target.value }))}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    >
                      <option value="">Sélectionner un responsable</option>
                      {users.map((user) => (
                        <option key={user.id} value={user.id}>
                          {user.name} - {user.poste}
                        </option>
                      ))}
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Email du Magasin
                    </label>
                    <input
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      placeholder="Email général du magasin"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Téléphone
                    </label>
                    <input
                      type="text"
                      value={formData.phone}
                      onChange={(e) => setFormData(prev => ({ ...prev, phone: e.target.value }))}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>
                </div>
                
                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Adresse
                  </label>
                  <textarea
                    value={formData.address}
                    onChange={(e) => setFormData(prev => ({ ...prev, address: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    rows={3}
                  />
                </div>
                
                <div className="mb-6">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Champs Disponibles pour les Produits
                  </label>
                  <div className="grid grid-cols-4 gap-2 max-h-60 overflow-y-auto border border-gray-200 p-3 rounded-md">
                    {DEFAULT_FIELDS.map((field) => (
                      <label key={field} className="flex items-center">
                        <input
                          type="checkbox"
                          checked={formData.selected_fields.includes(field)}
                          onChange={() => handleFieldToggle(field)}
                          className="mr-2"
                        />
                        <span className="text-xs">{field}</span>
                      </label>
                    ))}
                  </div>
                </div>
                
                <div className="flex justify-end space-x-3">
                  <button
                    type="button"
                    onClick={() => setShowModal(false)}
                    className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
                  >
                    Annuler
                  </button>
                  <button
                    type="submit"
                    disabled={loading}
                    className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 disabled:opacity-50"
                  >
                    {loading ? 'Enregistrement...' : 'Enregistrer'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* Modal de filtre */}
      {showFilterModal && (
        <div style={{background:"#8080805e"}} className="fixed inset-0 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-10 mx-auto p-5 border w-full max-w-2xl shadow-lg rounded-md bg-white">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-medium text-gray-900">Filtrer les Magasins</h3>
              <button
                onClick={() => setShowFilterModal(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="h-6 w-6" />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">Responsable</label>
                <input
                  type="text"
                  className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 text-sm"
                  placeholder="Entrer le nom du responsable"
                  value={filters.responsable}
                  onChange={(e) => handleFilterChange('responsable', e.target.value)}
                />
              </div>

              <div className="flex justify-end space-x-3 pt-4">
                <button
                  onClick={clearAllFilters}
                  className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50"
                >
                  Tout effacer
                </button>
                <button
                  type="button"
                  onClick={() => setShowFilterModal(false)}
                  className="px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-md hover:bg-blue-700"
                >
                  Appliquer les filtres
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default MagasinManagement;