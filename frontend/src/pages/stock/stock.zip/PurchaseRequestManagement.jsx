import { useState, useEffect } from 'react';
import { useAuth } from '../../hooks/useAuth';
import { usePermissions } from '../../hooks/usePermissions';
import axios from 'axios';
import { Plus, FileText, Store, User, CheckCircle, XCircle, Clock, Minus, Eye, Filter, X, Search, Lock } from 'lucide-react';

const PurchaseRequestManagement = () => {
  const { user } = useAuth();
  const { hasComponentAccess, hasPermission, loading: permissionsLoading } = usePermissions();
  const [purchaseRequests, setPurchaseRequests] = useState([]);
  const [filteredRequests, setFilteredRequests] = useState([]);
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [showViewModal, setShowViewModal] = useState(false);
  const [showFilterModal, setShowFilterModal] = useState(false);
  const [selectedRequest, setSelectedRequest] = useState(null);
  const [respMagasin, setrespMagasin] = useState(null);

  // États de filtre
  const [filters, setFilters] = useState({
    status: '',
    createdBy: '',
    dateFrom: '',
    dateTo: '',
    minAmount: '',
    maxAmount: '',
    searchTerm: ''
  });
  const [activeFilters, setActiveFilters] = useState([]);

  const [formData, setFormData] = useState({
    magasin_id: user?.magasin.id || '',
    products: [{ product_id: '', quantity: 1 }],
    total_amount: 0,
    notes: '',
    created_by: user?.firstname + " " + user?.lastname || ''
  });

  // Calculer le total à chaque changement de produits
  const calculateTotal = (productsArr) => {
    return productsArr.reduce((sum, item) => {
      const qty = Number(item.quantity) || 0;
      const product = products.find(p => p.id === parseInt(item.product_id));
      const price = product ? parseFloat(product.product_data?.Prix || 0) : 0;
      return sum + qty * price;
    }, 0);
  };

  // Mettre à jour le total_amount à chaque changement de produits
  const setProductsAndTotal = (productsArr) => {
    setFormData(prev => ({
      ...prev,
      products: productsArr,
      total_amount: calculateTotal(productsArr)
    }));
  };

  useEffect(() => {
    fetchData();
    // eslint-disable-next-line
  }, []);

  useEffect(() => {
    applyFilters();
    // eslint-disable-next-line
  }, [purchaseRequests, filters]);

  const fetchData = async () => {
    try {
      setLoading(true);
      const [requestsRes, productsRes, MagasinRes] = await Promise.all([
        axios.get(`http://localhost:5000/api/purchase-requests/magasin/${user?.magasin.id}`),
        axios.get(`http://localhost:5000/api/products/magasin/${user?.magasin.id}`),
        axios.get(`http://localhost:5000/api/magasins/${user?.magasin.id}`),
      ]);
      setrespMagasin(MagasinRes.data.responsable_id)
      setPurchaseRequests(requestsRes.data);
      setProducts(productsRes.data);
    } catch (error) {
      console.error('Erreur lors de la récupération des données :', error);
      alert('Erreur lors de la récupération des données');
    } finally {
      setLoading(false);
    }
  };

  // Fonctionnalité de filtre
  const applyFilters = () => {
    let filtered = [...purchaseRequests];

    // Filtre par statut
    if (filters.status) {
      filtered = filtered.filter(req => req.status === filters.status);
    }

    // Filtre par créateur
    if (filters.createdBy) {
      filtered = filtered.filter(req =>
        req.created_by.toLowerCase().includes(filters.createdBy.toLowerCase())
      );
    }

    // Filtre par plage de dates
    if (filters.dateFrom) {
      filtered = filtered.filter(req =>
        new Date(req.created_at) >= new Date(filters.dateFrom)
      );
    }
    if (filters.dateTo) {
      filtered = filtered.filter(req =>
        new Date(req.created_at) <= new Date(filters.dateTo + 'T23:59:59')
      );
    }

    // Filtre par plage de montant
    if (filters.minAmount) {
      filtered = filtered.filter(req =>
        parseFloat(req.total_amount || 0) >= parseFloat(filters.minAmount)
      );
    }
    if (filters.maxAmount) {
      filtered = filtered.filter(req =>
        parseFloat(req.total_amount || 0) <= parseFloat(filters.maxAmount)
      );
    }

    // Filtre par terme de recherche
    if (filters.searchTerm) {
      filtered = filtered.filter(req =>
        req.id.toString().includes(filters.searchTerm) ||
        req.created_by.toLowerCase().includes(filters.searchTerm.toLowerCase()) ||
        req.notes?.toLowerCase().includes(filters.searchTerm.toLowerCase())
      );
    }

    setFilteredRequests(filtered);
    updateActiveFilters();
  };

  const updateActiveFilters = () => {
    const active = [];
    if (filters.status) active.push({ key: 'status', label: `Statut : ${filters.status}`, value: filters.status });
    if (filters.createdBy) active.push({ key: 'createdBy', label: `Créé par : ${filters.createdBy}`, value: filters.createdBy });
    if (filters.dateFrom) active.push({ key: 'dateFrom', label: `Du : ${filters.dateFrom}`, value: filters.dateFrom });
    if (filters.dateTo) active.push({ key: 'dateTo', label: `Au : ${filters.dateTo}`, value: filters.dateTo });
    if (filters.minAmount) active.push({ key: 'minAmount', label: `Min : ${filters.minAmount} €`, value: filters.minAmount });
    if (filters.maxAmount) active.push({ key: 'maxAmount', label: `Max : ${filters.maxAmount} €`, value: filters.maxAmount });
    if (filters.searchTerm) active.push({ key: 'searchTerm', label: `Recherche : ${filters.searchTerm}`, value: filters.searchTerm });
    setActiveFilters(active);
  };

  const removeFilter = (filterKey) => {
    setFilters(prev => ({ ...prev, [filterKey]: '' }));
  };

  const clearAllFilters = () => {
    setFilters({
      status: '',
      createdBy: '',
      dateFrom: '',
      dateTo: '',
      minAmount: '',
      maxAmount: '',
      searchTerm: ''
    });
  };

  const handleFilterChange = (key, value) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  // Voir les détails de la demande
  const viewRequestDetails = async (requestId) => {
    try {
      const response = await axios.get(`http://localhost:5000/api/purchase-requests/${requestId}`);
      setSelectedRequest(response.data);
      setShowViewModal(true);
    } catch (error) {
      console.error('Erreur lors de la récupération des détails de la demande :', error);
      alert('Erreur lors de la récupération des détails de la demande');
    }
  };

  const getProductDetails = (productId) => {
    return products.find(p => p.id === parseInt(productId));
  };

  const addItem = () => {
    const newProducts = [...formData.products, { product_id: '', quantity: 1 }];
    setProductsAndTotal(newProducts);
  };

  const removeItem = (index) => {
    const newProducts = formData.products.filter((_, i) => i !== index);
    setProductsAndTotal(newProducts);
  };

  const updateItem = (index, field, value) => {
    const newProducts = [...formData.products];
    newProducts[index] = { ...newProducts[index], [field]: value };
    setProductsAndTotal(newProducts);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Nettoyer le tableau des produits - supprimer les champs supplémentaires
    const cleanProducts = formData.products.map(item => ({
      product_id: item.product_id,
      quantity: item.quantity
    }));

    const submitData = {
      magasin_id: user?.magasin.id,
      products: cleanProducts,
      notes: formData.notes || '',
      created_by: user?.firstname + " " + user?.lastname
    };

    // Validation : magasin_id, tableau de produits et created_by sont requis
    if (
      !submitData.magasin.id ||
      !Array.isArray(submitData.products) ||
      submitData.products.length === 0 ||
      !submitData.created_by
    ) {
      alert('Le magasin, la liste des produits et le créateur sont obligatoires');
      return;
    }

    // Valider que chaque produit a un product_id et une quantité > 0
    for (const item of submitData.products) {
      if (!item.product_id || Number(item.quantity) <= 0) {
        alert('Chaque article doit avoir un produit sélectionné et une quantité supérieure à 0');
        return;
      }
    }

    try {
      await axios.post('http://localhost:5000/api/purchase-requests', submitData);
      alert('Demande d\'achat créée avec succès');
      setShowModal(false);
      setFormData({
        magasin_id: user?.magasin.id || '',
        products: [{ product_id: '', quantity: 1 }],
        total_amount: 0,
        notes: '',
        created_by: user?.firstname + " " + user?.lastname || ''
      });
      fetchData();
    } catch (error) {
      // Afficher une erreur plus spécifique si disponible
      let errorMsg = 'Erreur lors de la création de la demande d\'achat : ';
      if (error.response?.data?.error) {
        errorMsg += error.response.data.error;
      } else if (error.response?.data?.message) {
        errorMsg += error.response.data.message;
      } else {
        errorMsg += error.message;
      }
      alert(errorMsg);
      console.error('Erreur lors de la création de la demande d\'achat :', error);
    }
  };

  const handleStatusUpdate = async (requestId, status) => {
    try {
      await axios.patch(`http://localhost:5000/api/purchase-requests/${requestId}/approval`, {
        status,
        approved_by: user.id
      });
      alert(`Demande d'achat ${status === 'approved' ? 'approuvée' : 'rejetée'} avec succès`);
      fetchData();
    } catch (error) {
      console.error('Erreur lors de la mise à jour du statut de la demande :', error);
      alert('Erreur lors de la mise à jour du statut : ' + (error.response?.data?.error || error.message));
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'approved':
        return <CheckCircle className="h-5 w-5 text-green-600" />;
      case 'rejected':
        return <XCircle className="h-5 w-5 text-red-600" />;
      default:
        return <Clock className="h-5 w-5 text-yellow-600" />;
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'approved':
        return 'bg-green-100 text-green-800';
      case 'rejected':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-yellow-100 text-yellow-800';
    }
  };

  // Check component access
  if (permissionsLoading) {
    return <div className="p-6">Vérification des permissions...</div>;
  }

  if (!hasComponentAccess('PurchaseRequestManagement')) {
    return (
      <div className="p-6">
        <div className="flex flex-col items-center justify-center min-h-[400px]">
          <Lock className="h-16 w-16 text-gray-400 mb-4" />
          <h2 className="text-xl font-semibold text-gray-900 mb-2">Accès non autorisé</h2>
          <p className="text-gray-600 text-center">
            Vous n'avez pas les permissions nécessaires pour accéder à la gestion des demandes d'achat.
            <br />
            Veuillez contacter votre administrateur pour obtenir les droits d'accès appropriés.
          </p>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="w-full py-6 px-2 sm:px-4 lg:px-8">
      <div className="px-0 py-6 sm:px-0">
        <div className="sm:flex sm:items-center">
          <div className="sm:flex-auto">
            <h1 className="text-3xl font-bold text-gray-900">Gestion des demandes d'achat</h1>
            <p className="mt-2 text-sm text-gray-700">
              Créez et gérez les demandes d'achat pour approbation
            </p>
          </div>
          <div className="mt-4 sm:mt-0 sm:ml-16 sm:flex-none space-x-2">
            <button
              onClick={() => setShowFilterModal(true)}
              className="inline-flex items-center justify-center rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
            >
              <Filter className="h-4 w-4 mr-2" />
              Filtres
              {activeFilters.length > 0 && (
                <span className="ml-2 bg-blue-100 text-blue-800 text-xs font-medium px-2 py-1 rounded-full">
                  {activeFilters.length}
                </span>
              )}
            </button>
            {hasPermission('create_purchase_request') && (
              <button
                onClick={() => setShowModal(true)}
                className="inline-flex items-center justify-center rounded-md border border-transparent bg-blue-600 px-4 py-2 text-sm font-medium text-white shadow-sm hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 sm:w-auto"
              >
                <Plus className="h-4 w-4 mr-2" />
                Nouvelle demande
              </button>
            )}
          </div>
        </div>

        {/* Affichage des filtres actifs */}
        {activeFilters.length > 0 && (
          <div className="mt-4 flex flex-wrap gap-2 items-center">
            <span className="text-sm font-medium text-gray-700">Filtres actifs :</span>
            {activeFilters.map((filter) => (
              <span
                key={filter.key}
                className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800"
              >
                {filter.label}
                <button
                  onClick={() => removeFilter(filter.key)}
                  className="ml-2 inline-flex items-center justify-center w-4 h-4 rounded-full hover:bg-blue-200"
                >
                  <X className="h-3 w-3" />
                </button>
              </span>
            ))}
            <button
              onClick={clearAllFilters}
              className="text-sm text-gray-500 hover:text-gray-700 underline"
            >
              Tout effacer
            </button>
          </div>
        )}

        {/* Barre de recherche */}
        <div className="mt-4">
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-5 w-5 text-gray-400" />
            </div>
            <input
              type="text"
              placeholder="Rechercher par ID, créateur ou notes..."
              className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
              value={filters.searchTerm}
              onChange={(e) => handleFilterChange('searchTerm', e.target.value)}
            />
          </div>
        </div>

        <div className="mt-8 flex flex-col">
          <div className="-my-2 -mx-2 overflow-x-auto sm:-mx-4 lg:-mx-8">
            <div className="inline-block min-w-full py-2 align-middle md:px-4 lg:px-8">
              <div className="overflow-hidden shadow ring-1 ring-black ring-opacity-5 md:rounded-lg">
                <table className="min-w-full divide-y divide-gray-300">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        ID Demande
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Articles
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Montant total
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Statut
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Créé par
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Date
                      </th>
                      <th className="relative px-6 py-3">
                        <span className="sr-only">Actions</span>
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {filteredRequests.map((request) => (
                      <tr key={request.id}>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <FileText className="h-5 w-5 text-gray-400 mr-3" />
                            <div className="text-sm font-medium text-gray-900">
                              DA-{request.id}
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <div className="text-sm text-gray-900">
                            {request.products?.length || 0} article(s)
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm font-medium text-gray-900">
                            {parseFloat(request.total_amount || 0).toLocaleString('fr-FR', { style: 'currency', currency: 'EUR' })}
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            {getStatusIcon(request.status)}
                            <span className={`ml-2 inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(request.status)}`}>
                              {request.status === 'pending' ? 'En attente' : request.status === 'approved' ? 'Approuvée' : 'Rejetée'}
                            </span>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <User className="h-4 w-4 text-gray-400 mr-2" />
                            <span className="text-sm text-gray-900">
                              {request.created_by}
                            </span>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm text-gray-900">
                            {new Date(request.created_at).toLocaleDateString('fr-FR')}
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                          <div className="flex space-x-2">
                            <button
                              onClick={() => viewRequestDetails(request.id)}
                              className="text-blue-600 hover:text-blue-900"
                            >
                              <Eye className="h-4 w-4" />
                            </button>
                            {hasPermission('validate_purchase_request') && user?.id === respMagasin && request.status === 'pending' && (
                              <>
                                <button
                                  onClick={() => handleStatusUpdate(request.id, 'approved')}
                                  className="text-green-600 hover:text-green-900"
                                >
                                  Approuver
                                </button>
                                <button
                                  onClick={() => handleStatusUpdate(request.id, 'rejected')}
                                  className="text-red-600 hover:text-red-900"
                                >
                                  Rejeter
                                </button>
                              </>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                {filteredRequests.length === 0 && (
                  <div className="text-center py-8 text-gray-500">
                    Aucune demande d'achat trouvée correspondant à vos filtres.
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Modals continue in next response due to length limit */}
      </div>
    </div>
  );
};

export default PurchaseRequestManagement;