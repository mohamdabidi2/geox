import { useState, useEffect } from 'react';
import { useAuth } from '../../hooks/useAuth';
import { usePermissions } from '../../hooks/usePermissions';
import axios from 'axios';
import { Plus, Edit2, CheckCircle, XCircle, Eye, Filter, X, Search, Lock } from 'lucide-react';

const CategoryManagement = () => {
  const { user } = useAuth();
  const { hasComponentAccess, hasPermission, loading: permissionsLoading } = usePermissions();
  const [categories, setCategories] = useState([]);
  const [filteredCategories, setFilteredCategories] = useState([]);
  const [availableFields, setAvailableFields] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [showFilterModal, setShowFilterModal] = useState(false);
  const [editingCategory, setEditingCategory] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    required_fields: []
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  // États de filtre
  const [filters, setFilters] = useState({
    status: '',
    createdBy: '',
    dateFrom: '',
    dateTo: '',
    searchTerm: ''
  });
  const [activeFilters, setActiveFilters] = useState([]);

 

  useEffect(() => {
    console.log(user)
    if (user?.magasin.id) {
      fetchCategories();
      fetchAvailableFields();
    }
  }, [user]);

  useEffect(() => {
    applyFilters();
  }, [categories, filters]);

  const fetchCategories = async () => {
    try {
      const response = await axios.get(`http://localhost:5000/api/categories/magasin/${user.magasin.id}`);
      setCategories(response.data);
    } catch (error) {
      console.error('Erreur lors de la récupération des catégories :', error);
      setError('Échec de la récupération des catégories');
    }
  };

  // Fonctionnalité de filtrage
  const applyFilters = () => {
    let filtered = [...categories];

    // Filtre statut
    if (filters.status) {
      if (filters.status === 'approved') {
        filtered = filtered.filter(cat => cat.is_approved);
      } else if (filters.status === 'pending') {
        filtered = filtered.filter(cat => !cat.is_approved);
      }
    }

    // Filtre créateur
    if (filters.createdBy) {
      filtered = filtered.filter(cat => 
        cat.created_by?.toLowerCase().includes(filters.createdBy.toLowerCase())
      );
    }

    // Filtre plage de dates
    if (filters.dateFrom) {
      filtered = filtered.filter(cat => 
        new Date(cat.created_at) >= new Date(filters.dateFrom)
      );
    }
    if (filters.dateTo) {
      filtered = filtered.filter(cat => 
        new Date(cat.created_at) <= new Date(filters.dateTo + 'T23:59:59')
      );
    }

    // Filtre de recherche
    if (filters.searchTerm) {
      filtered = filtered.filter(cat => {
        const searchLower = filters.searchTerm.toLowerCase();
        return cat.name.toLowerCase().includes(searchLower) ||
               cat.created_by?.toLowerCase().includes(searchLower);
      });
    }

    setFilteredCategories(filtered);
    updateActiveFilters();
  };

  const updateActiveFilters = () => {
    const active = [];
    if (filters.status) active.push({ key: 'status', label: `Statut : ${filters.status === 'approved' ? 'Approuvée' : 'En attente'}`, value: filters.status });
    if (filters.createdBy) active.push({ key: 'createdBy', label: `Créé par : ${filters.createdBy}`, value: filters.createdBy });
    if (filters.dateFrom) active.push({ key: 'dateFrom', label: `Du : ${filters.dateFrom}`, value: filters.dateFrom });
    if (filters.dateTo) active.push({ key: 'dateTo', label: `Au : ${filters.dateTo}`, value: filters.dateTo });
    if (filters.searchTerm) active.push({ key: 'searchTerm', label: `Recherche : ${filters.searchTerm}`, value: filters.searchTerm });
    setActiveFilters(active);
  };

  const removeFilter = (filterKey) => {
    setFilters(prev => ({ ...prev, [filterKey]: '' }));
  };

  const clearAllFilters = () => {
    setFilters({
      status: '',
      createdBy: '',
      dateFrom: '',
      dateTo: '',
      searchTerm: ''
    });
  };

  const handleFilterChange = (key, value) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  const fetchAvailableFields = async () => {
    try {
      const response = await axios.get(`http://localhost:5000/api/magasins/${user.magasin.id}/fields`);
      setAvailableFields(response.data.fields);
    } catch (error) {
      console.error('Erreur lors de la récupération des champs :', error);
      setError('Échec de la récupération des champs disponibles');
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      if (editingCategory) {
        await axios.put(`http://localhost:5000/api/categories/${editingCategory.id}`, formData);
      } else {
        await axios.post('http://localhost:5000/api/categories', {
          ...formData,
          magasin_id: user.magasin.id,
          created_by: user.firstname+" "+user.lastname
        });
      }
      
      await fetchCategories();
      setShowModal(false);
      setEditingCategory(null);
      setFormData({ name: '', required_fields: [] });
    } catch (error) {
      console.error('Erreur lors de l\'enregistrement de la catégorie :', error);
      setError(error.response?.data?.error || 'Échec de l\'enregistrement de la catégorie');
    } finally {
      setLoading(false);
    }
  };

  const handleApproval = async (categoryId, isApproved) => {
    try {
      await axios.patch(`http://localhost:5000/api/categories/${categoryId}/approval`, {
        is_approved: isApproved,
        approved_by: user.username
      });
      await fetchCategories();
    } catch (error) {
      console.error('Erreur lors de la mise à jour de l\'approbation :', error);
      setError(error.response?.data?.error || 'Échec de la mise à jour de l\'approbation');
    }
  };

  const handleFieldToggle = (field) => {
    const isSelected = formData.required_fields.includes(field);
    setFormData(prev => ({
      ...prev,
      required_fields: isSelected 
        ? prev.required_fields.filter(f => f !== field)
        : [...prev.required_fields, field]
    }));
  };

  const openModal = (category = null) => {
    if (category) {
      setEditingCategory(category);
      setFormData({
        name: category.name,
        required_fields: category.required_fields || []
      });
    } else {
      setEditingCategory(null);
      setFormData({ name: '', required_fields: [] });
    }
    setShowModal(true);
  };

  // Ajout d'un état de chargement ou rendu conditionnel
  if (!user || !user.magasin.id) {
    return <div className="p-6">Chargement...</div>;
  }
 // Check component access
 if (permissionsLoading) {
  return <div className="p-6">Vérification des permissions...</div>;
}

if (!hasComponentAccess('CategoryManagement')) {
  return (
    <div className="p-6">
      <div className="flex flex-col items-center justify-center min-h-[400px]">
        <Lock className="h-16 w-16 text-gray-400 mb-4" />
        <h2 className="text-xl font-semibold text-gray-900 mb-2">Accès non autorisé</h2>
        <p className="text-gray-600 text-center">
          Vous n'avez pas les permissions nécessaires pour accéder à la gestion des catégories.
          <br />
          Veuillez contacter votre administrateur pour obtenir les droits d'accès appropriés.
        </p>
      </div>
    </div>
  );
}
  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Gestion des Catégories</h1>
          <p className="mt-2 text-sm text-gray-700">
            Gérez les catégories et leurs champs requis
          </p>
        </div>
        <div className="flex space-x-2">
          <button
            onClick={() => setShowFilterModal(true)}
            className="inline-flex items-center justify-center rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
          >
            <Filter className="h-4 w-4 mr-2" />
            Filtres
            {activeFilters.length > 0 && (
              <span className="ml-2 bg-blue-100 text-blue-800 text-xs font-medium px-2 py-1 rounded-full">
                {activeFilters.length}
              </span>
            )}
          </button>
          {hasPermission('create_category') && (
            <button
              onClick={() => openModal()}
              className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg flex items-center space-x-2"
            >
              <Plus className="h-4 w-4" />
              <span>Nouvelle Catégorie</span>
            </button>
          )}
        </div>
      </div>

      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
          {error}
        </div>
      )}

      {/* Affichage des filtres actifs */}
      {activeFilters.length > 0 && (
        <div className="mt-4 flex flex-wrap gap-2 items-center">
          <span className="text-sm font-medium text-gray-700">Filtres actifs :</span>
          {activeFilters.map((filter) => (
            <span
              key={filter.key}
              className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800"
            >
              {filter.label}
              <button
                onClick={() => removeFilter(filter.key)}
                className="ml-2 inline-flex items-center justify-center w-4 h-4 rounded-full hover:bg-blue-200"
              >
                <X className="h-3 w-3" />
              </button>
            </span>
          ))}
          <button
            onClick={clearAllFilters}
            className="text-sm text-gray-500 hover:text-gray-700 underline"
          >
            Tout effacer
          </button>
        </div>
      )}

      {/* Barre de recherche */}
      <div className="mt-4">
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search className="h-5 w-5 text-gray-400" />
          </div>
          <input
            type="text"
            placeholder="Rechercher par nom ou créateur..."
            className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
            value={filters.searchTerm}
            onChange={(e) => handleFilterChange('searchTerm', e.target.value)}
          />
        </div>
      </div>

      <div className="bg-white shadow rounded-lg overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Nom
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Champs Requis
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Statut
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Créé par
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {filteredCategories.map((category) => (
              <tr key={category.id}>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                  {category.name}
                </td>
                <td className="px-6 py-4 text-sm text-gray-500">
                  <span className="text-xs bg-gray-100 px-2 py-1 rounded">
                    {category.required_fields?.length || 0} champs
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {category.is_approved ? (
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                      <CheckCircle className="h-3 w-3 mr-1" />
                      Approuvée
                    </span>
                  ) : (
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                      <XCircle className="h-3 w-3 mr-1" />
                      En attente
                    </span>
                  )}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {category.created_by}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  <div className="flex space-x-2">
                    <button
                      onClick={() => openModal(category)}
                      className="text-indigo-600 hover:text-indigo-900"
                    >
                      <Edit2 className="h-4 w-4" />
                    </button>
                    
                    {hasPermission('validate_category') && !category.is_approved && (
                      <>
                        <button
                          onClick={() => handleApproval(category.id, true)}
                          className="text-green-600 hover:text-green-900"
                        >
                          <CheckCircle className="h-4 w-4" />
                        </button>
                        <button
                          onClick={() => handleApproval(category.id, false)}
                          className="text-red-600 hover:text-red-900"
                        >
                          <XCircle className="h-4 w-4" />
                        </button>
                      </>
                    )}
                    
                    <button className="text-blue-600 hover:text-blue-900">
                      <Eye className="h-4 w-4" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {filteredCategories.length === 0 && (
          <div className="text-center py-8 text-gray-500">
            Aucune catégorie trouvée correspondant à vos filtres.
          </div>
        )}
      </div>

      {/* Modal */}
      {showModal && (
        <div style={{background:"#8080805e"}} className="fixed inset-0 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-20 mx-auto p-5 border w-full max-w-2xl shadow-lg rounded-md bg-white">
            <div className="mt-3">
              <h3 className="text-lg font-medium text-gray-900 mb-4">
                {editingCategory ? 'Modifier la Catégorie' : 'Nouvelle Catégorie'}
              </h3>
              
              <form onSubmit={handleSubmit}>
                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Nom de la Catégorie
                  </label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    required
                  />
                </div>
                
                <div className="mb-6">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Champs Requis
                  </label>
                  <div className="grid grid-cols-3 gap-2 max-h-60 overflow-y-auto">
                    {availableFields.map((field) => (
                      <label key={field} className="flex items-center">
                        <input
                          type="checkbox"
                          checked={formData.required_fields.includes(field)}
                          onChange={() => handleFieldToggle(field)}
                          className="mr-2"
                        />
                        <span className="text-sm">{field}</span>
                      </label>
                    ))}
                  </div>
                </div>
                
                <div className="flex justify-end space-x-3">
                  <button
                    type="button"
                    onClick={() => setShowModal(false)}
                    className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
                  >
                    Annuler
                  </button>
                  <button
                    type="submit"
                    disabled={loading}
                    className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 disabled:opacity-50"
                  >
                    {loading ? 'Enregistrement...' : 'Enregistrer'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* Modal de filtre */}
      {showFilterModal && (
        <div style={{background:"#8080805e"}} className="fixed inset-0  bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-10 mx-auto p-5 border w-full max-w-2xl shadow-lg rounded-md bg-white">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-medium text-gray-900">Filtrer les catégories</h3>
              <button
                onClick={() => setShowFilterModal(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="h-6 w-6" />
              </button>
            </div>

            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Statut</label>
                  <select
                    className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 text-sm"
                    value={filters.status}
                    onChange={(e) => handleFilterChange('status', e.target.value)}
                  >
                    <option value="">Tous les statuts</option>
                    <option value="approved">Approuvée</option>
                    <option value="pending">En attente</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Créé par</label>
                  <input
                    type="text"
                    className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 text-sm"
                    placeholder="Nom du créateur"
                    value={filters.createdBy}
                    onChange={(e) => handleFilterChange('createdBy', e.target.value)}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Date de début</label>
                  <input
                    type="date"
                    className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 text-sm"
                    value={filters.dateFrom}
                    onChange={(e) => handleFilterChange('dateFrom', e.target.value)}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Date de fin</label>
                  <input
                    type="date"
                    className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 text-sm"
                    value={filters.dateTo}
                    onChange={(e) => handleFilterChange('dateTo', e.target.value)}
                  />
                </div>
              </div>

              <div className="flex justify-end space-x-3 pt-4">
                <button
                  onClick={clearAllFilters}
                  className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50"
                >
                  Tout effacer
                </button>
                <button
                  onClick={() => setShowFilterModal(false)}
                  className="px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-md hover:bg-blue-700"
                >
                  Appliquer les filtres
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CategoryManagement;