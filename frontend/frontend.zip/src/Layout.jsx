import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { 
  Grid3X3, 
  BarChart3, 
  FileText, 
  HelpCircle, 
  Settings,
  Home,
  Users,
  Zap,
  Package
} from 'lucide-react';
import Sidebar from './pages/shared/Sidebar';

// Import the logo - make sure you have a logo file in your assets folder
import Logo from './assets/logo.png';

const Layout = ({ children }) => {
  const navigate = useNavigate();
  const location = useLocation();

  // Define navigation items with correct paths
  const getNavigationItems = () => {
    const currentPath = location.pathname;

    const baseItems = [
      { 
        icon: Home, 
        label: 'Dashboard',
        active: currentPath === '/dashboard',
        onClick: () => navigate('/dashboard')
      },
      { 
        icon: Grid3X3, 
        label: 'Modules',
        active: currentPath === '/Modules',
        onClick: () => navigate('/Modules')
      },
      { 
        icon: Users, 
        label: 'Users',
        active: currentPath === '/admin/users',
        onClick: () => navigate('/admin/users')
      },
      { 
        icon: Package, 
        label: 'Stock',
        active: currentPath === '/stock',
        onClick: () => navigate('/admin/stock-menu')
      }
    ];

    return baseItems;
  };

  const getSupportItems = () => {
    return [
      { 
        icon: HelpCircle, 
        label: 'Help Center',
        onClick: () => console.log('Help Center clicked')
      },
      { 
        icon: Settings, 
        label: 'Settings',
        onClick: () => console.log('Settings clicked')
      }
    ];
  };

  const getActiveItem = () => {
    const currentPath = location.pathname;
    if (currentPath === '/dashboard') return 'Dashboard';
    if (currentPath === '/admin/stock-menu') return 'Modules';
    if (currentPath === '/admin/users') return 'Users';
    if (currentPath === '/stock') return 'Stock';
    return '';
  };

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Sidebar */}
      <Sidebar 
        logo={Logo}
        navigationItems={getNavigationItems()}
        supportItems={getSupportItems()}
        activeItem={getActiveItem()}
      />

      {/* Main Content */}
      <div className="flex-1 flex flex-col ml-72">
        {children}
      </div>
    </div>
  );
};

export default Layout;