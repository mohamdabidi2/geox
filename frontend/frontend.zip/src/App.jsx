import { BrowserRouter as Router, Routes, Route, Navigate, useNavigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './hooks/useAuth';
import LoginPage from './pages/LoginPage';
import EmailVerificationPage from './pages/EmailVerificationPage';
import PasswordCreationPage from './pages/PasswordCreationPage';
import DashboardPage from './pages/DashboardPage';
import UserManagement from './pages/Users/userManagement';
import Layout from './Layout';
import './App.css';
import MagasinManagement from './pages/stock/MagasinManagement';
import CategoryManagement from './pages/stock/CategoryManagement';
import ProductManagement from './pages/stock/ProductManagement';
import SupplierManagement from './pages/stock/SupplierManagement';
import PurchaseRequestManagement from './pages/stock/PurchaseRequestManagement';
import PurchaseOrderManagement from './pages/stock/PurchaseOrderManagement';
import StockManagement from './pages/stock/StockManagement';
import StockCards from './pages/stock/Layer';
import PostManagement from './pages/postes/PostManagement';

// Protected Route Component
function ProtectedRoute({ children }) {
  const { isAuthenticated, isFullyVerified, loading, user } = useAuth();
  const navigate = useNavigate();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-gray-900"></div>
      </div>
    );
  }

  // Check if token exists first, then check user authentication
  const token = localStorage.getItem('token');
  
  if (!token) {
    return <Navigate to="/login" replace />;
  }

  // If we have a token but user data isn't loaded yet, show loading
  if (token && !user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-gray-900"></div>
      </div>
    );
  }
  if (!isFullyVerified()) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-md w-full text-center">
          <div className="bg-white shadow rounded-lg p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Account Pending Approval</h2>
            <p className="text-gray-600 mb-4">
              Your profile is not yet fully validated. Please wait until RH and Direction confirm it.
            </p>
            <button
              onClick={() => {
                // Force re-check of authentication status
                // This will trigger a re-render and re-evaluation of ProtectedRoute
                navigate(0); // This is a soft refresh without full page reload
              }}
              className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
            >
              Refresh Status
            </button>
          </div>
        </div>
      </div>
    );
  }
  return children;
}

// Public Route Component (redirect if already authenticated)
function PublicRoute({ children }) {
  const { isFullyVerified, loading, user } = useAuth();
  const token = localStorage.getItem('token');

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-gray-900"></div>
      </div>
    );
  }

  // Only redirect if we have both token and verified user
  if (token && user && isFullyVerified()) {
    return <Navigate to="/dashboard" replace />;
  }

  return children;
}

function AppRoutes() {
  return (
    <Routes>
      <Route 
        path="/login" 
        element={
          <PublicRoute>
            <LoginPage />
          </PublicRoute>
        } 
      />
      <Route 
        path="/email-verification" 
        element={<EmailVerificationPage />} 
      />
      <Route 
        path="/verify-email/:token" 
        element={<PasswordCreationPage />} 
      />
      <Route 
        path="/dashboard" 
        element={
          <ProtectedRoute>
            <Layout>
              <DashboardPage />
            </Layout>
          </ProtectedRoute>
        } 
      />
      <Route path="/" element={<Navigate to="/login" replace />} />
      <Route 
        path="/admin/users" 
        element={
          <ProtectedRoute>
            <Layout>
              <UserManagement />
            </Layout>
          </ProtectedRoute>
        } 
      />



<Route path="/magasins" element={
  <ProtectedRoute>
    <Layout>
      <MagasinManagement />
    </Layout>
  </ProtectedRoute>
} />
<Route path="/categories" element={
  <ProtectedRoute>
    <Layout>
      <CategoryManagement />
    </Layout>
  </ProtectedRoute>
} />
<Route path="/products" element={
  <ProtectedRoute>
    <Layout>
      <ProductManagement />
    </Layout>
  </ProtectedRoute>
} />
<Route path="/suppliers" element={
  <ProtectedRoute>
    <Layout>
      <SupplierManagement />
    </Layout>
  </ProtectedRoute>
} />
<Route path="/admin/stock-menu" element={
  <ProtectedRoute>
    <Layout>
      <StockCards />
    </Layout>
  </ProtectedRoute>
} />
<Route path="/admin/Posts" element={
  <ProtectedRoute>
    <Layout>
      <PostManagement />
    </Layout>
  </ProtectedRoute>
} />
<Route path="/Modules" element={
  <ProtectedRoute>
    <Layout>
      <StockCards />
    </Layout>
  </ProtectedRoute>
} />
<Route path="/purchase-requests" element={
  <ProtectedRoute>
    <Layout>
      <PurchaseRequestManagement />
    </Layout>
  </ProtectedRoute>
} />
<Route path="/purchase-orders" element={
  <ProtectedRoute>
    <Layout>
      <PurchaseOrderManagement />
    </Layout>
  </ProtectedRoute>
} />
<Route path="/stock" element={
  <ProtectedRoute>
    <Layout>
      <StockManagement />
    </Layout>
  </ProtectedRoute>
} />


      <Route path="*" element={<Navigate to="/login" replace />} />
     
    </Routes>
  );
}

function App() {
  return (
    <AuthProvider>
      <Router>
        <div className="App">
          <AppRoutes />
        </div>
      </Router>
    </AuthProvider>
  );
}

export default App;


