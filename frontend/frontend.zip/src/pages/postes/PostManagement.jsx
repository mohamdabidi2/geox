import { useState, useEffect } from 'react';
import { useAuth } from '../../hooks/useAuth';
import axios from 'axios';
import { Plus, Users, Settings, Eye, Edit2, Trash2, Move, Filter, X, Search } from 'lucide-react';
import HierarchicalPostView from './HierarchicalPostView';
import PostPermissionModal from './PostPermissionModal';
import modulesConfig from './modules-config.json';

const PostManagement = () => {
  const { user } = useAuth();
  const [posts, setPosts] = useState([]);
  const [filteredPosts, setFilteredPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [showPermissionModal, setShowPermissionModal] = useState(false);
  const [showFilterModal, setShowFilterModal] = useState(false);
  const [showHierarchicalView, setShowHierarchicalView] = useState(false);
  const [editingPost, setEditingPost] = useState(null);
  const [selectedPost, setSelectedPost] = useState(null);
  const [error, setError] = useState('');
  const [actionLoading, setActionLoading] = useState(false);

  const [formData, setFormData] = useState({
    name: '',
    description: '',
    actions: [],
    parent_id: null,
    position_top: 100,
    position_left: 100,
    position_right: 0,
    position_bottom: 0
  });

  // Filter states
  const [filters, setFilters] = useState({
    name: '',
    hasActions: '',
    parentPost: '',
    searchTerm: ''
  });
  const [activeFilters, setActiveFilters] = useState([]);

  useEffect(() => {
    fetchPosts();
  }, []);

  useEffect(() => {
    applyFilters();
  }, [posts, filters]);

  const fetchPosts = async () => {
    try {
      setLoading(true);
      const response = await axios.get('http://localhost:5000/api/posts');
      setPosts(response.data);
    } catch (error) {
      console.error('Error fetching posts:', error);
      setError('Failed to fetch posts');
    } finally {
      setLoading(false);
    }
  };

  // Filter functionality
  const applyFilters = () => {
    let filtered = [...posts];

    if (filters.name) {
      filtered = filtered.filter(post => 
        post.name.toLowerCase().includes(filters.name.toLowerCase())
      );
    }

    if (filters.hasActions) {
      if (filters.hasActions === 'yes') {
        filtered = filtered.filter(post => post.actions && post.actions.length > 0);
      } else if (filters.hasActions === 'no') {
        filtered = filtered.filter(post => !post.actions || post.actions.length === 0);
      }
    }

    if (filters.parentPost) {
      filtered = filtered.filter(post => {
        const parentPost = posts.find(p => p.id === post.parent_id);
        return parentPost && parentPost.name.toLowerCase().includes(filters.parentPost.toLowerCase());
      });
    }

    if (filters.searchTerm) {
      filtered = filtered.filter(post => {
        const searchLower = filters.searchTerm.toLowerCase();
        return post.name.toLowerCase().includes(searchLower) ||
               post.description?.toLowerCase().includes(searchLower);
      });
    }

    setFilteredPosts(filtered);
    updateActiveFilters();
  };

  const updateActiveFilters = () => {
    const active = [];
    if (filters.name) active.push({ key: 'name', label: `Name: ${filters.name}`, value: filters.name });
    if (filters.hasActions) active.push({ key: 'hasActions', label: `Has Actions: ${filters.hasActions}`, value: filters.hasActions });
    if (filters.parentPost) active.push({ key: 'parentPost', label: `Parent: ${filters.parentPost}`, value: filters.parentPost });
    if (filters.searchTerm) active.push({ key: 'searchTerm', label: `Search: ${filters.searchTerm}`, value: filters.searchTerm });
    setActiveFilters(active);
  };

  const removeFilter = (filterKey) => {
    setFilters(prev => ({ ...prev, [filterKey]: '' }));
  };

  const clearAllFilters = () => {
    setFilters({
      name: '',
      hasActions: '',
      parentPost: '',
      searchTerm: ''
    });
  };

  const handleFilterChange = (key, value) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setActionLoading(true);
    setError('');

    try {
      const payload = {
        ...formData,
        created_by: user?.username || user?.email || 'Unknown'
      };

      if (editingPost) {
        await axios.put(`http://localhost:5000/api/posts/${editingPost.id}`, payload);
      } else {
        await axios.post('http://localhost:5000/api/posts', payload);
      }

      await fetchPosts();
      setShowModal(false);
      resetForm();
    } catch (error) {
      console.error('Error saving post:', error);
      setError(error.response?.data?.error || 'Failed to save post');
    } finally {
      setActionLoading(false);
    }
  };

  const handleDelete = async (postId) => {
    if (!window.confirm('Are you sure you want to delete this post?')) return;

    try {
      setActionLoading(true);
      await axios.delete(`http://localhost:5000/api/posts/${postId}`);
      await fetchPosts();
    } catch (error) {
      console.error('Error deleting post:', error);
      setError('Failed to delete post');
    } finally {
      setActionLoading(false);
    }
  };

  const handlePositionUpdate = async (postId, position) => {
    try {
      await axios.patch(`http://localhost:5000/api/posts/${postId}/position`, position);
      await fetchPosts();
    } catch (error) {
      console.error('Error updating position:', error);
      setError('Failed to update position');
    }
  };

  const resetForm = () => {
    setFormData({
      name: '',
      description: '',
      actions: [],
      parent_id: null,
      position_top: 100,
      position_left: 100,
      position_right: 0,
      position_bottom: 0
    });
    setEditingPost(null);
  };

  const openModal = (post = null) => {
    if (post) {
      setEditingPost(post);
      setFormData({
        name: post.name,
        description: post.description || '',
        actions: post.actions || [],
        parent_id: post.parent_id,
        position_top: post.position_top || 100,
        position_left: post.position_left || 100,
        position_right: post.position_right || 0,
        position_bottom: post.position_bottom || 0
      });
    } else {
      resetForm();
    }
    setShowModal(true);
  };

  const openPermissionModal = (post) => {
    setSelectedPost(post);
    setShowPermissionModal(true);
  };

  const getParentPostName = (parentId) => {
    const parent = posts.find(p => p.id === parentId);
    return parent ? parent.name : 'None';
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="w-full py-6 px-2 sm:px-4 lg:px-8">
      <div className="px-0 py-6">
        {error && (
          <div className="mb-4 p-3 rounded bg-red-100 text-red-700 border border-red-200">
            {error}
          </div>
        )}

        <div className="sm:flex sm:items-center">
          <div className="sm:flex-auto">
            <h1 className="text-3xl font-bold text-gray-900">Gestion des Postes</h1>
            <p className="mt-2 text-sm text-gray-700">
              Manage organizational posts with hierarchical structure and permissions
            </p>
          </div>
          <div className="mt-4 sm:mt-0 sm:ml-16 sm:flex-none space-x-2">
            <button
              onClick={() => setShowHierarchicalView(!showHierarchicalView)}
              className="inline-flex items-center justify-center rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
            >
              <Move className="h-4 w-4 mr-2" />
              {showHierarchicalView ? 'Table View' : 'Hierarchical View'}
            </button>
            <button
              onClick={() => setShowFilterModal(true)}
              className="inline-flex items-center justify-center rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
            >
              <Filter className="h-4 w-4 mr-2" />
              Filters
              {activeFilters.length > 0 && (
                <span className="ml-2 bg-blue-100 text-blue-800 text-xs font-medium px-2 py-1 rounded-full">
                  {activeFilters.length}
                </span>
              )}
            </button>
            <button
              onClick={() => openModal()}
              className="inline-flex items-center justify-center rounded-md border border-transparent bg-blue-600 px-4 py-2 text-sm font-medium text-white shadow-sm hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 sm:w-auto"
            >
              <Plus className="h-4 w-4 mr-2" />
              Nouveau Poste
            </button>
          </div>
        </div>

        {/* Active Filters Display */}
        {activeFilters.length > 0 && (
          <div className="mt-4 flex flex-wrap gap-2 items-center">
            <span className="text-sm font-medium text-gray-700">Active filters:</span>
            {activeFilters.map((filter) => (
              <span
                key={filter.key}
                className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800"
              >
                {filter.label}
                <button
                  onClick={() => removeFilter(filter.key)}
                  className="ml-2 inline-flex items-center justify-center w-4 h-4 rounded-full hover:bg-blue-200"
                >
                  <X className="h-3 w-3" />
                </button>
              </span>
            ))}
            <button
              onClick={clearAllFilters}
              className="text-sm text-gray-500 hover:text-gray-700 underline"
            >
              Clear all
            </button>
          </div>
        )}

        {/* Search Bar */}
        <div className="mt-4">
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-5 w-5 text-gray-400" />
            </div>
            <input
              type="text"
              placeholder="Search by post name or description..."
              className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
              value={filters.searchTerm}
              onChange={(e) => handleFilterChange('searchTerm', e.target.value)}
            />
          </div>
        </div>

        {/* Hierarchical View */}
        {showHierarchicalView ? (
          <HierarchicalPostView
            posts={filteredPosts}
            onPositionUpdate={handlePositionUpdate}
            onEdit={openModal}
            onDelete={handleDelete}
            onManagePermissions={openPermissionModal}
          />
        ) : (
          /* Table View */
          <div className="mt-8 w-full">
            <div className="flex flex-col">
              <div className="-my-2 -mx-2 overflow-x-auto">
                <div className="inline-block min-w-full py-2 align-middle px-2">
                  <div className="overflow-x-auto shadow ring-1 ring-black ring-opacity-5 rounded-lg">
                    <table className="min-w-full divide-y divide-gray-300">
                      <thead className="bg-gray-50">
                        <tr>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Nom du Poste
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Description
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Actions Assignées
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Poste Parent
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Position
                          </th>
                          <th className="relative px-6 py-3">
                            <span className="sr-only">Actions</span>
                          </th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-gray-200">
                        {filteredPosts.map((post) => (
                          <tr key={post.id}>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="flex items-center">
                                <Users className="h-5 w-5 text-gray-400 mr-3" />
                                <div className="text-sm font-medium text-gray-900">
                                  {post.name}
                                </div>
                              </div>
                            </td>
                            <td className="px-6 py-4">
                              <div className="text-sm text-gray-900 max-w-xs truncate">
                                {post.description || 'No description'}
                              </div>
                            </td>
                            <td className="px-6 py-4">
                              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                                {post.actions ? post.actions.length : 0} actions
                              </span>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                              {getParentPostName(post.parent_id)}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                              <div className="text-xs">
                                Top: {post.position_top}, Left: {post.position_left}
                              </div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                              <div className="flex space-x-2">
                                <button
                                  onClick={() => openPermissionModal(post)}
                                  className="text-green-600 hover:text-green-900"
                                  title="Manage Permissions"
                                >
                                  <Settings className="h-4 w-4" />
                                </button>
                                <button
                                  onClick={() => openModal(post)}
                                  className="text-indigo-600 hover:text-indigo-900"
                                  title="Edit Post"
                                >
                                  <Edit2 className="h-4 w-4" />
                                </button>
                                <button
                                  onClick={() => handleDelete(post.id)}
                                  className="text-red-600 hover:text-red-900"
                                  title="Delete Post"
                                  disabled={actionLoading}
                                >
                                  <Trash2 className="h-4 w-4" />
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                    {filteredPosts.length === 0 && (
                      <div className="text-center py-8 text-gray-500">
                        No posts found matching your filters.
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Create/Edit Post Modal */}
        {showModal && (
          <div style={{background:"#8080805e"}} className="fixed inset-0 bg-opacity-50 overflow-y-auto h-full w-full z-50">
            <div className="relative top-20 mx-auto p-5 border w-full max-w-2xl shadow-lg rounded-md bg-white">
              <div className="mt-3">
                <h3 className="text-lg font-medium text-gray-900 mb-4">
                  {editingPost ? 'Modifier le Poste' : 'Nouveau Poste'}
                </h3>
                
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Nom du Poste
                    </label>
                    <input
                      type="text"
                      required
                      className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      disabled={actionLoading}
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Description
                    </label>
                    <textarea
                      rows={3}
                      className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                      value={formData.description}
                      onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                      disabled={actionLoading}
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Poste Parent
                    </label>
                    <select
                      className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                      value={formData.parent_id || ''}
                      onChange={(e) => setFormData({ ...formData, parent_id: e.target.value || null })}
                      disabled={actionLoading}
                    >
                      <option value="">Aucun parent</option>
                      {posts.filter(p => p.id !== editingPost?.id).map((post) => (
                        <option key={post.id} value={post.id}>
                          {post.name}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700">
                        Position Top
                      </label>
                      <input
                        type="number"
                        min="0"
                        className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                        value={formData.position_top}
                        onChange={(e) => setFormData({ ...formData, position_top: parseInt(e.target.value) })}
                        disabled={actionLoading}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">
                        Position Left
                      </label>
                      <input
                        type="number"
                        min="0"
                        className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                        value={formData.position_left}
                        onChange={(e) => setFormData({ ...formData, position_left: parseInt(e.target.value) })}
                        disabled={actionLoading}
                      />
                    </div>
                  </div>

                  <div className="flex justify-end space-x-3 pt-4">
                    <button
                      type="button"
                      onClick={() => setShowModal(false)}
                      className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50"
                      disabled={actionLoading}
                    >
                      Annuler
                    </button>
                    <button
                      type="submit"
                      className={`px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 ${actionLoading ? 'opacity-50 pointer-events-none' : ''}`}
                      disabled={actionLoading}
                    >
                      {actionLoading ? 'Enregistrement...' : 'Enregistrer'}
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        )}

        {/* Permission Management Modal */}
        {showPermissionModal && selectedPost && (
          <PostPermissionModal
            post={selectedPost}
            modulesConfig={modulesConfig}
            onClose={() => {
              setShowPermissionModal(false);
              setSelectedPost(null);
            }}
            onSave={async (actions) => {
              try {
                await axios.patch(`http://localhost:5000/api/posts/${selectedPost.id}/actions`, { actions });
                await fetchPosts();
                setShowPermissionModal(false);
                setSelectedPost(null);
              } catch (error) {
                console.error('Error updating actions:', error);
                setError('Failed to update actions');
              }
            }}
          />
        )}

        {/* Filter Modal */}
        {showFilterModal && (
          <div style={{background:"#8080805e"}} className="fixed inset-0 bg-opacity-50 overflow-y-auto h-full w-full z-50">
            <div className="relative top-10 mx-auto p-5 border w-full max-w-2xl shadow-lg rounded-md bg-white">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-medium text-gray-900">Filter Posts</h3>
                <button
                  onClick={() => setShowFilterModal(false)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <X className="h-6 w-6" />
                </button>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Post Name</label>
                  <input
                    type="text"
                    className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 text-sm"
                    placeholder="Enter post name"
                    value={filters.name}
                    onChange={(e) => handleFilterChange('name', e.target.value)}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Has Actions</label>
                    <select
                      className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 text-sm"
                      value={filters.hasActions}
                      onChange={(e) => handleFilterChange('hasActions', e.target.value)}
                    >
                      <option value="">All Posts</option>
                      <option value="yes">With Actions</option>
                      <option value="no">Without Actions</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Parent Post</label>
                    <input
                      type="text"
                      className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 text-sm"
                      placeholder="Enter parent post name"
                      value={filters.parentPost}
                      onChange={(e) => handleFilterChange('parentPost', e.target.value)}
                    />
                  </div>
                </div>

                <div className="flex justify-end space-x-3 pt-4">
                  <button
                    onClick={clearAllFilters}
                    className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50"
                  >
                    Clear All
                  </button>
                  <button
                    onClick={() => setShowFilterModal(false)}
                    className="px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-md hover:bg-blue-700"
                  >
                    Apply Filters
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default PostManagement;