import React, { useState, useEffect } from 'react'; // Add React import
import { useAuth } from '../../hooks/useAuth';
import axios from 'axios';
import { Plus, Building2, User, Eye, Filter, X, Search, Mail, Phone, MapPin, Globe, Edit, Trash2, MessageCircle, Video, Linkedin, ExternalLink, Minus } from 'lucide-react';
const SupplierManagement = () => {
  const { user } = useAuth();
  const [suppliers, setSuppliers] = useState([]);
  const [filteredSuppliers, setFilteredSuppliers] = useState([]);
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [showViewModal, setShowViewModal] = useState(false);
  const [showFilterModal, setShowFilterModal] = useState(false);
  const [selectedSupplier, setSelectedSupplier] = useState(null);
  const [editMode, setEditMode] = useState(false);
  
  // Filter states
  const [filters, setFilters] = useState({
    country: '',
    createdBy: '',
    dateFrom: '',
    dateTo: '',
    contactType: '',
    searchTerm: ''
  });
  const [activeFilters, setActiveFilters] = useState([]);

  const [formData, setFormData] = useState({
    magasin_id: user?.magasin_id || '',
    name: '',
    country: '',
    address: '',
    contacts: [], // Changed from contact_types to contacts array
    created_by_user_id: user?.id || ''
  });

  const contactTypeOptions = [
    { type: 'Email', icon: Mail, placeholder: 'example@company.com', inputType: 'email' },
    { type: 'Phone', icon: Phone, placeholder: '+1234567890', inputType: 'tel' },

  ];

  const countryOptions = [
    'Algeria', 'Morocco', 'Tunisia', 'Egypt', 'Libya',
    'France', 'Germany', 'Italy', 'Spain', 'UK',
    'USA', 'Canada', 'China', 'Japan', 'India',
    'Turkey', 'UAE', 'Saudi Arabia', 'Other'
  ];

  useEffect(() => {
    fetchData();
    // eslint-disable-next-line
  }, []);

  useEffect(() => {
    applyFilters();
    // eslint-disable-next-line
  }, [suppliers, filters]);

  const fetchData = async () => {
    try {
      setLoading(true);
      const [suppliersRes, usersRes] = await Promise.all([
        axios.get(`http://localhost:5000/api/suppliers/magasin/${user?.magasin_id}`),
        axios.get('http://localhost:5000/api/suppliers/users')
      ]);
      
      // Transform suppliers data to handle both old and new contact format
      const transformedSuppliers = suppliersRes.data.map(supplier => ({
        ...supplier,
        contacts: supplier.contacts || transformLegacyContacts(supplier)
      }));
      
      setSuppliers(transformedSuppliers);
      setUsers(usersRes.data);
    } catch (error) {
      console.error('Error fetching data:', error);
      alert('Error fetching data');
    } finally {
      setLoading(false);
    }
  };

  // Transform legacy contact data to new format
  const transformLegacyContacts = (supplier) => {
    const contacts = [];
    if (supplier.email) {
      contacts.push({ type: 'Email', value: supplier.email });
    }
    if (supplier.phone) {
      contacts.push({ type: 'Phone', value: supplier.phone });
    }
    // Add contact types without values as placeholders
    if (supplier.contact_types && Array.isArray(supplier.contact_types)) {
      supplier.contact_types.forEach(type => {
        if (!contacts.find(c => c.type === type)) {
          contacts.push({ type, value: '' });
        }
      });
    }
    return contacts;
  };

  // Filter functionality
  const applyFilters = () => {
    let filtered = [...suppliers];

    // Country filter
    if (filters.country) {
      filtered = filtered.filter(supplier => 
        supplier.country?.toLowerCase().includes(filters.country.toLowerCase())
      );
    }

    // Created by filter
    if (filters.createdBy) {
      filtered = filtered.filter(supplier => 
        supplier.created_by.toLowerCase().includes(filters.createdBy.toLowerCase())
      );
    }

    // Date range filter
    if (filters.dateFrom) {
      filtered = filtered.filter(supplier => 
        new Date(supplier.created_at) >= new Date(filters.dateFrom)
      );
    }
    if (filters.dateTo) {
      filtered = filtered.filter(supplier => 
        new Date(supplier.created_at) <= new Date(filters.dateTo + 'T23:59:59')
      );
    }

    // Contact type filter
    if (filters.contactType) {
      filtered = filtered.filter(supplier => 
        supplier.contacts?.some(contact => contact.type === filters.contactType && contact.value)
      );
    }

    // Search term filter
    if (filters.searchTerm) {
      filtered = filtered.filter(supplier => {
        const searchLower = filters.searchTerm.toLowerCase();
        return supplier.name.toLowerCase().includes(searchLower) ||
               supplier.address?.toLowerCase().includes(searchLower) ||
               supplier.country?.toLowerCase().includes(searchLower) ||
               supplier.contacts?.some(contact => 
                 contact.value?.toLowerCase().includes(searchLower)
               );
      });
    }

    setFilteredSuppliers(filtered);
    updateActiveFilters();
  };

  const updateActiveFilters = () => {
    const active = [];
    if (filters.country) active.push({ key: 'country', label: `Country: ${filters.country}`, value: filters.country });
    if (filters.createdBy) active.push({ key: 'createdBy', label: `Created by: ${filters.createdBy}`, value: filters.createdBy });
    if (filters.dateFrom) active.push({ key: 'dateFrom', label: `From: ${filters.dateFrom}`, value: filters.dateFrom });
    if (filters.dateTo) active.push({ key: 'dateTo', label: `To: ${filters.dateTo}`, value: filters.dateTo });
    if (filters.contactType) active.push({ key: 'contactType', label: `Contact: ${filters.contactType}`, value: filters.contactType });
    if (filters.searchTerm) active.push({ key: 'searchTerm', label: `Search: ${filters.searchTerm}`, value: filters.searchTerm });
    setActiveFilters(active);
  };

  const removeFilter = (filterKey) => {
    setFilters(prev => ({ ...prev, [filterKey]: '' }));
  };

  const clearAllFilters = () => {
    setFilters({
      country: '',
      createdBy: '',
      dateFrom: '',
      dateTo: '',
      contactType: '',
      searchTerm: ''
    });
  };

  const handleFilterChange = (key, value) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  // Contact management functions
  const addContact = () => {
    setFormData(prev => ({
      ...prev,
      contacts: [...prev.contacts, { type: '', value: '' }]
    }));
  };

  const removeContact = (index) => {
    setFormData(prev => ({
      ...prev,
      contacts: prev.contacts.filter((_, i) => i !== index)
    }));
  };

  const updateContact = (index, field, value) => {
    setFormData(prev => ({
      ...prev,
      contacts: prev.contacts.map((contact, i) => 
        i === index ? { ...contact, [field]: value } : contact
      )
    }));
  };

  const getContactIcon = (type) => {
    const option = contactTypeOptions.find(opt => opt.type === type);
    return option ? option.icon : ExternalLink;
  };

  const getContactPlaceholder = (type) => {
    const option = contactTypeOptions.find(opt => opt.type === type);
    return option ? option.placeholder : 'Enter contact information';
  };

  const getContactInputType = (type) => {
    const option = contactTypeOptions.find(opt => opt.type === type);
    return option ? option.inputType : 'text';
  };

  // View supplier details
  const viewSupplierDetails = async (supplierId) => {
    try {
      const response = await axios.get(`http://localhost:5000/api/suppliers/${supplierId}`);
      const supplier = {
        ...response.data,
        contacts: response.data.contacts || transformLegacyContacts(response.data)
      };
      setSelectedSupplier(supplier);
      setShowViewModal(true);
      setEditMode(false);
    } catch (error) {
      console.error('Error fetching supplier details:', error);
      alert('Error fetching supplier details');
    }
  };

  const handleEdit = () => {
    setFormData({
      magasin_id: selectedSupplier.magasin_id,
      name: selectedSupplier.name,
      country: selectedSupplier.country || '',
      address: selectedSupplier.address || '',
      contacts: selectedSupplier.contacts || [],
      created_by_user_id: selectedSupplier.created_by_user_id
    });
    setEditMode(true);
  };

  const handleDelete = async (supplierId) => {
    if (window.confirm('Are you sure you want to delete this supplier?')) {
      try {
        await axios.delete(`http://localhost:5000/api/suppliers/${supplierId}`);
        alert('Supplier deleted successfully');
        setShowViewModal(false);
        fetchData();
      } catch (error) {
        console.error('Error deleting supplier:', error);
        alert('Error deleting supplier: ' + (error.response?.data?.error || error.message));
      }
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!formData.name) {
      alert('Supplier name is required');
      return;
    }

    // Filter out empty contacts
    const validContacts = formData.contacts.filter(contact => contact.type && contact.value.trim());

    // Prepare data for backend (maintain backward compatibility)
    const submitData = {
      ...formData,
      contacts: validContacts,
      // For backward compatibility, extract email and phone
      email: validContacts.find(c => c.type === 'Email')?.value || '',
      phone: validContacts.find(c => c.type === 'Phone')?.value || '',
      contact_types: validContacts.map(c => c.type)
    };

    try {
      if (editMode && selectedSupplier) {
        await axios.put(`http://localhost:5000/api/suppliers/${selectedSupplier.id}`, submitData);
        alert('Supplier updated successfully');
        setShowViewModal(false);
      } else {
        await axios.post('http://localhost:5000/api/suppliers', submitData);
        alert('Supplier created successfully');
        setShowModal(false);
      }
      
      setFormData({
        magasin_id: user?.magasin_id || '',
        name: '',
        country: '',
        address: '',
        contacts: [],
        created_by_user_id: user?.id || ''
      });
      setEditMode(false);
      fetchData();
    } catch (error) {
      let errorMsg = editMode ? 'Error updating supplier: ' : 'Error creating supplier: ';
      if (error.response?.data?.error) {
        errorMsg += error.response.data.error;
      } else if (error.response?.data?.message) {
        errorMsg += error.response.data.message;
      } else {
        errorMsg += error.message;
      }
      alert(errorMsg);
      console.error('Error with supplier operation:', error);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="w-full py-6 px-2 sm:px-4 lg:px-8">
      <div className="px-0 py-6 sm:px-0">
        <div className="sm:flex sm:items-center">
          <div className="sm:flex-auto">
            <h1 className="text-3xl font-bold text-gray-900">Supplier Management</h1>
            <p className="mt-2 text-sm text-gray-700">
              Manage suppliers and their contact information
            </p>
          </div>
          <div className="mt-4 sm:mt-0 sm:ml-16 sm:flex-none space-x-2">
            <button
              onClick={() => setShowFilterModal(true)}
              className="inline-flex items-center justify-center rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
            >
              <Filter className="h-4 w-4 mr-2" />
              Filters
              {activeFilters.length > 0 && (
                <span className="ml-2 bg-blue-100 text-blue-800 text-xs font-medium px-2 py-1 rounded-full">
                  {activeFilters.length}
                </span>
              )}
            </button>
            <button
              onClick={() => setShowModal(true)}
              className="inline-flex items-center justify-center rounded-md border border-transparent bg-blue-600 px-4 py-2 text-sm font-medium text-white shadow-sm hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 sm:w-auto"
            >
              <Plus className="h-4 w-4 mr-2" />
              New Supplier
            </button>
          </div>
        </div>

        {/* Active Filters Display */}
        {activeFilters.length > 0 && (
          <div className="mt-4 flex flex-wrap gap-2 items-center">
            <span className="text-sm font-medium text-gray-700">Active filters:</span>
            {activeFilters.map((filter) => (
              <span
                key={filter.key}
                className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800"
              >
                {filter.label}
                <button
                  onClick={() => removeFilter(filter.key)}
                  className="ml-2 inline-flex items-center justify-center w-4 h-4 rounded-full hover:bg-blue-200"
                >
                  <X className="h-3 w-3" />
                </button>
              </span>
            ))}
            <button
              onClick={clearAllFilters}
              className="text-sm text-gray-500 hover:text-gray-700 underline"
            >
              Clear all
            </button>
          </div>
        )}

        {/* Search Bar */}
        <div className="mt-4">
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-5 w-5 text-gray-400" />
            </div>
            <input
              type="text"
              placeholder="Search by name, contact info, address, or country..."
              className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
              value={filters.searchTerm}
              onChange={(e) => handleFilterChange('searchTerm', e.target.value)}
            />
          </div>
        </div>

        <div className="mt-8 flex flex-col">
          <div className="-my-2 -mx-2 overflow-x-auto sm:-mx-4 lg:-mx-8">
            <div className="inline-block min-w-full py-2 align-middle md:px-4 lg:px-8">
              <div className="overflow-hidden shadow ring-1 ring-black ring-opacity-5 md:rounded-lg">
                <table className="min-w-full divide-y divide-gray-300">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Supplier Name
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Country
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Contact Info
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Contact Types
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Created By
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Date
                      </th>
                      <th className="relative px-6 py-3">
                        <span className="sr-only">Actions</span>
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {filteredSuppliers.map((supplier) => {
                      const validContacts = supplier.contacts?.filter(c => c.value) || [];
                      const primaryEmail = validContacts.find(c => c.type === 'Email');
                      const primaryPhone = validContacts.find(c => c.type === 'Phone');
                      
                      return (
                        <tr key={supplier.id}>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex items-center">
                              <Building2 className="h-5 w-5 text-gray-400 mr-3" />
                              <div className="text-sm font-medium text-gray-900">
                                {supplier.name}
                              </div>
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex items-center">
                              <Globe className="h-4 w-4 text-gray-400 mr-2" />
                              <span className="text-sm text-gray-900">
                                {supplier.country || 'N/A'}
                              </span>
                            </div>
                          </td>
                          <td className="px-6 py-4">
                            <div className="text-sm text-gray-900">
                              {primaryEmail && (
                                <div className="flex items-center mb-1">
                                  <Mail className="h-3 w-3 text-gray-400 mr-1" />
                                  <span className="truncate max-w-32">{primaryEmail.value}</span>
                                </div>
                              )}
                              {primaryPhone && (
                                <div className="flex items-center">
                                  <Phone className="h-3 w-3 text-gray-400 mr-1" />
                                  <span>{primaryPhone.value}</span>
                                </div>
                              )}
                              {!primaryEmail && !primaryPhone && validContacts.length > 0 && (
                                <div className="flex items-center">
                                  {React.createElement(getContactIcon(validContacts[0].type), { className: "h-3 w-3 text-gray-400 mr-1" })}
                                  <span className="truncate max-w-32">{validContacts[0].value}</span>
                                </div>
                              )}
                            </div>
                          </td>
                          <td className="px-6 py-4">
                            <div className="flex flex-wrap gap-1">
                              {validContacts.slice(0, 2).map((contact, index) => (
                                <span
                                  key={index}
                                  className="inline-flex px-2 py-1 text-xs font-medium bg-gray-100 text-gray-800 rounded-full"
                                >
                                  {contact.type}
                                </span>
                              ))}
                              {validContacts.length > 2 && (
                                <span className="inline-flex px-2 py-1 text-xs font-medium bg-gray-100 text-gray-800 rounded-full">
                                  +{validContacts.length - 2}
                                </span>
                              )}
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex items-center">
                              <User className="h-4 w-4 text-gray-400 mr-2" />
                              <span className="text-sm text-gray-900">
                                {supplier.created_by}
                              </span>
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm text-gray-900">
                              {new Date(supplier.created_at).toLocaleDateString()}
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                            <button
                              onClick={() => viewSupplierDetails(supplier.id)}
                              className="text-blue-600 hover:text-blue-900"
                            >
                              <Eye className="h-4 w-4" />
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
                {filteredSuppliers.length === 0 && (
                  <div className="text-center py-8 text-gray-500">
                    No suppliers found matching your filters.
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Create/Edit Supplier Modal */}
        {(showModal || editMode) && (
          <div style={{background:"#8080805e"}} className="fixed inset-0  bg-opacity-50 overflow-y-auto h-full w-full z-50">
            <div className="relative top-10 mx-auto p-5 border w-full max-w-3xl shadow-lg rounded-md bg-white max-h-5/6 overflow-y-auto">
              <div className="mt-3">
                <h3 className="text-lg font-medium text-gray-900 mb-4">
                  {editMode ? 'Edit Supplier' : 'Create New Supplier'}
                </h3>
                
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Supplier Name *
                    </label>
                    <input
                      type="text"
                      required
                      className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 text-sm"
                      value={formData.name}
                      onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                      placeholder="Enter supplier name"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700">
                        Country
                      </label>
                      <select
                        className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 text-sm"
                        value={formData.country}
                        onChange={(e) => setFormData(prev => ({ ...prev, country: e.target.value }))}
                      >
                        <option value="">Select Country</option>
                        {countryOptions.map((country) => (
                          <option key={country} value={country}>
                            {country}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">
                        Created By
                      </label>
                      <select
                        className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 text-sm"
                        value={formData.created_by_user_id}
                        onChange={(e) => setFormData(prev => ({ ...prev, created_by_user_id: e.target.value }))}
                        disabled={!editMode}
                      >
                        <option value="">Select User</option>
                        {users.map((user) => (
                          <option key={user.id} value={user.id}>
                            {user.name} ({user.poste})
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Address
                    </label>
                    <textarea
                      className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 text-sm"
                      rows="3"
                      value={formData.address}
                      onChange={(e) => setFormData(prev => ({ ...prev, address: e.target.value }))}
                      placeholder="Enter full address"
                    />
                  </div>

                  {/* Dynamic Contact Information */}
                  <div>
                    <div className="flex justify-between items-center mb-3">
                      <label className="block text-sm font-medium text-gray-700">
                        Contact Information
                      </label>
                      <button
                        type="button"
                        onClick={addContact}
                        className="text-blue-600 hover:text-blue-800 text-sm font-medium"
                      >
                        + Add Contact
                      </button>
                    </div>
                    
                    <div className="space-y-3 max-h-60 overflow-y-auto border border-gray-300 rounded-md p-3">
                      {formData.contacts.map((contact, index) => (
                        <div key={index} className="grid grid-cols-12 gap-2 items-center">
                          <div className="col-span-4">
                            <select
                              className="block w-full border border-gray-200 rounded-md px-2 py-1 text-sm"
                              value={contact.type}
                              onChange={(e) => updateContact(index, 'type', e.target.value)}
                            >
                              <option value="">Select Type</option>
                              {contactTypeOptions.map((option) => (
                                <option key={option.type} value={option.type}>
                                  {option.type}
                                </option>
                              ))}
                            </select>
                          </div>
                          
                          <div className="col-span-7">
                            <div className="relative">
                              <div className="absolute inset-y-0 left-0 pl-2 flex items-center pointer-events-none">
                                {contact.type && React.createElement(getContactIcon(contact.type), { className: "h-4 w-4 text-gray-400" })}
                              </div>
                              <input
                                type={getContactInputType(contact.type)}
                                className={`block w-full border border-gray-200 rounded-md py-1 text-sm ${contact.type ? 'pl-8 pr-2' : 'px-2'}`}
                                placeholder={contact.type ? getContactPlaceholder(contact.type) : 'Select contact type first'}
                                value={contact.value}
                                onChange={(e) => updateContact(index, 'value', e.target.value)}
                                disabled={!contact.type}
                              />
                            </div>
                          </div>
                          
                          <div className="col-span-1">
                            <button
                              type="button"
                              onClick={() => removeContact(index)}
                              className="text-red-600 hover:text-red-800"
                            >
                              <Minus className="h-4 w-4" />
                            </button>
                          </div>
                        </div>
                      ))}
                      
                      {formData.contacts.length === 0 && (
                        <div className="text-center py-4 text-gray-500 text-sm">
                          No contact information added. Click "Add Contact" to start.
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="flex justify-end space-x-3 pt-4">
                    <button
                      type="button"
                      onClick={() => {
                        if (editMode) {
                          setEditMode(false);
                        } else {
                          setShowModal(false);
                        }
                        setFormData({
                          magasin_id: user?.magasin_id || '',
                          name: '',
                          country: '',
                          address: '',
                          contacts: [],
                          created_by_user_id: user?.id || ''
                        });
                      }}
                      className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-md hover:bg-blue-700"
                    >
                      {editMode ? 'Update Supplier' : 'Create Supplier'}
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        )}

        {/* View Supplier Details Modal */}
        {showViewModal && selectedSupplier && !editMode && (
          <div style={{background:"#8080805e"}} className="fixed inset-0  bg-opacity-50 overflow-y-auto h-full w-full z-50">
            <div className="relative top-10 mx-auto p-5 border w-full max-w-4xl shadow-lg rounded-md bg-white max-h-5/6 overflow-y-auto">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-medium text-gray-900">
                  Supplier Details - {selectedSupplier.name}
                </h3>
                <button
                  onClick={() => setShowViewModal(false)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <X className="h-6 w-6" />
                </button>
              </div>

              <div className="space-y-6">
                {/* Basic Information */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Supplier Name</label>
                    <p className="mt-1 text-sm text-gray-900 font-semibold">{selectedSupplier.name}</p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Country</label>
                    <div className="flex items-center mt-1">
                      <Globe className="h-4 w-4 text-gray-400 mr-2" />
                      <p className="text-sm text-gray-900">{selectedSupplier.country || 'Not specified'}</p>
                    </div>
                  </div>
                </div>

                {/* Address */}
                {selectedSupplier.address && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Address</label>
                    <div className="flex items-start mt-1">
                      <MapPin className="h-4 w-4 text-gray-400 mr-2 mt-0.5" />
                      <p className="text-sm text-gray-900">{selectedSupplier.address}</p>
                    </div>
                  </div>
                )}

                {/* Contact Information */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-3">Contact Information</label>
                  {selectedSupplier.contacts && selectedSupplier.contacts.length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {selectedSupplier.contacts.filter(c => c.value).map((contact, index) => {
                        const IconComponent = getContactIcon(contact.type);
                        return (
                          <div key={index} className="flex items-center p-3 bg-gray-50 rounded-md">
                            <IconComponent className="h-5 w-5 text-gray-400 mr-3" />
                            <div>
                              <p className="text-xs font-medium text-gray-500 uppercase">{contact.type}</p>
                              <p className="text-sm text-gray-900">{contact.value}</p>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  ) : (
                    <p className="text-sm text-gray-500">No contact information available</p>
                  )}
                </div>

                {/* Creation Information */}
                <div className="grid grid-cols-2 gap-4 pt-4 border-t">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Created By</label>
                    <div className="mt-1">
                      <p className="text-sm text-gray-900">{selectedSupplier.created_by}</p>
                      {selectedSupplier.created_by_email && (
                        <p className="text-xs text-gray-500">{selectedSupplier.created_by_email}</p>
                      )}
                      {selectedSupplier.created_by_poste && (
                        <p className="text-xs text-gray-500">{selectedSupplier.created_by_poste}</p>
                      )}
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Created Date</label>
                    <p className="mt-1 text-sm text-gray-900">
                      {new Date(selectedSupplier.created_at).toLocaleString()}
                    </p>
                  </div>
                </div>

                {/* Magasin Information */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Magasin</label>
                    <p className="mt-1 text-sm text-gray-900">{selectedSupplier.magasin_name}</p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Magasin Responsable</label>
                    <div className="mt-1">
                      <p className="text-sm text-gray-900">{selectedSupplier.magasin_responsable}</p>
                      {selectedSupplier.magasin_responsable_email && (
                        <p className="text-xs text-gray-500">{selectedSupplier.magasin_responsable_email}</p>
                      )}
                    </div>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex justify-end space-x-3 pt-4 border-t">
                  <button
                    onClick={() => handleDelete(selectedSupplier.id)}
                    className="inline-flex items-center px-4 py-2 text-sm font-medium text-white bg-red-600 border border-transparent rounded-md hover:bg-red-700"
                  >
                    <Trash2 className="h-4 w-4 mr-2" />
                    Delete
                  </button>
                  <button
                    onClick={handleEdit}
                    className="inline-flex items-center px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-md hover:bg-blue-700"
                  >
                    <Edit className="h-4 w-4 mr-2" />
                    Edit
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Filter Modal */}
        {showFilterModal && (
          <div style={{background:"#8080805e"}} className="fixed inset-0  bg-opacity-50 overflow-y-auto h-full w-full z-50">
            <div className="relative top-10 mx-auto p-5 border w-full max-w-2xl shadow-lg rounded-md bg-white">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-medium text-gray-900">Filter Suppliers</h3>
                <button
                  onClick={() => setShowFilterModal(false)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <X className="h-6 w-6" />
                </button>
              </div>

              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Country</label>
                    <select
                      className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 text-sm"
                      value={filters.country}
                      onChange={(e) => handleFilterChange('country', e.target.value)}
                    >
                      <option value="">All Countries</option>
                      {countryOptions.map((country) => (
                        <option key={country} value={country}>
                          {country}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Contact Type</label>
                    <select
                      className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 text-sm"
                      value={filters.contactType}
                      onChange={(e) => handleFilterChange('contactType', e.target.value)}
                    >
                      <option value="">All Contact Types</option>
                      {contactTypeOptions.map((option) => (
                        <option key={option.type} value={option.type}>
                          {option.type}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">Created By</label>
                  <input
                    type="text"
                    className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 text-sm"
                    placeholder="Enter creator name"
                    value={filters.createdBy}
                    onChange={(e) => handleFilterChange('createdBy', e.target.value)}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Date From</label>
                    <input
                      type="date"
                      className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 text-sm"
                      value={filters.dateFrom}
                      onChange={(e) => handleFilterChange('dateFrom', e.target.value)}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Date To</label>
                    <input
                      type="date"
                      className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 text-sm"
                      value={filters.dateTo}
                      onChange={(e) => handleFilterChange('dateTo', e.target.value)}
                    />
                  </div>
                </div>

                <div className="flex justify-end space-x-3 pt-4">
                  <button
                    onClick={clearAllFilters}
                    className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50"
                  >
                    Clear All
                  </button>
                  <button
                    onClick={() => setShowFilterModal(false)}
                    className="px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-md hover:bg-blue-700"
                  >
                    Apply Filters
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default SupplierManagement;

