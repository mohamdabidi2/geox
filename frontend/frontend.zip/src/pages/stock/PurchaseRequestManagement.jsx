import { useState, useEffect } from 'react';
import { useAuth } from '../../hooks/useAuth';
import axios from 'axios';
import { Plus, FileText, Store, User, CheckCircle, XCircle, Clock, Minus, Eye, Filter, X, Search } from 'lucide-react';

const PurchaseRequestManagement = () => {
  const { user } = useAuth();
  const [purchaseRequests, setPurchaseRequests] = useState([]);
  const [filteredRequests, setFilteredRequests] = useState([]);
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [showViewModal, setShowViewModal] = useState(false);
  const [showFilterModal, setShowFilterModal] = useState(false);
  const [selectedRequest, setSelectedRequest] = useState(null);
  const [respMagasin, setrespMagasin] = useState(null);
  
  // Filter states
  const [filters, setFilters] = useState({
    status: '',
    createdBy: '',
    dateFrom: '',
    dateTo: '',
    minAmount: '',
    maxAmount: '',
    searchTerm: ''
  });
  const [activeFilters, setActiveFilters] = useState([]);

  const [formData, setFormData] = useState({
    magasin_id: user?.magasin_id || '',
    products: [{ product_id: '', quantity: 1 }],
    total_amount: 0,
    notes: '',
    created_by: user?.firstname + " " + user?.lastname || ''
  });

  // Calculate total whenever products change
  const calculateTotal = (productsArr) => {
    return productsArr.reduce((sum, item) => {
      const qty = Number(item.quantity) || 0;
      const product = products.find(p => p.id === parseInt(item.product_id));
      const price = product ? parseFloat(product.product_data?.Prix || 0) : 0;
      return sum + qty * price;
    }, 0);
  };

  // Update total_amount whenever products change
  const setProductsAndTotal = (productsArr) => {
    setFormData(prev => ({
      ...prev,
      products: productsArr,
      total_amount: calculateTotal(productsArr)
    }));
  };

  useEffect(() => {
    fetchData();
    // eslint-disable-next-line
  }, []);

  useEffect(() => {
    applyFilters();
    // eslint-disable-next-line
  }, [purchaseRequests, filters]);

  const fetchData = async () => {
    try {
      setLoading(true);
      const [requestsRes, productsRes, MagasinRes] = await Promise.all([
        axios.get(`http://localhost:5000/api/purchase-requests/magasin/${user?.magasin_id}`),
        axios.get(`http://localhost:5000/api/products/magasin/${user?.magasin_id}`),
        axios.get(`http://localhost:5000/api/magasins/${user?.magasin_id}`),
      ]);
      console.log(user?.id)
      setrespMagasin(MagasinRes.data.responsable_id)
      setPurchaseRequests(requestsRes.data);
      setProducts(productsRes.data);
    } catch (error) {
      console.error('Error fetching data:', error);
      alert('Error fetching data');
    } finally {
      setLoading(false);
    }
  };

  // Filter functionality
  const applyFilters = () => {
    let filtered = [...purchaseRequests];

    // Status filter
    if (filters.status) {
      filtered = filtered.filter(req => req.status === filters.status);
    }

    // Created by filter
    if (filters.createdBy) {
      filtered = filtered.filter(req => 
        req.created_by.toLowerCase().includes(filters.createdBy.toLowerCase())
      );
    }

    // Date range filter
    if (filters.dateFrom) {
      filtered = filtered.filter(req => 
        new Date(req.created_at) >= new Date(filters.dateFrom)
      );
    }
    if (filters.dateTo) {
      filtered = filtered.filter(req => 
        new Date(req.created_at) <= new Date(filters.dateTo + 'T23:59:59')
      );
    }

    // Amount range filter
    if (filters.minAmount) {
      filtered = filtered.filter(req => 
        parseFloat(req.total_amount || 0) >= parseFloat(filters.minAmount)
      );
    }
    if (filters.maxAmount) {
      filtered = filtered.filter(req => 
        parseFloat(req.total_amount || 0) <= parseFloat(filters.maxAmount)
      );
    }

    // Search term filter
    if (filters.searchTerm) {
      filtered = filtered.filter(req => 
        req.id.toString().includes(filters.searchTerm) ||
        req.created_by.toLowerCase().includes(filters.searchTerm.toLowerCase()) ||
        req.notes?.toLowerCase().includes(filters.searchTerm.toLowerCase())
      );
    }

    setFilteredRequests(filtered);
    updateActiveFilters();
  };

  const updateActiveFilters = () => {
    const active = [];
    if (filters.status) active.push({ key: 'status', label: `Status: ${filters.status}`, value: filters.status });
    if (filters.createdBy) active.push({ key: 'createdBy', label: `Created by: ${filters.createdBy}`, value: filters.createdBy });
    if (filters.dateFrom) active.push({ key: 'dateFrom', label: `From: ${filters.dateFrom}`, value: filters.dateFrom });
    if (filters.dateTo) active.push({ key: 'dateTo', label: `To: ${filters.dateTo}`, value: filters.dateTo });
    if (filters.minAmount) active.push({ key: 'minAmount', label: `Min: $${filters.minAmount}`, value: filters.minAmount });
    if (filters.maxAmount) active.push({ key: 'maxAmount', label: `Max: $${filters.maxAmount}`, value: filters.maxAmount });
    if (filters.searchTerm) active.push({ key: 'searchTerm', label: `Search: ${filters.searchTerm}`, value: filters.searchTerm });
    setActiveFilters(active);
  };

  const removeFilter = (filterKey) => {
    setFilters(prev => ({ ...prev, [filterKey]: '' }));
  };

  const clearAllFilters = () => {
    setFilters({
      status: '',
      createdBy: '',
      dateFrom: '',
      dateTo: '',
      minAmount: '',
      maxAmount: '',
      searchTerm: ''
    });
  };

  const handleFilterChange = (key, value) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  // View request details
  const viewRequestDetails = async (requestId) => {
    try {
      const response = await axios.get(`http://localhost:5000/api/purchase-requests/${requestId}`);
      setSelectedRequest(response.data);
      setShowViewModal(true);
    } catch (error) {
      console.error('Error fetching request details:', error);
      alert('Error fetching request details');
    }
  };

  const getProductDetails = (productId) => {
    return products.find(p => p.id === parseInt(productId));
  };

  const addItem = () => {
    const newProducts = [...formData.products, { product_id: '', quantity: 1 }];
    setProductsAndTotal(newProducts);
  };

  const removeItem = (index) => {
    const newProducts = formData.products.filter((_, i) => i !== index);
    setProductsAndTotal(newProducts);
  };

  const updateItem = (index, field, value) => {
    const newProducts = [...formData.products];
    newProducts[index] = { ...newProducts[index], [field]: value };
    setProductsAndTotal(newProducts);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Clean products array - remove any extra fields
    const cleanProducts = formData.products.map(item => ({
      product_id: item.product_id,
      quantity: item.quantity
    }));

    const submitData = {
      magasin_id: user?.magasin_id,
      products: cleanProducts,
      notes: formData.notes || '',
      created_by: user?.firstname + " " + user?.lastname 
    };

    // Validation: magasin_id, products array, and created_by are required
    if (
      !submitData.magasin_id ||
      !Array.isArray(submitData.products) ||
      submitData.products.length === 0 ||
      !submitData.created_by
    ) {
      alert('magasin_id, products array, and created_by are required');
      return;
    }

    // Validate that every product has a product_id and quantity > 0
    for (const item of submitData.products) {
      if (!item.product_id || Number(item.quantity) <= 0) {
        alert('Each item must have a selected product and quantity greater than 0');
        return;
      }
    }

    try {
      await axios.post('http://localhost:5000/api/purchase-requests', submitData);
      alert('Purchase request created successfully');
      setShowModal(false);
      setFormData({
        magasin_id: user?.magasin_id || '',
        products: [{ product_id: '', quantity: 1 }],
        total_amount: 0,
        notes: '',
        created_by: user?.firstname + " " + user?.lastname || ''
      });
      fetchData();
    } catch (error) {
      // Show more specific error if available
      let errorMsg = 'Error creating purchase request: ';
      if (error.response?.data?.error) {
        errorMsg += error.response.data.error;
      } else if (error.response?.data?.message) {
        errorMsg += error.response.data.message;
      } else {
        errorMsg += error.message;
      }
      alert(errorMsg);
      console.error('Error creating purchase request:', error);
    }
  };

  const handleStatusUpdate = async (requestId, status) => {
    try {
      await axios.patch(`http://localhost:5000/api/purchase-requests/${requestId}/approval`, { 
        status,
        approved_by: user.id
      });
      alert(`Purchase request ${status} successfully`);
      fetchData();
    } catch (error) {
      console.error('Error updating request status:', error);
      alert('Error updating request status: ' + (error.response?.data?.error || error.message));
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'approved':
        return <CheckCircle className="h-5 w-5 text-green-600" />;
      case 'rejected':
        return <XCircle className="h-5 w-5 text-red-600" />;
      default:
        return <Clock className="h-5 w-5 text-yellow-600" />;
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'approved':
        return 'bg-green-100 text-green-800';
      case 'rejected':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-yellow-100 text-yellow-800';
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="w-full py-6 px-2 sm:px-4 lg:px-8">
      <div className="px-0 py-6 sm:px-0">
        <div className="sm:flex sm:items-center">
          <div className="sm:flex-auto">
            <h1 className="text-3xl font-bold text-gray-900">Purchase Request Management</h1>
            <p className="mt-2 text-sm text-gray-700">
              Create and manage purchase requests for approval
            </p>
          </div>
          <div className="mt-4 sm:mt-0 sm:ml-16 sm:flex-none space-x-2">
            <button
              onClick={() => setShowFilterModal(true)}
              className="inline-flex items-center justify-center rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
            >
              <Filter className="h-4 w-4 mr-2" />
              Filters
              {activeFilters.length > 0 && (
                <span className="ml-2 bg-blue-100 text-blue-800 text-xs font-medium px-2 py-1 rounded-full">
                  {activeFilters.length}
                </span>
              )}
            </button>
            <button
              onClick={() => setShowModal(true)}
              className="inline-flex items-center justify-center rounded-md border border-transparent bg-blue-600 px-4 py-2 text-sm font-medium text-white shadow-sm hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 sm:w-auto"
            >
              <Plus className="h-4 w-4 mr-2" />
              New Request
            </button>
          </div>
        </div>

        {/* Active Filters Display */}
        {activeFilters.length > 0 && (
          <div className="mt-4 flex flex-wrap gap-2 items-center">
            <span className="text-sm font-medium text-gray-700">Active filters:</span>
            {activeFilters.map((filter) => (
              <span
                key={filter.key}
                className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800"
              >
                {filter.label}
                <button
                  onClick={() => removeFilter(filter.key)}
                  className="ml-2 inline-flex items-center justify-center w-4 h-4 rounded-full hover:bg-blue-200"
                >
                  <X className="h-3 w-3" />
                </button>
              </span>
            ))}
            <button
              onClick={clearAllFilters}
              className="text-sm text-gray-500 hover:text-gray-700 underline"
            >
              Clear all
            </button>
          </div>
        )}

        {/* Search Bar */}
        <div className="mt-4">
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-5 w-5 text-gray-400" />
            </div>
            <input
              type="text"
              placeholder="Search by ID, creator, or notes..."
              className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
              value={filters.searchTerm}
              onChange={(e) => handleFilterChange('searchTerm', e.target.value)}
            />
          </div>
        </div>

        <div className="mt-8 flex flex-col">
          <div className="-my-2 -mx-2 overflow-x-auto sm:-mx-4 lg:-mx-8">
            <div className="inline-block min-w-full py-2 align-middle md:px-4 lg:px-8">
              <div className="overflow-hidden shadow ring-1 ring-black ring-opacity-5 md:rounded-lg">
                <table className="min-w-full divide-y divide-gray-300">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Request ID
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Items
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Total Amount
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Status
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Created By
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Date
                      </th>
                      <th className="relative px-6 py-3">
                        <span className="sr-only">Actions</span>
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {filteredRequests.map((request) => (
                      <tr key={request.id}>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <FileText className="h-5 w-5 text-gray-400 mr-3" />
                            <div className="text-sm font-medium text-gray-900">
                              PR-{request.id}
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <div className="text-sm text-gray-900">
                            {request.products?.length || 0} items
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm font-medium text-gray-900">
                            ${parseFloat(request.total_amount || 0).toFixed(2)}
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            {getStatusIcon(request.status)}
                            <span className={`ml-2 inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(request.status)}`}>
                              {request.status}
                            </span>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <User className="h-4 w-4 text-gray-400 mr-2" />
                            <span className="text-sm text-gray-900">
                              {request.created_by}
                            </span>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm text-gray-900">
                            {new Date(request.created_at).toLocaleDateString()}
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                          <div className="flex space-x-2">
                            <button
                              onClick={() => viewRequestDetails(request.id)}
                              className="text-blue-600 hover:text-blue-900"
                            >
                              <Eye className="h-4 w-4" />
                            </button>
                            {user?.id === respMagasin && request.status === 'pending' && (
                              <>
                                <button
                                  onClick={() => handleStatusUpdate(request.id, 'approved')}
                                  className="text-green-600 hover:text-green-900"
                                >
                                  Approve
                                </button>
                                <button
                                  onClick={() => handleStatusUpdate(request.id, 'rejected')}
                                  className="text-red-600 hover:text-red-900"
                                >
                                  Reject
                                </button>
                              </>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                {filteredRequests.length === 0 && (
                  <div className="text-center py-8 text-gray-500">
                    No purchase requests found matching your filters.
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Create Request Modal */}
        {showModal && (
          <div style={{background:"#8080805e"}} className="fixed inset-0  bg-opacity-50 overflow-y-auto h-full w-full z-50">
            <div className="relative top-10 mx-auto p-5 border w-full max-w-5xl shadow-lg rounded-md bg-white max-h-5/6 overflow-y-auto">
              <div className="mt-3">
                <h3 className="text-lg font-medium text-gray-900 mb-4">
                  Create Purchase Request
                </h3>
                
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <label className="block text-sm font-medium text-gray-700">
                        Items
                      </label>
                      <button
                        type="button"
                        onClick={addItem}
                        className="text-blue-600 hover:text-blue-800 text-sm"
                      >
                        + Add Item
                      </button>
                    </div>
                    
                    <div className="space-y-3 max-h-60 overflow-y-auto border border-gray-300 rounded-md p-3">
                      {formData.products.map((item, index) => (
                        <div key={index} className="grid grid-cols-12 gap-2 items-center">
                          <div className="col-span-5">
                            <select
                              required
                              className="block w-full border border-gray-200 rounded-md px-2 py-1 text-sm"
                              value={item.product_id}
                              onChange={(e) => updateItem(index, 'product_id', e.target.value)}
                            >
                              <option value="">Select Product</option>
                              {products.map((product) => (
                                <option key={product.id} value={product.id}>
                                  {product.name} ({product.category_name})
                                </option>
                              ))}
                            </select>
                          </div>
                          
                          <div className="col-span-2">
                            <input
                              type="number"
                              min="1"
                              required
                              placeholder="Qty"
                              className="block w-full border border-gray-200 rounded-md px-2 py-1 text-sm"
                              value={item.quantity}
                              onChange={(e) => updateItem(index, 'quantity', e.target.value)}
                            />
                          </div>
                          
                          <div className="col-span-3">
                            <span className="text-sm text-gray-600">
                              {item.product_id ? 
                                `$${products.find(p => p.id === parseInt(item.product_id))?.product_data?.Prix || '0.00'}` 
                                : 'Select product'
                              }
                            </span>
                          </div>
                          
                          <div className="col-span-1">
                            <span className="text-sm text-gray-600">
                              ${(Number(products.find(p => p.id === parseInt(item.product_id))?.product_data?.Prix || 0) * Number(item.quantity || 0)).toFixed(2)}
                            </span>
                          </div>
                          
                          <div className="col-span-1">
                            {formData.products.length > 1 && (
                              <button
                                type="button"
                                onClick={() => removeItem(index)}
                                className="text-red-600 hover:text-red-800"
                              >
                                <Minus className="h-4 w-4" />
                              </button>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Notes (Optional)
                    </label>
                    <textarea
                      className="block w-full border border-gray-300 rounded-md px-3 py-2 text-sm"
                      rows="3"
                      value={formData.notes}
                      onChange={(e) => setFormData(prev => ({ ...prev, notes: e.target.value }))}
                      placeholder="Add any additional notes or comments..."
                    />
                  </div>

                  <div className="bg-gray-50 p-4 rounded-md">
                    <div className="flex justify-between items-center">
                      <span className="text-lg font-medium text-gray-900">Total Amount:</span>
                      <span className="text-lg font-bold text-blue-600">
                        ${formData.total_amount.toFixed(2)}
                      </span>
                    </div>
                  </div>

                  <div className="flex justify-end space-x-3 pt-4">
                    <button
                      type="button"
                      onClick={() => setShowModal(false)}
                      className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-md hover:bg-blue-700"
                    >
                      Create Request
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        )}

        {/* View Request Details Modal */}
        {showViewModal && selectedRequest && (
          <div style={{background:"#8080805e"}} className="fixed inset-0  bg-opacity-50 overflow-y-auto h-full w-full z-50">
            <div className="relative top-10 mx-auto p-5 border w-full max-w-4xl shadow-lg rounded-md bg-white max-h-5/6 overflow-y-auto">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-medium text-gray-900">
                  Purchase Request Details - PR-{selectedRequest.id}
                </h3>
                <button
                  onClick={() => setShowViewModal(false)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <X className="h-6 w-6" />
                </button>
              </div>

              <div className="space-y-6">
                {/* Request Info */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Status</label>
                    <div className="flex items-center mt-1">
                      {getStatusIcon(selectedRequest.status)}
                      <span className={`ml-2 inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(selectedRequest.status)}`}>
                        {selectedRequest.status}
                      </span>
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Total Amount</label>
                    <p className="mt-1 text-lg font-semibold text-gray-900">
                      ${parseFloat(selectedRequest.total_amount || 0).toFixed(2)}
                    </p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Created By</label>
                    <p className="mt-1 text-sm text-gray-900">{selectedRequest.created_by}</p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Created Date</label>
                    <p className="mt-1 text-sm text-gray-900">
                      {new Date(selectedRequest.created_at).toLocaleString()}
                    </p>
                  </div>
                  {selectedRequest.approved_by && (
                    <>
                      <div>
                        <label className="block text-sm font-medium text-gray-700">Approved By</label>
                        <p className="mt-1 text-sm text-gray-900">{selectedRequest.approved_by}</p>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700">Approved Date</label>
                        <p className="mt-1 text-sm text-gray-900">
                          {new Date(selectedRequest.approved_at).toLocaleString()}
                        </p>
                      </div>
                    </>
                  )}
                </div>

                {/* Products */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-3">Requested Items</label>
                  <div className="overflow-hidden shadow ring-1 ring-black ring-opacity-5 rounded-lg">
                    <table className="min-w-full divide-y divide-gray-300">
                      <thead className="bg-gray-50">
                        <tr>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Product
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Category
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Quantity
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Unit Price
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Total
                          </th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-gray-200">
                        {selectedRequest.products?.map((item, index) => {
                          const product = getProductDetails(item.product_id);
                          const unitPrice = product?.product_data?.Prix || 0;
                          const total = unitPrice * item.quantity;
                          return (
                            <tr key={index}>
                              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                {product?.name || `Product ID: ${item.product_id}`}
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                {product?.category_name || 'N/A'}
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                {item.quantity}
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                ${parseFloat(unitPrice).toFixed(2)}
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                ${total.toFixed(2)}
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Notes */}
                {selectedRequest.notes && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Notes</label>
                    <div className="mt-1 p-3 bg-gray-50 rounded-md">
                      <p className="text-sm text-gray-900">{selectedRequest.notes}</p>
                    </div>
                  </div>
                )}

                {/* Actions */}
                {user?.id === respMagasin && selectedRequest.status === 'pending' && (
                  <div className="flex justify-end space-x-3 pt-4 border-t">
                    <button
                      onClick={() => {
                        handleStatusUpdate(selectedRequest.id, 'rejected');
                        setShowViewModal(false);
                      }}
                      className="px-4 py-2 text-sm font-medium text-white bg-red-600 border border-transparent rounded-md hover:bg-red-700"
                    >
                      Reject
                    </button>
                    <button
                      onClick={() => {
                        handleStatusUpdate(selectedRequest.id, 'approved');
                        setShowViewModal(false);
                      }}
                      className="px-4 py-2 text-sm font-medium text-white bg-green-600 border border-transparent rounded-md hover:bg-green-700"
                    >
                      Approve
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Filter Modal */}
        {showFilterModal && (
          <div style={{background:"#8080805e"}} className="fixed inset-0  bg-opacity-50 overflow-y-auto h-full w-full z-50">
            <div className="relative top-10 mx-auto p-5 border w-full max-w-2xl shadow-lg rounded-md bg-white">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-medium text-gray-900">Filter Purchase Requests</h3>
                <button
                  onClick={() => setShowFilterModal(false)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <X className="h-6 w-6" />
                </button>
              </div>

              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Status</label>
                    <select
                      className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 text-sm"
                      value={filters.status}
                      onChange={(e) => handleFilterChange('status', e.target.value)}
                    >
                      <option value="">All Statuses</option>
                      <option value="pending">Pending</option>
                      <option value="approved">Approved</option>
                      <option value="rejected">Rejected</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Created By</label>
                    <input
                      type="text"
                      className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 text-sm"
                      placeholder="Enter creator name"
                      value={filters.createdBy}
                      onChange={(e) => handleFilterChange('createdBy', e.target.value)}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Date From</label>
                    <input
                      type="date"
                      className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 text-sm"
                      value={filters.dateFrom}
                      onChange={(e) => handleFilterChange('dateFrom', e.target.value)}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Date To</label>
                    <input
                      type="date"
                      className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 text-sm"
                      value={filters.dateTo}
                      onChange={(e) => handleFilterChange('dateTo', e.target.value)}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Min Amount ($)</label>
                    <input
                      type="number"
                      min="0"
                      step="0.01"
                      className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 text-sm"
                      placeholder="0.00"
                      value={filters.minAmount}
                      onChange={(e) => handleFilterChange('minAmount', e.target.value)}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Max Amount ($)</label>
                    <input
                      type="number"
                      min="0"
                      step="0.01"
                      className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 text-sm"
                      placeholder="0.00"
                      value={filters.maxAmount}
                      onChange={(e) => handleFilterChange('maxAmount', e.target.value)}
                    />
                  </div>
                </div>

                <div className="flex justify-end space-x-3 pt-4">
                  <button
                    onClick={clearAllFilters}
                    className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50"
                  >
                    Clear All
                  </button>
                  <button
                    onClick={() => setShowFilterModal(false)}
                    className="px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-md hover:bg-blue-700"
                  >
                    Apply Filters
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default PurchaseRequestManagement;

