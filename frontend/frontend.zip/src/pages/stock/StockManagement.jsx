import { useState, useEffect } from 'react';
import { useAuth } from '../../hooks/useAuth';
import axios from 'axios';
import { Plus, BarChart3, Package, Store, TrendingUp, TrendingDown, Activity, Filter, X, Search } from 'lucide-react';

const StockManagement = () => {
  const { user } = useAuth();
  const [currentStock, setCurrentStock] = useState([]);
  const [filteredStock, setFilteredStock] = useState([]);
  const [stockMovements, setStockMovements] = useState([]);
  const [filteredMovements, setFilteredMovements] = useState([]);
  const [products, setProducts] = useState([]);
  const [magasins, setMagasins] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [showFilterModal, setShowFilterModal] = useState(false);
  const [activeTab, setActiveTab] = useState('stock');
  const [formData, setFormData] = useState({
    product_id: '',
    magasin_id: '',
    movement_type: 'in',
    quantity: 1,
    reference_type: 'manual',
    reference_id: '',
    notes: ''
  });

  // Filter states
  const [filters, setFilters] = useState({
    product: '',
    category: '',
    magasin: '',
    movementType: '',
    referenceType: '',
    searchTerm: ''
  });
  const [activeFilters, setActiveFilters] = useState([]);

  useEffect(() => {
    fetchData();
  }, []);

  useEffect(() => {
    applyFilters();
  }, [currentStock, stockMovements, filters]);

  const fetchData = async () => {
    try {
      setLoading(true);
      const [stockRes, movementsRes, productsRes, magasinsRes] = await Promise.all([
        axios.get('http://localhost:5000/api/stock/current-stock'),
        axios.get('http://localhost:5000/api/stock/stock-movements'),
        axios.get('http://localhost:5000/api/products/magasin/'+user.magasin_id),
        axios.get('http://localhost:5000/api/magasins')
      ]);
      
      // Filter approved products
      const approvedProducts = productsRes.data.filter(product => product.is_approved);
      
      setCurrentStock(stockRes.data);
      setStockMovements(movementsRes.data);
      setProducts(approvedProducts);
      setMagasins(magasinsRes.data);
    } catch (error) {
      console.error('Error fetching data:', error);
      alert('Error fetching data');
    } finally {
      setLoading(false);
    }
  };

  // Filter functionality
  const applyFilters = () => {
    // Filter current stock
    let filteredStockData = [...currentStock];
    
    if (filters.product) {
      filteredStockData = filteredStockData.filter(stock => 
        stock.product_name?.toLowerCase().includes(filters.product.toLowerCase())
      );
    }

    if (filters.category) {
      filteredStockData = filteredStockData.filter(stock => 
        stock.category_name?.toLowerCase().includes(filters.category.toLowerCase())
      );
    }

    if (filters.magasin) {
      filteredStockData = filteredStockData.filter(stock => 
        stock.magasin_name?.toLowerCase().includes(filters.magasin.toLowerCase())
      );
    }

    if (filters.searchTerm) {
      filteredStockData = filteredStockData.filter(stock => {
        const searchLower = filters.searchTerm.toLowerCase();
        return stock.product_name?.toLowerCase().includes(searchLower) ||
               stock.category_name?.toLowerCase().includes(searchLower) ||
               stock.magasin_name?.toLowerCase().includes(searchLower);
      });
    }

    setFilteredStock(filteredStockData);

    // Filter stock movements
    let filteredMovementData = [...stockMovements];
    
    if (filters.product) {
      filteredMovementData = filteredMovementData.filter(movement => 
        movement.product_name?.toLowerCase().includes(filters.product.toLowerCase())
      );
    }

    if (filters.magasin) {
      filteredMovementData = filteredMovementData.filter(movement => 
        movement.magasin_name?.toLowerCase().includes(filters.magasin.toLowerCase())
      );
    }

    if (filters.movementType) {
      filteredMovementData = filteredMovementData.filter(movement => 
        movement.movement_type === filters.movementType
      );
    }

    if (filters.referenceType) {
      filteredMovementData = filteredMovementData.filter(movement => 
        movement.reference_type === filters.referenceType
      );
    }

    if (filters.searchTerm) {
      filteredMovementData = filteredMovementData.filter(movement => {
        const searchLower = filters.searchTerm.toLowerCase();
        return movement.product_name?.toLowerCase().includes(searchLower) ||
               movement.magasin_name?.toLowerCase().includes(searchLower) ||
               movement.reference_type?.toLowerCase().includes(searchLower);
      });
    }

    setFilteredMovements(filteredMovementData);
    updateActiveFilters();
  };

  const updateActiveFilters = () => {
    const active = [];
    if (filters.product) active.push({ key: 'product', label: `Product: ${filters.product}`, value: filters.product });
    if (filters.category) active.push({ key: 'category', label: `Category: ${filters.category}`, value: filters.category });
    if (filters.magasin) active.push({ key: 'magasin', label: `Magasin: ${filters.magasin}`, value: filters.magasin });
    if (filters.movementType) active.push({ key: 'movementType', label: `Movement: ${filters.movementType}`, value: filters.movementType });
    if (filters.referenceType) active.push({ key: 'referenceType', label: `Reference: ${filters.referenceType}`, value: filters.referenceType });
    if (filters.searchTerm) active.push({ key: 'searchTerm', label: `Search: ${filters.searchTerm}`, value: filters.searchTerm });
    setActiveFilters(active);
  };

  const removeFilter = (filterKey) => {
    setFilters(prev => ({ ...prev, [filterKey]: '' }));
  };

  const clearAllFilters = () => {
    setFilters({
      product: '',
      category: '',
      magasin: '',
      movementType: '',
      referenceType: '',
      searchTerm: ''
    });
  };

  const handleFilterChange = (key, value) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post('http://localhost:5000/api/stock/stock-movements', formData);
      alert('Stock movement recorded successfully');
      setShowModal(false);
      setFormData({
        product_id: '',
        magasin_id: '',
        movement_type: 'in',
        quantity: 1,
        reference_type: 'manual',
        reference_id: '',
        notes: ''
      });
      fetchData();
    } catch (error) {
      console.error('Error recording stock movement:', error);
      alert('Error recording stock movement');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="w-full py-6 px-2 sm:px-4 lg:px-8">
      <div className="px-0 py-6">
        <div className="sm:flex sm:items-center">
          <div className="sm:flex-auto">
            <h1 className="text-3xl font-bold text-gray-900">Stock Management</h1>
            <p className="mt-2 text-sm text-gray-700">
              Monitor current stock levels and record stock movements
            </p>
          </div>
          <div className="mt-4 sm:mt-0 sm:ml-16 sm:flex-none space-x-2">
            <button
              onClick={() => setShowFilterModal(true)}
              className="inline-flex items-center justify-center rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
            >
              <Filter className="h-4 w-4 mr-2" />
              Filters
              {activeFilters.length > 0 && (
                <span className="ml-2 bg-blue-100 text-blue-800 text-xs font-medium px-2 py-1 rounded-full">
                  {activeFilters.length}
                </span>
              )}
            </button>
            <button
              onClick={() => setShowModal(true)}
              className="inline-flex items-center justify-center rounded-md border border-transparent bg-blue-600 px-4 py-2 text-sm font-medium text-white shadow-sm hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 sm:w-auto"
            >
              <Plus className="h-4 w-4 mr-2" />
              Record Movement
            </button>
          </div>
        </div>

        {/* Active Filters Display */}
        {activeFilters.length > 0 && (
          <div className="mt-4 flex flex-wrap gap-2 items-center">
            <span className="text-sm font-medium text-gray-700">Active filters:</span>
            {activeFilters.map((filter) => (
              <span
                key={filter.key}
                className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800"
              >
                {filter.label}
                <button
                  onClick={() => removeFilter(filter.key)}
                  className="ml-2 inline-flex items-center justify-center w-4 h-4 rounded-full hover:bg-blue-200"
                >
                  <X className="h-3 w-3" />
                </button>
              </span>
            ))}
            <button
              onClick={clearAllFilters}
              className="text-sm text-gray-500 hover:text-gray-700 underline"
            >
              Clear all
            </button>
          </div>
        )}

        {/* Search Bar */}
        <div className="mt-4">
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-5 w-5 text-gray-400" />
            </div>
            <input
              type="text"
              placeholder="Search by product, category, or magasin..."
              className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
              value={filters.searchTerm}
              onChange={(e) => handleFilterChange('searchTerm', e.target.value)}
            />
          </div>
        </div>

        {/* Tabs */}
        <div className="mt-6">
          <nav className="flex space-x-8" aria-label="Tabs">
            <button
              onClick={() => setActiveTab('stock')}
              className={`py-2 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'stock'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <BarChart3 className="h-4 w-4 inline mr-2" />
              Current Stock
            </button>
            <button
              onClick={() => setActiveTab('movements')}
              className={`py-2 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'movements'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <Activity className="h-4 w-4 inline mr-2" />
              Stock Movements
            </button>
          </nav>
        </div>

        {/* Current Stock Tab */}
        {activeTab === 'stock' && (
          <div className="mt-8 w-full">
            <div className="flex flex-col">
              <div className="-my-2 -mx-2 overflow-x-auto">
                <div className="inline-block min-w-full py-2 align-middle px-2">
                  <div className="overflow-x-auto shadow ring-1 ring-black ring-opacity-5 rounded-lg">
                    <table className="min-w-full divide-y divide-gray-300">
                      <thead className="bg-gray-50">
                        <tr>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Product
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Category
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Magasin
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Current Quantity
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Last Updated
                          </th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-gray-200">
                        {filteredStock.map((stock) => (
                          <tr key={`${stock.product_id}-${stock.magasin_id}`}>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="flex items-center">
                                <Package className="h-5 w-5 text-gray-400 mr-3" />
                                <div className="text-sm font-medium text-gray-900">
                                  {stock.product_name}
                                </div>
                              </div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <span className="text-sm text-gray-900">
                                {stock.category_name}
                              </span>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="flex items-center">
                                <Store className="h-4 w-4 text-gray-400 mr-2" />
                                <span className="text-sm text-gray-900">
                                  {stock.magasin_name}
                                </span>
                              </div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className={`text-sm font-medium ${
                                stock.quantity === 0 ? 'text-red-600' :
                                stock.quantity < 10 ? 'text-yellow-600' : 'text-green-600'
                              }`}>
                                {stock.quantity}
                              </div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                              {new Date(stock.last_updated).toLocaleDateString()}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                    {filteredStock.length === 0 && (
                      <div className="text-center py-8 text-gray-500">
                        No stock found matching your filters.
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Stock Movements Tab */}
        {activeTab === 'movements' && (
          <div className="mt-8 w-full">
            <div className="flex flex-col">
              <div className="-my-2 -mx-2 overflow-x-auto">
                <div className="inline-block min-w-full py-2 align-middle px-2">
                  <div className="overflow-x-auto shadow ring-1 ring-black ring-opacity-5 rounded-lg">
                    <table className="min-w-full divide-y divide-gray-300">
                      <thead className="bg-gray-50">
                        <tr>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Product
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Magasin
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Movement
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Quantity
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Reference
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Date
                          </th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-gray-200">
                        {filteredMovements.map((movement) => (
                          <tr key={movement.id}>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="flex items-center">
                                <Package className="h-5 w-5 text-gray-400 mr-3" />
                                <div className="text-sm font-medium text-gray-900">
                                  {movement.product_name}
                                </div>
                              </div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="flex items-center">
                                <Store className="h-4 w-4 text-gray-400 mr-2" />
                                <span className="text-sm text-gray-900">
                                  {movement.magasin_name}
                                </span>
                              </div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="flex items-center">
                                {movement.movement_type === 'in' ? (
                                  <TrendingUp className="h-4 w-4 text-green-500 mr-2" />
                                ) : (
                                  <TrendingDown className="h-4 w-4 text-red-500 mr-2" />
                                )}
                                <span className={`text-sm capitalize ${
                                  movement.movement_type === 'in' ? 'text-green-600' : 'text-red-600'
                                }`}>
                                  {movement.movement_type}
                                </span>
                              </div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="text-sm font-medium text-gray-900">
                                {movement.quantity}
                              </div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="text-sm text-gray-900">
                                {movement.reference_type}
                                {movement.reference_id && ` #${movement.reference_id}`}
                              </div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                              {new Date(movement.created_at).toLocaleDateString()}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                    {filteredMovements.length === 0 && (
                      <div className="text-center py-8 text-gray-500">
                        No movements found matching your filters.
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Modal */}
        {showModal && (
          <div style={{background:"#8080805e"}} className="fixed inset-0  bg-opacity-50 overflow-y-auto h-full w-full z-50">
            <div className="relative top-20 mx-auto p-5 border w-11/12 md:w-1/2 shadow-lg rounded-md bg-white">
              <div className="mt-3">
                <h3 className="text-lg font-medium text-gray-900 mb-4">
                  Record Stock Movement
                </h3>
                
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700">
                        Product
                      </label>
                      <select
                        required
                        className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                        value={formData.product_id}
                        onChange={(e) => setFormData({ ...formData, product_id: e.target.value })}
                      >
                        <option value="">Select Product</option>
                        {products.map((product) => (
                          <option key={product.id} value={product.id}>
                            {product.name} ({product.category_name})
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700">
                        Magasin
                      </label>
                      <select
                        required
                        className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                        value={formData.magasin_id}
                        onChange={(e) => setFormData({ ...formData, magasin_id: e.target.value })}
                      >
                        <option value="">Select Magasin</option>
                        {magasins.map((magasin) => (
                          <option key={magasin.id} value={magasin.id}>
                            {magasin.name}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700">
                        Movement Type
                      </label>
                      <select
                        required
                        className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                        value={formData.movement_type}
                        onChange={(e) => setFormData({ ...formData, movement_type: e.target.value })}
                      >
                        <option value="in">Stock In</option>
                        <option value="out">Stock Out</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700">
                        Quantity
                      </label>
                      <input
                        type="number"
                        min="1"
                        required
                        className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                        value={formData.quantity}
                        onChange={(e) => setFormData({ ...formData, quantity: parseInt(e.target.value) })}
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Reference Type
                    </label>
                    <select
                      className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                      value={formData.reference_type}
                      onChange={(e) => setFormData({ ...formData, reference_type: e.target.value })}
                    >
                      <option value="manual">Manual</option>
                      <option value="purchase_order">Purchase Order</option>
                      <option value="sale">Sale</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Notes
                    </label>
                    <textarea
                      rows={3}
                      className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                      value={formData.notes}
                      onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                      placeholder="Optional notes about this movement"
                    />
                  </div>

                  <div className="flex justify-end space-x-3 pt-4">
                    <button
                      type="button"
                      onClick={() => {
                        setShowModal(false);
                        setFormData({
                          product_id: '',
                          magasin_id: '',
                          movement_type: 'in',
                          quantity: 1,
                          reference_type: 'manual',
                          reference_id: '',
                          notes: ''
                        });
                      }}
                      className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700"
                    >
                      Record Movement
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        )}

        {/* Filter Modal */}
        {showFilterModal && (
          <div style={{background:"#8080805e"}} className="fixed inset-0 bg-opacity-50 overflow-y-auto h-full w-full z-50">
            <div className="relative top-10 mx-auto p-5 border w-full max-w-2xl shadow-lg rounded-md bg-white">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-medium text-gray-900">Filter Stock & Movements</h3>
                <button
                  onClick={() => setShowFilterModal(false)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <X className="h-6 w-6" />
                </button>
              </div>

              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Product</label>
                    <input
                      type="text"
                      className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 text-sm"
                      placeholder="Enter product name"
                      value={filters.product}
                      onChange={(e) => handleFilterChange('product', e.target.value)}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Category</label>
                    <input
                      type="text"
                      className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 text-sm"
                      placeholder="Enter category name"
                      value={filters.category}
                      onChange={(e) => handleFilterChange('category', e.target.value)}
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">Magasin</label>
                  <input
                    type="text"
                    className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 text-sm"
                    placeholder="Enter magasin name"
                    value={filters.magasin}
                    onChange={(e) => handleFilterChange('magasin', e.target.value)}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Movement Type</label>
                    <select
                      className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 text-sm"
                      value={filters.movementType}
                      onChange={(e) => handleFilterChange('movementType', e.target.value)}
                    >
                      <option value="">All Movement Types</option>
                      <option value="in">Stock In</option>
                      <option value="out">Stock Out</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Reference Type</label>
                    <select
                      className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 text-sm"
                      value={filters.referenceType}
                      onChange={(e) => handleFilterChange('referenceType', e.target.value)}
                    >
                      <option value="">All Reference Types</option>
                      <option value="manual">Manual</option>
                      <option value="purchase_order">Purchase Order</option>
                      <option value="sale">Sale</option>
                    </select>
                  </div>
                </div>

                <div className="flex justify-end space-x-3 pt-4">
                  <button
                    onClick={clearAllFilters}
                    className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50"
                  >
                    Clear All
                  </button>
                  <button
                    onClick={() => setShowFilterModal(false)}
                    className="px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-md hover:bg-blue-700"
                  >
                    Apply Filters
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default StockManagement;