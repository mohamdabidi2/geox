import React from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Store, 
  Layers, 
  Package, 
  Users, 
  ShoppingCart, 
  FileText, 
  BarChart3 
} from 'lucide-react';

const StockCards = () => {
  const navigate = useNavigate();
  
  const cards = [
    {
      title: 'Gestion des Magasins',
      description: 'Gérez les magasins et leurs configurations',
      icon: Store,
      path: '/magasins',
      color: 'bg-blue-500'
    },
    {
      title: 'Gestion des Catégories',
      description: 'Créez et gérez les catégories de produits',
      icon: Layers,
      path: '/categories',
      color: 'bg-green-500'
    },
    {
      title: 'Gestion des Produits',
      description: 'Ajoutez et gérez les produits',
      icon: Package,
      path: '/products',
      color: 'bg-purple-500'
    },
    {
      title: 'Gestion des Fournisseurs',
      description: 'Gérez les fournisseurs et leurs contacts',
      icon: Users,
      path: '/suppliers',
      color: 'bg-orange-500'
    },
    {
      title: 'Demandes d\'Achat',
      description: 'Créez et suivez les demandes d\'achat',
      icon: FileText,
      path: '/purchase-requests',
      color: 'bg-red-500'
    },
    {
      title: 'Commandes d\'Achat',
      description: 'Gérez les commandes d\'achat',
      icon: ShoppingCart,
      path: '/purchase-orders',
      color: 'bg-indigo-500'
    },
    {
      title: 'Gestion des Stocks',
      description: 'Surveillez et gérez les niveaux de stock',
      icon: BarChart3,
      path: '/stock',
      color: 'bg-teal-500'
    }
  ];

  const handleCardClick = (path) => {
    navigate(path);
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 p-6">
      {cards.map((card, index) => {
        const IconComponent = card.icon;
        return (
          <div
            key={index}
            className="bg-white rounded-lg shadow-md p-6 cursor-pointer transition-all duration-200 hover:shadow-lg hover:transform hover:scale-105"
            onClick={() => handleCardClick(card.path)}
          >
            <div className="flex items-center mb-4">
              <div className={`p-3 rounded-full ${card.color} text-white`}>
                <IconComponent className="h-6 w-6" />
              </div>
              <h3 className="ml-4 text-lg font-semibold text-gray-900">
                {card.title}
              </h3>
            </div>
            <p className="text-sm text-gray-600">
              {card.description}
            </p>
            <div className="mt-4 text-sm text-blue-600 font-medium">
              Cliquer pour accéder →
            </div>
          </div>
        );
      })}
    </div>
  );
};

export default StockCards;