import { useState, useEffect } from 'react';
import { useAuth } from '../../hooks/useAuth';
import axios from 'axios';
import { Plus, ShoppingCart, Store, User, Mail, Eye } from 'lucide-react';

const PurchaseOrderManagement = () => {
  const { user } = useAuth();
  const [purchaseOrders, setPurchaseOrders] = useState([]);
  const [purchaseRequests, setPurchaseRequests] = useState([]);
  const [suppliers, setSuppliers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [formData, setFormData] = useState({
    demande_achat_ids: [],
    fournisseur_id: '',
    notes: '',
    magasin_id: user.magasin_id,
    created_by: user.id
  });
  const [filters, setFilters] = useState({
    orderNumber: '',
    supplier: '',
    status: '',
    createdBy: '',
    date: ''
  });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      setLoading(true);
      const [ordersRes, requestsRes, suppliersRes] = await Promise.all([
        axios.get('http://localhost:5000/api/purchase-orders/magasin/' + user.magasin_id),
        axios.get('http://localhost:5000/api/purchase-requests/magasin/' + user.magasin_id + '/approved'),
        axios.get('http://localhost:5000/api/suppliers/magasin/' + user.magasin_id)
      ]);

      setPurchaseOrders(ordersRes.data);

      const normalizedRequests = Array.isArray(requestsRes.data)
        ? requestsRes.data.map(req => ({
            ...req,
            items: req.products || [],
            products: req.products || [],
            total_amount: req.total_amount !== undefined
              ? req.total_amount
              : Array.isArray(req.products)
                ? req.products.reduce((sum, p) => sum + (parseFloat(p.unit_price || 0) * parseFloat(p.quantity || 0)), 0)
                : 0
          }))
        : [];
      setPurchaseRequests(normalizedRequests);
      setSuppliers(suppliersRes.data);
    } catch (error) {
      console.error('Error fetching data:', error);
      alert('Error fetching data');
    } finally {
      setLoading(false);
    }
  };

  const handleRequestChange = (selectedIds) => {
    const selectedRequests = purchaseRequests.filter(r => selectedIds.includes(r.id.toString()));
    const newTotalAmount = selectedRequests.reduce(
      (acc, r) =>
        acc +
        (r.total_amount !== undefined
          ? parseFloat(r.total_amount || 0)
          : Array.isArray(r.products)
            ? r.products.reduce((sum, p) => sum + (parseFloat(p.unit_price || 0) * parseFloat(p.quantity || 0)), 0)
            : 0),
      0
    );

    setFormData(prev => ({
      ...prev,
      demande_achat_ids: selectedIds.map(id => parseInt(id)),
      total_amount: newTotalAmount
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('http://localhost:5000/api/purchase-orders', {
        ...formData,
        magasin_id: user.magasin_id,
        created_by: user.id
      });
      alert(`Purchase order created successfully. Order Number: ${response.data.order_number}`);
      setShowModal(false);
      setFormData({
        demande_achat_ids: [],
        fournisseur_id: '',
        notes: '',
        magasin_id: user.magasin_id,
        created_by: user.id
      });
      fetchData();
    } catch (error) {
      console.error('Error creating purchase order:', error);
      alert('Error creating purchase order');
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'confirmed':
        return 'bg-green-100 text-green-800';
      case 'received':
        return 'bg-blue-100 text-blue-800';
      case 'cancelled':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-yellow-100 text-yellow-800';
    }
  };

  const filteredOrders = purchaseOrders.filter(order => {
    return (
      (filters.orderNumber === '' || order.order_number.toLowerCase().includes(filters.orderNumber.toLowerCase())) &&
      (filters.supplier === '' || order.fournisseur_name.toLowerCase().includes(filters.supplier.toLowerCase())) &&
      (filters.status === '' || order.status.toLowerCase() === filters.status.toLowerCase()) &&
      (filters.createdBy === '' || order.created_by_name.toLowerCase().includes(filters.createdBy.toLowerCase())) &&
      (filters.date === '' || new Date(order.created_at).toLocaleDateString().includes(filters.date))
    );
  });

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center w-full">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="w-full py-6 px-2 sm:px-4 lg:px-8">
      <div className="py-6 px-0 w-full">
        <div className="flex flex-col sm:flex-row sm:items-center w-full">
          <div className="flex-auto">
            <h1 className="text-3xl font-bold text-gray-900">Purchase Order Management</h1>
            <p className="mt-2 text-sm text-gray-700">
              Create purchase orders from approved requests and send to suppliers
            </p>
          </div>
          <div className="mt-4 sm:mt-0 sm:ml-16 sm:flex-none">
            <button
              onClick={() => setShowModal(true)}
              className="inline-flex items-center justify-center rounded-md border border-transparent bg-blue-600 px-4 py-2 text-sm font-medium text-white shadow-sm hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 sm:w-auto"
            >
              <Plus className="h-4 w-4 mr-2" />
              Create Order
            </button>
          </div>
        </div>

        {/* Filter Section */}
        <div className="mt-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
          <input
            type="text"
            placeholder="Filter by Order Number"
            className="border border-gray-300 rounded-md p-2"
            value={filters.orderNumber}
            onChange={(e) => setFilters({ ...filters, orderNumber: e.target.value })}
          />
          <input
            type="text"
            placeholder="Filter by Supplier"
            className="border border-gray-300 rounded-md p-2"
            value={filters.supplier}
            onChange={(e) => setFilters({ ...filters, supplier: e.target.value })}
          />
          <select
            className="border border-gray-300 rounded-md p-2"
            value={filters.status}
            onChange={(e) => setFilters({ ...filters, status: e.target.value })}
          >
            <option value="">Filter by Status</option>
            <option value="pending">Pending</option>
            <option value="sent">Sent</option>
            <option value="confirmed">Confirmed</option>
            <option value="received">Received</option>
            <option value="cancelled">Cancelled</option>
          </select>
          <input
            type="text"
            placeholder="Filter by Created By"
            className="border border-gray-300 rounded-md p-2"
            value={filters.createdBy}
            onChange={(e) => setFilters({ ...filters, createdBy: e.target.value })}
          />
          <input
            type="date"
            placeholder="Filter by Date"
            className="border border-gray-300 rounded-md p-2"
            value={filters.date}
            onChange={(e) => setFilters({ ...filters, date: e.target.value })}
          />
        </div>

        <div className="mt-8 flex flex-col w-full">
          <div className="-my-2 -mx-2 overflow-x-auto w-full">
            <div className="inline-block min-w-full py-2 align-middle px-2">
              <div className="overflow-x-auto shadow ring-1 ring-black ring-opacity-5 rounded-lg w-full">
                <table className="min-w-full divide-y divide-gray-300 w-full">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Order Number
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Supplier
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Items
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Total Amount
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Status
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Created By
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Date
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {filteredOrders.map((order) => (
                      <tr key={order.id}>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <ShoppingCart className="h-5 w-5 text-gray-400 mr-3" />
                            <div className="text-sm font-medium text-gray-900">
                              {order.order_number}
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <User className="h-4 w-4 text-gray-400 mr-2" />
                            <span className="text-sm text-gray-900">
                              {order.fournisseur_name || order.fournisseur_name}
                            </span>
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <div className="text-sm text-gray-900">
                            {(() => {
                              let items = [];
                              if (order.items) {
                                try {
                                  items = JSON.parse(order.items);
                                } catch {
                                  items = [];
                                }
                              } else if (order.products) {
                                try {
                                  items = Array.isArray(order.products)
                                    ? order.products
                                    : JSON.parse(order.products);
                                } catch {
                                  items = [];
                                }
                              }
                              return items.length;
                            })()} items
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm font-medium text-gray-900">
                            ${parseFloat(order.total_amount || 0).toFixed(2)}
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(order.status)}`}>
                            {order.status}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <User className="h-4 w-4 text-gray-400 mr-2" />
                            <span className="text-sm text-gray-900">
                              {order.created_by_name || order.created_by}
                            </span>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {new Date(order.created_at).toLocaleDateString()}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                          <button
                            onClick={() => alert('View Order ' + order.id)}
                            className="text-blue-600 hover:text-blue-900"
                          >
                            <Eye className="h-5 w-5" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

        {/* Modal */}
        {showModal && (
          <div style={{background:"#8080805e"}} className="fixed inset-0  bg-opacity-50 overflow-y-auto h-full w-full z-50">
            <div className="relative top-20 mx-auto p-5 border w-full max-w-5xl shadow-lg rounded-md bg-white max-h-[90vh] overflow-y-auto">
              <div className="mt-3">
                <h3 className="text-lg font-medium text-gray-900 mb-4">
                  Create Purchase Order
                </h3>

                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Supplier
                    </label>
                    <select
                      required
                      className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                      value={formData.fournisseur_id}
                      onChange={(e) => {
                        setFormData({ ...formData, fournisseur_id: e.target.value, demande_achat_ids: [] });
                      }}
                    >
                      <option value="">Select Supplier</option>
                      {suppliers.map((supplier) => (
                        <option key={supplier.id} value={supplier.id}>
                          {supplier.name} - {supplier.country} ({supplier.email})
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Purchase Requests (Select multiple)
                    </label>
                    <select
                      required
                      multiple
                      className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                      value={formData.demande_achat_ids}
                      onChange={(e) =>
                        handleRequestChange(
                          Array.from(e.target.options)
                            .filter(option => option.selected)
                            .map(option => option.value)
                        )
                      }
                      disabled={!formData.fournisseur_id}
                    >
                      {purchaseRequests.map((request) => (
                        <option key={request.id} value={request.id}>
                          PR-{request.id} - {request.magasin_name}
                          {typeof request.total_amount !== 'undefined'
                            ? ` ($${parseFloat(request.total_amount).toFixed(2)})`
                            : request.products && Array.isArray(request.products)
                              ? ` ($${request.products.reduce((sum, p) => sum + (parseFloat(p.unit_price || 0) * parseFloat(p.quantity || 0)), 0).toFixed(2)})`
                              : ''}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Notes (Optional)
                    </label>
                    <textarea
                      className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                      value={formData.notes}
                      onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                      rows={3}
                      placeholder="Additional notes for the supplier..."
                    />
                  </div>

                  <div className="bg-gray-50 p-3 rounded-md">
                    <div className="text-lg font-medium text-gray-900">
                      Total Amount: ${formData.total_amount?.toFixed(2) || '0.00'}
                    </div>
                  </div>

                  <div className="flex justify-end space-x-3 pt-4">
                    <button
                      type="button"
                      onClick={() => {
                        setShowModal(false);
                        setFormData({
                          demande_achat_ids: [],
                          fournisseur_id: '',
                          notes: '',
                          magasin_id: user.magasin_id,
                          created_by: user.id
                        });
                      }}
                      className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700"
                    >
                      Create & Send Order
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default PurchaseOrderManagement;


