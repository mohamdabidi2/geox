import React, { useState, useEffect, useRef } from 'react';
import {
  Search,
  Filter,
  CheckCircle,
  Plus,
  X,
  ChevronLeft,
  ChevronRight,
  Edit,
  Trash2,
  Eye
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import axiosInstance from '@/utils/axiosInstance';

const POSTE_OPTIONS = [
  "Warehouse Manager",
  "Sales Rep",
  "HR Lead",
  "Accountant",
  "CRM Specialist",
  "Chef",
  "Head Chef",
  "Kitchen Manager"
];

const UserManagement = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const [editingUserId, setEditingUserId] = useState(null);
  const [users, setUsers] = useState([]);
  const [chefs, setChefs] = useState([]);
  const [filteredChefs, setFilteredChefs] = useState([]);
  const [chefSearchQuery, setChefSearchQuery] = useState('');
  const [magasins, setMagasins] = useState([]);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    email: '',
    firstname: '',
    lastname: '',
    poste: '',
    magasin_id: '',
    responsibleChefs: []
  });
  const [formError, setFormError] = useState('');

  // Filters state
  const [searchQuery, setSearchQuery] = useState('');
  const [filterPoste, setFilterPoste] = useState('');
  const [filterValidEmail, setFilterValidEmail] = useState('');
  const [filterRh, setFilterRh] = useState('');
  const [filterDirection, setFilterDirection] = useState('');
  const [filterMagasin, setFilterMagasin] = useState('');
  const [showFilters, setShowFilters] = useState(false);

  // Show detail modal
  const [showDetailUser, setShowDetailUser] = useState(null);

  // Ref for the select element to control selection programmatically
  const chefSelectRef = useRef(null);

  const fetchUsers = async () => {
    try {
      setLoading(true);
      const response = await axiosInstance.get(`/users`);
      const data = response.data;

      if (data.success) {
        setUsers(data.data);
      } else {
        console.error('Failed to fetch users:', data.message);
      }
    } catch (error) {
      console.error('Error fetching users:', error);
    } finally {
      setLoading(false);
    }
  };

  // Fetch magasins from backend
  const fetchMagasins = async () => {
    try {
      const response = await axiosInstance.get(`/magasins`);
      setMagasins(response.data);
    } catch (error) {
      console.error('Error fetching magasins:', error);
    }
  };

  // Fetch chefs from backend
  const fetchChefs = async () => {
    try {
      const response = await axiosInstance.get(`/users/chefs`);
      const data = response.data;

      if (data.success) {
        setChefs(data.data);
        setFilteredChefs(data.data);
      } else {
        console.error('Failed to fetch chefs:', data.message);
      }
    } catch (error) {
      console.error('Error fetching chefs:', error);
    }
  };

  // Search chefs functionality
  const searchChefs = async (query) => {
    if (!query.trim()) {
      setFilteredChefs(chefs);
      return;
    }

    try {
      const response = await axiosInstance.get(`/users/chefs/search?q=${encodeURIComponent(query)}`);
      const data = response.data;

      if (data.success) {
        setFilteredChefs(data.data);
      } else {
        console.error('Failed to search chefs:', data.message);
      }
    } catch (error) {
      console.error('Error searching chefs:', error);
      // Fallback to local filtering
      const filtered = chefs.filter(chef =>
        chef.firstname.toLowerCase().includes(query.toLowerCase()) ||
        chef.lastname.toLowerCase().includes(query.toLowerCase()) ||
        chef.email.toLowerCase().includes(query.toLowerCase())
      );
      setFilteredChefs(filtered);
    }
  };

  // Load data on component mount
  useEffect(() => {
    fetchUsers();
    fetchChefs();
    fetchMagasins();
  }, []);

  // Handle chef search
  useEffect(() => {
    const timeoutId = setTimeout(() => {
      searchChefs(chefSearchQuery);
    }, 300); // Debounce search

    return () => clearTimeout(timeoutId);
  }, [chefSearchQuery, chefs]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    setFormError('');
  };

  // Handle multiple chef selection using the select's selectedOptions
  const handleChefSelection = (e) => {
    const selectedOptions = Array.from(e.target.selectedOptions, option => {
      const chef = filteredChefs.find(c => c.id.toString() === option.value);
      return chef
        ? {
            id: chef.id,
            firstname: chef.firstname,
            lastname: chef.lastname,
            email: chef.email
          }
        : null;
    }).filter(Boolean);

    setFormData(prev => ({
      ...prev,
      responsibleChefs: selectedOptions
    }));
    setFormError('');
  };

  // Keep the select element's options selected in sync with formData.responsibleChefs
  useEffect(() => {
    if (chefSelectRef.current) {
      const select = chefSelectRef.current;
      for (let i = 0; i < select.options.length; i++) {
        const option = select.options[i];
        option.selected = formData.responsibleChefs.some(selected => selected.id.toString() === option.value);
      }
    }
  }, [formData.responsibleChefs, filteredChefs, isModalOpen]);

  // Client-side validation for required fields
  const validateForm = () => {
    const { email, firstname, lastname, poste } = formData;
    if (!email.trim() || !firstname.trim() || !lastname.trim() || !poste.trim()) {
      setFormError('Email, Firstname, Lastname, and Poste are required.');
      return false;
    }
    return true;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    setFormError('');
    if (!validateForm()) {
      return;
    }

    try {
      setLoading(true);

      // Prepare data for submission
      const submitData = {
        ...formData,
        magasin_id: formData.magasin_id || null,
        responsibleChefs: formData.responsibleChefs.length > 0 ? formData.responsibleChefs : []
      };

      let response;
      if (isEditMode && editingUserId) {
        // Update existing user
        response = await axiosInstance.put(`/users/${editingUserId}`, submitData, {
          headers: {
            'Content-Type': 'application/json',
          }
        });
      } else {
        // Create new user - use the users endpoint instead of auth/register
        response = await axiosInstance.post('/auth/register', submitData, {
          headers: {
            'Content-Type': 'application/json',
          }
        });
      }

      const data = response.data;

      if (data.success) {
        setIsModalOpen(false);
        setIsEditMode(false);
        setEditingUserId(null);
        setFormData({
          email: '',
          firstname: '',
          lastname: '',
          poste: '',
          magasin_id: '',
          responsibleChefs: []
        });
        setFormError('');
        fetchUsers();
      } else {
        setFormError(data.message || `Failed to ${isEditMode ? 'update' : 'create'} user.`);
      }
    } catch (error) {
      let backendMsg = `Error ${isEditMode ? 'updating' : 'creating'} user. Please try again.`;
      if (error.response && error.response.data && error.response.data.message) {
        backendMsg = error.response.data.message;
      }
      setFormError(backendMsg);
    } finally {
      setLoading(false);
    }
  };

  // Handle edit user
  const handleEditUser = (user) => {
    setFormData({
      email: user.email,
      firstname: user.firstname,
      lastname: user.lastname,
      poste: user.poste,
      magasin_id: user.magasin_id || '',
      responsibleChefs: user.responsibleChefs || []
    });
    setIsEditMode(true);
    setEditingUserId(user.id);
    setFormError('');
    setIsModalOpen(true);
  };

  // Handle show detail user
  const handleShowDetailUser = (user) => {
    setShowDetailUser(user);
  };

  // Handle delete user
  const handleDeleteUser = async (userId) => {
    if (!window.confirm('Are you sure you want to delete this user?')) {
      return;
    }

    try {
      setLoading(true);
      const response = await axiosInstance.delete(`/users/${userId}`);
      const data = response.data;

      if (data.success) {
        fetchUsers();
      } else {
        alert(`Error: ${data.message}`);
      }
    } catch (error) {
      alert('Error deleting user. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  // Handle validation actions (now used by select)
  const handleValidationSelect = async (userId, validationType, value) => {
    try {
      setLoading(true);
      const response = await axiosInstance.put(`/users/${userId}/validate-${validationType}`, {
        isValid: value === "true" || value === true
      });
      const data = response.data;

      if (data.success) {
        fetchUsers();
      } else {
        alert(`Error: ${data.message}`);
      }
    } catch (error) {
      alert(`Error updating ${validationType} validation. Please try again.`);
    } finally {
      setLoading(false);
    }
  };

  const getStatusBadge = (status) => {
    const baseClasses = "px-2 py-1 rounded text-xs font-medium";
    if (status === true || status === 1) {
      return `${baseClasses} bg-green-100 text-green-800`;
    } else if (status === false || status === 0) {
      return `${baseClasses} bg-red-100 text-red-800`;
    }
    switch (status) {
      case 'Valid':
        return `${baseClasses} bg-green-100 text-green-800`;
      case 'Invalid':
        return `${baseClasses} bg-red-100 text-red-800`;
      case 'Verified':
        return `${baseClasses} bg-blue-100 text-blue-800`;
      case 'Pending':
        return `${baseClasses} bg-yellow-100 text-yellow-800`;
      default:
        return `${baseClasses} bg-gray-100 text-gray-800`;
    }
  };

  const formatStatusText = (status) => {
    if (status === true || status === 1) {
      return 'Valid';
    } else if (status === false || status === 0) {
      return 'Invalid';
    }
    return status || 'Unknown';
  };

  // Reset modal state when opening for new user
  const handleNewUser = () => {
    setFormData({
      email: '',
      firstname: '',
      lastname: '',
      poste: '',
      magasin_id: '',
      responsibleChefs: []
    });
    setIsEditMode(false);
    setEditingUserId(null);
    setFormError('');
    setIsModalOpen(true);
  };

  // Close modal and reset state
  const handleCloseModal = () => {
    setIsModalOpen(false);
    setIsEditMode(false);
    setEditingUserId(null);
    setFormData({
      email: '',
      firstname: '',
      lastname: '',
      poste: '',
      magasin_id: '',
      responsibleChefs: []
    });
    setFormError('');
  };

  // Filtering logic
  const filteredUsers = users.filter(user => {
    // Search
    const searchLower = searchQuery.trim().toLowerCase();
    let matchesSearch = true;
    if (searchLower) {
      matchesSearch =
        (user.firstname && user.firstname.toLowerCase().includes(searchLower)) ||
        (user.lastname && user.lastname.toLowerCase().includes(searchLower)) ||
        (user.email && user.email.toLowerCase().includes(searchLower)) ||
        (user.poste && user.poste.toLowerCase().includes(searchLower)) ||
        (user.magasin && user.magasin.name && user.magasin.name.toLowerCase().includes(searchLower));
    }
    // Poste
    let matchesPoste = true;
    if (filterPoste) {
      matchesPoste = user.poste === filterPoste;
    }
    // Valid Email
    let matchesValidEmail = true;
    if (filterValidEmail) {
      if (filterValidEmail === 'valid') matchesValidEmail = user.validEmail === true || user.validEmail === 1;
      else if (filterValidEmail === 'invalid') matchesValidEmail = user.validEmail === false || user.validEmail === 0;
    }
    // RH
    let matchesRh = true;
    if (filterRh) {
      if (filterRh === 'valid') matchesRh = user.verifiedProfileRh === true || user.verifiedProfileRh === 1;
      else if (filterRh === 'invalid') matchesRh = user.verifiedProfileRh === false || user.verifiedProfileRh === 0;
    }
    // Direction
    let matchesDirection = true;
    if (filterDirection) {
      if (filterDirection === 'valid') matchesDirection = user.verifiedProfileDirection === true || user.verifiedProfileDirection === 1;
      else if (filterDirection === 'invalid') matchesDirection = user.verifiedProfileDirection === false || user.verifiedProfileDirection === 0;
    }
    // Magasin
    let matchesMagasin = true;
    if (filterMagasin) {
      matchesMagasin = user.magasin_id && user.magasin_id.toString() === filterMagasin;
    }
    return matchesSearch && matchesPoste && matchesValidEmail && matchesRh && matchesDirection && matchesMagasin;
  });

  return (
    <div className="flex flex-col min-h-screen" style={{ width: "83vw" }}>
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-8 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="relative">
              <Search className="w-5 h-5 text-gray-400 absolute left-3 top-1/2 transform -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search users..."
                className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none w-80"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
              />
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <span className="text-sm font-medium text-gray-700">Admin</span>
            <div className="w-8 h-8 bg-red-500 rounded-full"></div>
          </div>
        </div>
      </div>

      {/* Users Section */}
      <div className="flex-1 px-8 py-6">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-semibold text-gray-900">Users</h1>
          <div className="flex items-center space-x-3">
            <Button
              variant="outline"
              className="flex items-center space-x-2"
              onClick={() => setShowFilters(f => !f)}
            >
              <Filter className="w-4 h-4" />
              <span>Filters</span>
            </Button>
            <Button
              variant={filterValidEmail === 'valid' ? "default" : "outline"}
              className="flex items-center space-x-2"
              onClick={() => setFilterValidEmail(filterValidEmail === 'valid' ? '' : 'valid')}
            >
              <CheckCircle className="w-4 h-4" />
              <span>Valid only</span>
            </Button>
            <Button
              onClick={handleNewUser}
              className="bg-blue-600 hover:bg-blue-700 text-white flex items-center space-x-2"
              disabled={loading}
            >
              <Plus className="w-4 h-4" />
              <span>New User</span>
            </Button>
          </div>
        </div>

        {/* Filters Panel */}
        {showFilters && (
          <div className="mb-6 bg-gray-50 border border-gray-200 rounded-lg p-4 flex flex-wrap gap-4">
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">Poste</label>
              <select
                className="border border-gray-300 rounded px-2 py-1"
                value={filterPoste}
                onChange={e => setFilterPoste(e.target.value)}
              >
                <option value="">All</option>
                {POSTE_OPTIONS.map(poste => (
                  <option key={poste} value={poste}>{poste}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">Valid Email</label>
              <select
                className="border border-gray-300 rounded px-2 py-1"
                value={filterValidEmail}
                onChange={e => setFilterValidEmail(e.target.value)}
              >
                <option value="">All</option>
                <option value="valid">Valid</option>
                <option value="invalid">Invalid</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">HR Check</label>
              <select
                className="border border-gray-300 rounded px-2 py-1"
                value={filterRh}
                onChange={e => setFilterRh(e.target.value)}
              >
                <option value="">All</option>
                <option value="valid">Valid</option>
                <option value="invalid">Invalid</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">Director Check</label>
              <select
                className="border border-gray-300 rounded px-2 py-1"
                value={filterDirection}
                onChange={e => setFilterDirection(e.target.value)}
              >
                <option value="">All</option>
                <option value="valid">Valid</option>
                <option value="invalid">Invalid</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">Magasin</label>
              <select
                className="border border-gray-300 rounded px-2 py-1"
                value={filterMagasin}
                onChange={e => setFilterMagasin(e.target.value)}
              >
                <option value="">All</option>
                {magasins.map(magasin => (
                  <option key={magasin.id} value={magasin.id}>
                    {magasin.name}
                  </option>
                ))}
              </select>
            </div>
            <div className="flex items-end">
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  setFilterPoste('');
                  setFilterValidEmail('');
                  setFilterRh('');
                  setFilterDirection('');
                  setFilterMagasin('');
                }}
              >
                Reset
              </Button>
            </div>
          </div>
        )}

        {/* Loading indicator */}
        {loading && (
          <div className="text-center py-4">
            <p className="text-gray-600">Loading...</p>
          </div>
        )}

        {/* Users Table */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Email</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Poste</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Responsible Chefs</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">validEmail</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">HR Check</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Director Check</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredUsers.map((user, index) => (
                <tr key={user.id || index} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    {`${user.firstname} ${user.lastname}`}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">{user.email}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">{user.poste || '-'}</td>
            
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                    {user.responsibleChefs && user.responsibleChefs.length > 0
                      ? user.responsibleChefs.map(chef =>
                        typeof chef === 'object'
                          ? `${chef.firstname} ${chef.lastname}`
                          : chef
                      ).join(', ')
                      : '-'
                    }
                  </td>
                  {/* VALID EMAIL */}
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center space-x-2">
                      <span className={getStatusBadge(user.validEmail)}>
                        {formatStatusText(user.validEmail)}
                      </span>
                      <select
                        className="border border-gray-300 rounded px-1 py-0.5 text-xs"
                        style={{ minWidth: 70 }}
                        value={
                          user.validEmail === true || user.validEmail === 1
                            ? "true"
                            : user.validEmail === false || user.validEmail === 0
                            ? "false"
                            : ""
                        }
                        onChange={e =>
                          handleValidationSelect(user.id, 'email', e.target.value)
                        }
                      >
                        <option value="true">Valid</option>
                        <option value="false">Invalid</option>
                      </select>
                    </div>
                  </td>
                  {/* HR CHECK */}
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center space-x-2">
                      <span className={getStatusBadge(user.verifiedProfileRh)}>
                        {formatStatusText(user.verifiedProfileRh)}
                      </span>
                      <select
                        className="border border-gray-300 rounded px-1 py-0.5 text-xs"
                        style={{ minWidth: 70 }}
                        value={
                          user.verifiedProfileRh === true || user.verifiedProfileRh === 1
                            ? "true"
                            : user.verifiedProfileRh === false || user.verifiedProfileRh === 0
                            ? "false"
                            : ""
                        }
                        onChange={e =>
                          handleValidationSelect(user.id, 'rh', e.target.value)
                        }
                      >
                        <option value="true">Valid</option>
                        <option value="false">Invalid</option>
                      </select>
                    </div>
                  </td>
                  {/* DIRECTOR CHECK */}
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center space-x-2">
                      <span className={getStatusBadge(user.verifiedProfileDirection)}>
                        {formatStatusText(user.verifiedProfileDirection)}
                      </span>
                      <select
                        className="border border-gray-300 rounded px-1 py-0.5 text-xs"
                        style={{ minWidth: 70 }}
                        value={
                          user.verifiedProfileDirection === true || user.verifiedProfileDirection === 1
                            ? "true"
                            : user.verifiedProfileDirection === false || user.verifiedProfileDirection === 0
                            ? "false"
                            : ""
                        }
                        onChange={e =>
                          handleValidationSelect(user.id, 'direction', e.target.value)
                        }
                      >
                        <option value="true">Valid</option>
                        <option value="false">Invalid</option>
                      </select>
                    </div>
                  </td>
                  {/* ACTIONS: ICONS ONLY */}
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center space-x-2">
                      <button
                        onClick={() => handleShowDetailUser(user)}
                        className="p-1 rounded hover:bg-gray-100"
                        title="Detail"
                        type="button"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleEditUser(user)}
                        className="p-1 rounded hover:bg-gray-100"
                        title="Edit"
                        type="button"
                      >
                        <Edit className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDeleteUser(user.id)}
                        className="p-1 rounded hover:bg-gray-100 text-red-600 hover:text-red-800"
                        title="Delete"
                        type="button"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              {filteredUsers.length === 0 && !loading && (
                <tr>
                  <td colSpan="9" className="px-6 py-4 text-center text-gray-500">
                    No users found
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="flex items-center justify-between mt-6">
          <p className="text-sm text-gray-600">Showing {filteredUsers.length} users</p>
          <div className="flex items-center space-x-2">
            <Button variant="outline" size="sm" className="flex items-center space-x-1" disabled>
              <ChevronLeft className="w-4 h-4" />
              <span>Prev</span>
            </Button>
            <Button variant="outline" size="sm" className="flex items-center space-x-1" disabled>
              <span>Next</span>
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* Detail Modal */}
      {showDetailUser && (
        <div className="fixed inset-0  flex items-center justify-center z-50" style={{backgroundColor:"#0000004b"}}>
          <div className="bg-white rounded-lg p-6 w-full max-w-lg mx-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold text-gray-900">
                User Details
              </h2>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowDetailUser(null)}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="w-5 h-5" />
              </Button>
            </div>
            <div className="space-y-2">
              <div><span className="font-semibold">Name:</span> {showDetailUser.firstname} {showDetailUser.lastname}</div>
              <div><span className="font-semibold">Email:</span> {showDetailUser.email}</div>
              <div><span className="font-semibold">Poste:</span> {showDetailUser.poste}</div>
          
              <div>
                <span className="font-semibold">Responsible Chefs:</span>{" "}
                {showDetailUser.responsibleChefs && showDetailUser.responsibleChefs.length > 0
                  ? showDetailUser.responsibleChefs.map(chef =>
                    typeof chef === 'object'
                      ? `${chef.firstname} ${chef.lastname}`
                      : chef
                  ).join(', ')
                  : '-'
                }
              </div>
              <div>
                <span className="font-semibold">Valid Email:</span>{" "}
                <span className={getStatusBadge(showDetailUser.validEmail)}>
                  {formatStatusText(showDetailUser.validEmail)}
                </span>
              </div>
              <div>
                <span className="font-semibold">HR Check:</span>{" "}
                <span className={getStatusBadge(showDetailUser.verifiedProfileRh)}>
                  {formatStatusText(showDetailUser.verifiedProfileRh)}
                </span>
              </div>
              <div>
                <span className="font-semibold">Director Check:</span>{" "}
                <span className={getStatusBadge(showDetailUser.verifiedProfileDirection)}>
                  {formatStatusText(showDetailUser.verifiedProfileDirection)}
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal */}
      {isModalOpen && (
        <div className="fixed inset-0  flex items-center justify-center z-50" style={{backgroundColor:"#0000004b"}}>
          <div className="bg-white rounded-lg p-6 w-full max-w-2xl mx-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold text-gray-900">
                {isEditMode ? 'Edit User' : 'New User'}
              </h2>
              <Button
                variant="ghost"
                size="sm"
                onClick={handleCloseModal}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="w-5 h-5" />
              </Button>
            </div>

            <p className="text-sm text-gray-600 mb-6">
              Email, Firstname, Lastname, and Poste are required. Magasin and Responsible Chefs are optional.
            </p>

            {formError && (
              <div className="mb-4">
                <div className="p-3 bg-red-100 border border-red-300 rounded text-sm text-red-700">
                  {formError}
                </div>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    placeholder="user@company.com"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Firstname</label>
                  <input
                    type="text"
                    name="firstname"
                    value={formData.firstname}
                    onChange={handleInputChange}
                    placeholder="John"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Lastname</label>
                  <input
                    type="text"
                    name="lastname"
                    value={formData.lastname}
                    onChange={handleInputChange}
                    placeholder="Doe"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Poste <span className="text-red-500">*</span></label>
                  <select
                    name="poste"
                    value={formData.poste}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
                    required
                  >
                    <option value="">Select a post</option>
                    {POSTE_OPTIONS.map(poste => (
                      <option key={poste} value={poste}>{poste}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Magasin (optional)</label>
                  <select
                    name="magasin_id"
                    value={formData.magasin_id}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
                  >
                    <option value="">Select a magasin</option>
                    {magasins.map(magasin => (
                      <option key={magasin.id} value={magasin.id}>
                        {magasin.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Search and Select Responsible Chefs (optional)
                </label>
                <div className="space-y-2">
                  <input
                    type="text"
                    placeholder="Search chefs by name or email..."
                    value={chefSearchQuery}
                    onChange={(e) => setChefSearchQuery(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
                  />
                  <select
                    multiple
                    name="responsibleChefs"
                    onChange={handleChefSelection}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none h-32"
                    size="6"
                    ref={chefSelectRef}
                  >
                    {filteredChefs.map((chef) => (
                      <option
                        key={chef.id}
                        value={chef.id}
                      >
                        {`${chef.firstname} ${chef.lastname} (${chef.email})`}
                      </option>
                    ))}
                  </select>
                  <p className="text-xs text-gray-500">
                    Hold Ctrl/Cmd to select multiple chefs. {filteredChefs.length} chef(s) available.
                  </p>
                </div>
              </div>

              {/* Selected chefs display */}
              {formData.responsibleChefs.length > 0 && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Selected Chefs:</label>
                  <div className="flex flex-wrap gap-2">
                    {formData.responsibleChefs.map((chef, index) => (
                      <span
                        key={index}
                        className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full flex items-center"
                      >
                        {`${chef.firstname} ${chef.lastname}`}
                        <button
                          type="button"
                          onClick={() => {
                            setFormData(prev => ({
                              ...prev,
                              responsibleChefs: prev.responsibleChefs.filter((_, i) => i !== index)
                            }));
                          }}
                          className="ml-1 text-blue-600 hover:text-blue-800"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </span>
                    ))}
                  </div>
                </div>
              )}

              <div className="flex justify-end space-x-3 pt-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={handleCloseModal}
                  disabled={loading}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  className="bg-blue-600 hover:bg-blue-700 text-white"
                  disabled={loading}
                >
                  {loading ? 'Processing...' : isEditMode ? 'Update User' : 'Create User'}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default UserManagement;