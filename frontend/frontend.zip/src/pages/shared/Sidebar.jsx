import React from 'react';
import { Grid3X3 } from 'lucide-react';

const Sidebar = ({ navigationItems = [], supportItems = [], activeItem = '' }) => {
  return (
    <div className="w-72 bg-slate-800 text-white flex flex-col fixed h-screen">
      {/* Logo/Brand */}
      <div className="p-6 border-b border-slate-700">
        <div className="w-12 h-12 bg-white rounded-lg flex items-center justify-center">
          <Grid3X3 className="w-6 h-6 text-slate-800" />
        </div>
      </div>

      {/* Navigation */}
      <div className="flex-1 px-4 py-6">
        {/* Main Navigation */}
        {navigationItems.length > 0 && (
          <div className="mb-8">
            <h3 className="text-sm font-medium text-slate-400 mb-4 px-2">
              {navigationItems.some(item => item.section) ? navigationItems[0].section : 'Main'}
            </h3>
            <nav className="space-y-2">
              {navigationItems.map((item, index) => (
                <a
                  key={index}
                  href={item.href || '#'}
                  onClick={item.onClick}
                  className={`flex items-center px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                    item.label === activeItem || item.active
                      ? 'bg-blue-600 text-white'
                      : 'text-slate-300 hover:bg-slate-700 hover:text-white'
                  }`}
                >
                  <item.icon className="w-5 h-5 mr-3" />
                  {item.label}
                </a>
              ))}
            </nav>
          </div>
        )}

        {/* Support Navigation */}
        {supportItems.length > 0 && (
          <div>
            <h3 className="text-sm font-medium text-slate-400 mb-4 px-2">
              {supportItems.some(item => item.section) ? supportItems[0].section : 'Support'}
            </h3>
            <nav className="space-y-2">
              {supportItems.map((item, index) => (
                <a
                  key={index}
                  href={item.href || '#'}
                  onClick={item.onClick}
                  className={`flex items-center px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                    item.label === activeItem || item.active
                      ? 'bg-blue-600 text-white'
                      : 'text-slate-300 hover:bg-slate-700 hover:text-white'
                  }`}
                >
                  <item.icon className="w-5 h-5 mr-3" />
                  {item.label}
                </a>
              ))}
            </nav>
          </div>
        )}

        {/* Single Navigation Section (for UserManagement style) */}
        {navigationItems.length === 0 && supportItems.length === 0 && (
          <div>
            <h3 className="text-sm font-medium text-slate-400 mb-4 px-2">Navigation</h3>
            <nav className="space-y-2">
              {/* Default navigation items will be passed as navigationItems */}
            </nav>
          </div>
        )}
      </div>
    </div>
  );
};

export default Sidebar;

