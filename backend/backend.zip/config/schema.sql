-- Create database
CREATE DATABASE IF NOT EXISTS geox_erp;
USE geox_erp;

-- Create users table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    firstname VARCHAR(100) NOT NULL,
    lastname VARCHAR(100) NOT NULL,
    poste VARCHAR(100) NOT NULL,
    responsibleChefs JSON DEFAULT NULL,
    isAdmin BOOLEAN DEFAULT FALSE,
    photo VARCHAR(255) DEFAULT 'default.jpg',
    validEmail BOOLEAN DEFAULT FALSE,
    verifiedProfileRh BOOLEAN DEFAULT FALSE,
    verifiedProfileDirection BOOLEAN DEFAULT FALSE,
    password VARCHAR(255) DEFAULT NULL,
    emailVerificationToken VARCHAR(255) DEFAULT NULL,
    emailVerificationExpires DATETIME DEFAULT NULL,
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Create index on email for faster lookups
CREATE INDEX idx_users_email ON users(email);

-- Create index on verification token
CREATE INDEX idx_users_verification_token ON users(emailVerificationToken);

