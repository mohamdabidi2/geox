const { pool } = require('../config/database');
const bcrypt = require('bcrypt');

class User {
    constructor(userData) {
        this.id = userData.id;
        this.email = userData.email;
        this.firstname = userData.firstname;
        this.lastname = userData.lastname;
        this.poste = userData.poste;
        this.responsibleChefs = userData.responsibleChefs;
        this.isAdmin = userData.isAdmin || false;
        this.photo = userData.photo || 'default.jpg';
        this.validEmail = userData.validEmail || false;
        this.verifiedProfileRh = userData.verifiedProfileRh || false;
        this.verifiedProfileDirection = userData.verifiedProfileDirection || false;
        this.password = userData.password;
        this.emailVerificationToken = userData.emailVerificationToken;
        this.emailVerificationExpires = userData.emailVerificationExpires;
        this.magasin_id = userData.magasin_id; // Added magasin_id field
        this.createdAt = userData.createdAt;
        this.updatedAt = userData.updatedAt;
        
        // For convenience, you might want to store the full magasin object if joined
        this.magasin = userData.magasin;
    }

    // Create a new user - UPDATED with magasin_id
    static async create(userData) {
        const connection = await pool.getConnection();
        try {
            // Sanitize all parameters to avoid undefined values
            const sanitizedData = {
                email: userData.email,
                firstname: userData.firstname,
                lastname: userData.lastname,
                poste: userData.poste,
                responsibleChefs: userData.responsibleChefs ? JSON.stringify(userData.responsibleChefs) : null,
                isAdmin: userData.isAdmin || false,
                photo: userData.photo || 'default.jpg',
                validEmail: userData.validEmail || false,
                verifiedProfileRh: userData.verifiedProfileRh || false,
                verifiedProfileDirection: userData.verifiedProfileDirection || false,
                password: userData.password || null,
                emailVerificationToken: userData.emailVerificationToken || null,
                emailVerificationExpires: userData.emailVerificationExpires || null,
                magasin_id: userData.magasin_id || null // Added magasin_id
            };

            const [result] = await connection.execute(
                `INSERT INTO users (email, firstname, lastname, poste, responsibleChefs, isAdmin, photo, validEmail, verifiedProfileRh, verifiedProfileDirection, password, emailVerificationToken, emailVerificationExpires, magasin_id)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                [
                    sanitizedData.email,
                    sanitizedData.firstname,
                    sanitizedData.lastname,
                    sanitizedData.poste,
                    sanitizedData.responsibleChefs,
                    sanitizedData.isAdmin,
                    sanitizedData.photo,
                    sanitizedData.validEmail,
                    sanitizedData.verifiedProfileRh,
                    sanitizedData.verifiedProfileDirection,
                    sanitizedData.password,
                    sanitizedData.emailVerificationToken,
                    sanitizedData.emailVerificationExpires,
                    sanitizedData.magasin_id
                ]
            );
            return result.insertId;
        } finally {
            connection.release();
        }
    }

    // Alternative simpler create method for registration - UPDATED with magasin_id
    static async createForRegistration(userData) {
        const connection = await pool.getConnection();
        try {
            const [result] = await connection.execute(
                `INSERT INTO users (email, firstname, lastname, poste, responsibleChefs, isAdmin, magasin_id)
                 VALUES (?, ?, ?, ?, ?, ?, ?)`,
                [
                    userData.email,
                    userData.firstname,
                    userData.lastname,
                    userData.poste,
                    userData.responsibleChefs ? JSON.stringify(userData.responsibleChefs) : null,
                    userData.isAdmin || false,
                    userData.magasin_id || null
                ]
            );
            return result.insertId;
        } finally {
            connection.release();
        }
    }

    // Find user by email - UPDATED to include magasin data if needed
    static async findByEmail(email, includeMagasin = false) {
        const connection = await pool.getConnection();
        try {
            let query = 'SELECT u.*';
            if (includeMagasin) {
                query += ', m.id as magasin_id, m.name as magasin_name, m.address as magasin_address, m.city as magasin_city';
            }
            query += ' FROM users u';
            if (includeMagasin) {
                query += ' LEFT JOIN magasins m ON u.magasin_id = m.id';
            }
            query += ' WHERE u.email = ?';
            
            const [rows] = await connection.execute(query, [email]);
            
            if (rows.length > 0) {
                const userData = rows[0];
                if (userData.responsibleChefs) {
                    userData.responsibleChefs = JSON.parse(userData.responsibleChefs);
                }
                
                // If including magasin data, create a magasin object
                if (includeMagasin && userData.magasin_id) {
                    userData.magasin = {
                        id: userData.magasin_id,
                        name: userData.magasin_name,
                        address: userData.magasin_address,
                        city: userData.magasin_city
                    };
                    // Remove the extra fields to avoid conflicts
                    delete userData.magasin_id;
                    delete userData.magasin_name;
                    delete userData.magasin_address;
                    delete userData.magasin_city;
                }
                
                return new User(userData);
            }
            return null;
        } finally {
            connection.release();
        }
    }

    // Find user by ID - UPDATED to include magasin data if needed
    static async findById(id, includeMagasin = false) {
        const connection = await pool.getConnection();
        try {
            let query = 'SELECT u.*';
            if (includeMagasin) {
                query += ', m.id as magasin_id, m.name as magasin_name, m.address as magasin_address, m.city as magasin_city';
            }
            query += ' FROM users u';
            if (includeMagasin) {
                query += ' LEFT JOIN magasins m ON u.magasin_id = m.id';
            }
            query += ' WHERE u.id = ?';
            
            const [rows] = await connection.execute(query, [id]);
            
            if (rows.length > 0) {
                const userData = rows[0];
                if (userData.responsibleChefs) {
                    userData.responsibleChefs = JSON.parse(userData.responsibleChefs);
                }
                
                // If including magasin data, create a magasin object
                if (includeMagasin && userData.magasin_id) {
                    userData.magasin = {
                        id: userData.magasin_id,
                        name: userData.magasin_name,
                        address: userData.magasin_address,
                        city: userData.magasin_city
                    };
                    // Remove the extra fields to avoid conflicts
                    delete userData.magasin_id;
                    delete userData.magasin_name;
                    delete userData.magasin_address;
                    delete userData.magasin_city;
                }
                
                return new User(userData);
            }
            return null;
        } finally {
            connection.release();
        }
    }

    // Find user by verification token - UPDATED
    static async findByVerificationToken(token) {
        const connection = await pool.getConnection();
        try {
            const [rows] = await connection.execute(
                'SELECT * FROM users WHERE emailVerificationToken = ? AND emailVerificationExpires > NOW()',
                [token]
            );
            if (rows.length > 0) {
                const userData = rows[0];
                if (userData.responsibleChefs) {
                    userData.responsibleChefs = JSON.parse(userData.responsibleChefs);
                }
                return new User(userData);
            }
            return null;
        } finally {
            connection.release();
        }
    }

    // Update user - UPDATED to handle magasin_id
    async update(updateData) {
        const connection = await pool.getConnection();
        try {
            const fields = [];
            const values = [];

            Object.keys(updateData).forEach(key => {
                if (updateData[key] !== undefined) {
                    fields.push(`${key} = ?`);
                    if (key === 'responsibleChefs' && updateData[key]) {
                        values.push(JSON.stringify(updateData[key]));
                    } else {
                        values.push(updateData[key]);
                    }
                }
            });

            if (fields.length === 0) return false;

            values.push(this.id);
            const query = `UPDATE users SET ${fields.join(', ')} WHERE id = ?`;
            
            const [result] = await connection.execute(query, values);
            return result.affectedRows > 0;
        } finally {
            connection.release();
        }
    }

    // Hash password
    static async hashPassword(password) {
        return await bcrypt.hash(password, 12);
    }

    // Compare password
    async comparePassword(password) {
        if (!this.password) return false;
        return await bcrypt.compare(password, this.password);
    }

    // Get all users (for admin) - UPDATED to include magasin data
    static async findAll(includeMagasin = false) {
        const connection = await pool.getConnection();
        try {
            let query = 'SELECT u.*';
            if (includeMagasin) {
                query += ', m.id as magasin_id, m.name as magasin_name, m.address as magasin_address, m.city as magasin_city';
            }
            query += ' FROM users u';
            if (includeMagasin) {
                query += ' LEFT JOIN magasins m ON u.magasin_id = m.id';
            }
            query += ' ORDER BY u.createdAt DESC';
            
            const [rows] = await connection.execute(query);
            
            return rows.map(userData => {
                if (userData.responsibleChefs) {
                    userData.responsibleChefs = JSON.parse(userData.responsibleChefs);
                }
                
                // If including magasin data, create a magasin object
                if (includeMagasin && userData.magasin_id) {
                    userData.magasin = {
                        id: userData.magasin_id,
                        name: userData.magasin_name,
                        address: userData.magasin_address,
                        city: userData.magasin_city
                    };
                    // Remove the extra fields to avoid conflicts
                    delete userData.magasin_id;
                    delete userData.magasin_name;
                    delete userData.magasin_address;
                    delete userData.magasin_city;
                }
                
                return new User(userData);
            });
        } finally {
            connection.release();
        }
    }

    // Find users by magasin_id
    static async findByMagasinId(magasinId) {
        const connection = await pool.getConnection();
        try {
            const [rows] = await connection.execute(
                'SELECT * FROM users WHERE magasin_id = ? ORDER BY createdAt DESC',
                [magasinId]
            );
            return rows.map(userData => {
                if (userData.responsibleChefs) {
                    userData.responsibleChefs = JSON.parse(userData.responsibleChefs);
                }
                return new User(userData);
            });
        } finally {
            connection.release();
        }
    }

    // Delete user
    async delete() {
        const connection = await pool.getConnection();
        try {
            const [result] = await connection.execute('DELETE FROM users WHERE id = ?', [this.id]);
            return result.affectedRows > 0;
        } finally {
            connection.release();
        }
    }

    // Convert to JSON (exclude sensitive data)
    toJSON() {
        const { password, emailVerificationToken, emailVerificationExpires, ...userWithoutSensitiveData } = this;
        return userWithoutSensitiveData;
    }
}

module.exports = User;