const User = require('../models/User');

const userController = {
  // Get all users
  getAllUsers: async (req, res) => {
    try {
      const users = await User.findAll();
      res.json({
        success: true,
        data: users.map(user => user.toJSON())
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'Error fetching users',
        error: error.message
      });
    }
  },

  // Get user by ID
  getUserById: async (req, res) => {
    try {
      const user = await User.findById(req.params.id);
      if (!user) {
        return res.status(404).json({
          success: false,
          message: 'User not found'
        });
      }
      res.json({
        success: true,
        data: user.toJSON()
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'Error fetching user',
        error: error.message
      });
    }
  },

  // Create new user
  createUser: async (req, res) => {
    try {
      const { email, firstname, lastname, poste, responsibleChefs } = req.body;
      
      // Check if user already exists
      const existingUser = await User.findByEmail(email);
      if (existingUser) {
        return res.status(400).json({
          success: false,
          message: 'User with this email already exists'
        });
      }

      // Create user data with default validation values (boolean false = 0)
      const userData = {
        email,
        firstname,
        lastname,
        poste,
        responsibleChefs: responsibleChefs || [],
        validEmail: false, // boolean false = 0 in display
        verifiedProfileRh: false, // boolean false = 0 in display
        verifiedProfileDirection: false // boolean false = 0 in display
      };

      const userId = await User.create(userData);
      const newUser = await User.findById(userId);
      
      res.status(201).json({
        success: true,
        data: newUser.toJSON(),
        message: 'User created successfully'
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'Error creating user',
        error: error.message
      });
    }
  },

  // Update user
  updateUser: async (req, res) => {
    try {
      const { email, firstname, lastname, poste, responsibleChefs } = req.body;
      
      // Find the user first
      const user = await User.findById(req.params.id);
      if (!user) {
        return res.status(404).json({
          success: false,
          message: 'User not found'
        });
      }

      // Check if email is being changed and if it already exists
      if (email && email !== user.email) {
        const existingUser = await User.findByEmail(email);
        if (existingUser) {
          return res.status(400).json({
            success: false,
            message: 'User with this email already exists'
          });
        }
      }

      // Prepare update data
      const updateData = {};
      if (email !== undefined) updateData.email = email;
      if (firstname !== undefined) updateData.firstname = firstname;
      if (lastname !== undefined) updateData.lastname = lastname;
      if (poste !== undefined) updateData.poste = poste;
      if (responsibleChefs !== undefined) updateData.responsibleChefs = responsibleChefs;

      // Update the user
      const updated = await user.update(updateData);
      if (!updated) {
        return res.status(500).json({
          success: false,
          message: 'Failed to update user'
        });
      }

      // Fetch updated user
      const updatedUser = await User.findById(req.params.id);
      res.json({
        success: true,
        data: updatedUser.toJSON(),
        message: 'User updated successfully'
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'Error updating user',
        error: error.message
      });
    }
  },

  // Delete user
  deleteUser: async (req, res) => {
    try {
      const user = await User.findById(req.params.id);
      if (!user) {
        return res.status(404).json({
          success: false,
          message: 'User not found'
        });
      }

      const deleted = await user.delete();
      if (!deleted) {
        return res.status(500).json({
          success: false,
          message: 'Failed to delete user'
        });
      }

      res.json({
        success: true,
        message: 'User deleted successfully',
        data: user.toJSON()
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'Error deleting user',
        error: error.message
      });
    }
  },

  // Get all chefs (users with chef-related positions)
  getAllChefs: async (req, res) => {
    try {
      const allUsers = await User.findAll();
   
      
      res.json({
        success: true,
        data: allUsers.map(chef => ({
          id: chef.id,
          firstname: chef.firstname,
          lastname: chef.lastname,
          email: chef.email,
          poste: chef.poste
        }))
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'Error fetching chefs',
        error: error.message
      });
    }
  },

  // Search chefs
  searchChefs: async (req, res) => {
    try {
      const { q } = req.query;
      if (!q) {
        return res.json({
          success: true,
          data: []
        });
      }

      const allUsers = await User.findAll();
      const chefs = allUsers.filter(user => 
        user.poste && ['Chef', 'Head Chef', 'Kitchen Manager'].includes(user.poste)
      );

      const searchQuery = q.toLowerCase();
      const filteredChefs = chefs.filter(chef => 
        chef.firstname.toLowerCase().includes(searchQuery) ||
        chef.lastname.toLowerCase().includes(searchQuery) ||
        chef.email.toLowerCase().includes(searchQuery)
      );
      
      res.json({
        success: true,
        data: filteredChefs.map(chef => ({
          id: chef.id,
          firstname: chef.firstname,
          lastname: chef.lastname,
          email: chef.email,
          poste: chef.poste
        }))
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'Error searching chefs',
        error: error.message
      });
    }
  },

  // Validate user email
  validateUserEmail: async (req, res) => {
    try {
      const { isValid } = req.body;
      
      const user = await User.findById(req.params.id);
      if (!user) {
        return res.status(404).json({
          success: false,
          message: 'User not found'
        });
      }

      // Update validation status (boolean true/false maps to 1/0 in frontend display)
      const updated = await user.update({ validEmail: isValid });
      if (!updated) {
        return res.status(500).json({
          success: false,
          message: 'Failed to update email validation'
        });
      }

      const updatedUser = await User.findById(req.params.id);
      res.json({
        success: true,
        data: updatedUser.toJSON(),
        message: `Email validation ${isValid ? 'approved' : 'rejected'}`
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'Error validating email',
        error: error.message
      });
    }
  },

  // Validate user RH profile
  validateUserRH: async (req, res) => {
    try {
      const { isValid } = req.body;
      
      const user = await User.findById(req.params.id);
      if (!user) {
        return res.status(404).json({
          success: false,
          message: 'User not found'
        });
      }

      const updated = await user.update({ verifiedProfileRh: isValid });
      if (!updated) {
        return res.status(500).json({
          success: false,
          message: 'Failed to update RH validation'
        });
      }

      const updatedUser = await User.findById(req.params.id);
      res.json({
        success: true,
        data: updatedUser.toJSON(),
        message: `RH validation ${isValid ? 'approved' : 'rejected'}`
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'Error validating RH profile',
        error: error.message
      });
    }
  },

  // Validate user Direction profile
  validateUserDirection: async (req, res) => {
    try {
      const { isValid } = req.body;
      
      const user = await User.findById(req.params.id);
      if (!user) {
        return res.status(404).json({
          success: false,
          message: 'User not found'
        });
      }

      const updated = await user.update({ verifiedProfileDirection: isValid });
      if (!updated) {
        return res.status(500).json({
          success: false,
          message: 'Failed to update direction validation'
        });
      }

      const updatedUser = await User.findById(req.params.id);
      res.json({
        success: true,
        data: updatedUser.toJSON(),
        message: `Direction validation ${isValid ? 'approved' : 'rejected'}`
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'Error validating direction profile',
        error: error.message
      });
    }
  },

  // Bulk validate emails
  bulkValidateEmails: async (req, res) => {
    try {
      const { userIds, isValid } = req.body;
      
      if (!Array.isArray(userIds) || userIds.length === 0) {
        return res.status(400).json({
          success: false,
          message: 'userIds must be a non-empty array'
        });
      }

      let updatedCount = 0;
      for (const userId of userIds) {
        const user = await User.findById(userId);
        if (user) {
          const updated = await user.update({ validEmail: isValid });
          if (updated) updatedCount++;
        }
      }

      res.json({
        success: true,
        message: `${updatedCount} users' email validation updated`,
        data: { modifiedCount: updatedCount }
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'Error bulk validating emails',
        error: error.message
      });
    }
  },

  // Bulk validate RH profiles
  bulkValidateRH: async (req, res) => {
    try {
      const { userIds, isValid } = req.body;
      
      if (!Array.isArray(userIds) || userIds.length === 0) {
        return res.status(400).json({
          success: false,
          message: 'userIds must be a non-empty array'
        });
      }

      let updatedCount = 0;
      for (const userId of userIds) {
        const user = await User.findById(userId);
        if (user) {
          const updated = await user.update({ verifiedProfileRh: isValid });
          if (updated) updatedCount++;
        }
      }

      res.json({
        success: true,
        message: `${updatedCount} users' RH validation updated`,
        data: { modifiedCount: updatedCount }
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'Error bulk validating RH profiles',
        error: error.message
      });
    }
  },

  // Bulk validate Direction profiles
  bulkValidateDirection: async (req, res) => {
    try {
      const { userIds, isValid } = req.body;
      
      if (!Array.isArray(userIds) || userIds.length === 0) {
        return res.status(400).json({
          success: false,
          message: 'userIds must be a non-empty array'
        });
      }

      let updatedCount = 0;
      for (const userId of userIds) {
        const user = await User.findById(userId);
        if (user) {
          const updated = await user.update({ verifiedProfileDirection: isValid });
          if (updated) updatedCount++;
        }
      }

      res.json({
        success: true,
        message: `${updatedCount} users' direction validation updated`,
        data: { modifiedCount: updatedCount }
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'Error bulk validating direction profiles',
        error: error.message
      });
    }
  }
};

module.exports = userController;

